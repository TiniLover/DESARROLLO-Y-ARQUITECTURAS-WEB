namespace AventuraTemplate
{
    // =====================================================================
    // SUBCLASE CONCRETA: AVENTURA EN EL BOSQUE  (como MateCocido en la demo)
    // Tercera aventura (el enunciado pide al menos dos). Muestra que se
    // pueden tener más acciones sin tocar la clase abstracta.
    // =====================================================================
    public class AventuraBosque : Aventura
    {
        public override string Nombre => "El Bosque";

        protected override string Descripcion =>
            "Entrás a un bosque espeso. Los caminos se dividen y empieza a oscurecer.";

        protected override string[] Acciones => new[]
        {
            "Seguir el sendero marcado",
            "Trepar a un árbol para orientarte",
            "Seguir unas huellas en el barro"
        };

        protected override void EjecutarAccion(int eleccion)
        {
            switch (eleccion)
            {
                case 1:
                    Console.WriteLine("Seguís el sendero marcado...");
                    Console.WriteLine("Resultado: llegás a un refugio y pasás la noche a salvo.");
                    break;
                case 2:
                    Console.WriteLine("Trepás al árbol más alto...");
                    Console.WriteLine("Resultado: ves las luces de un pueblo y encontrás la salida.");
                    break;
                default:
                    Console.WriteLine("Seguís las huellas...");
                    Console.WriteLine("Resultado: te encontrás con un oso y tenés que huir corriendo.");
                    break;
            }
        }
    }
}
