namespace AventuraTemplate
{
    // =====================================================================
    // PATRÓN TEMPLATE METHOD — CLASE ABSTRACTA
    // ---------------------------------------------------------------------
    // ¿Por qué Template Method?
    //   Todas las aventuras siguen el MISMO flujo y en el MISMO orden:
    //     1. Mostrar introducción
    //     2. Validar la elección del jugador
    //     3. Ejecutar la acción elegida   <- lo ÚNICO que cambia por aventura
    //     4. Mostrar un desenlace común
    //   El patrón permite escribir ese flujo UNA sola vez (en esta clase) y
    //   que cada aventura (Cueva, Río, Bosque) complete solo su parte.
    //   Nadie puede saltear un paso ni cambiarles el orden.
    //
    // Es igual a BebidaCaliente de la demo de clase:
    //   PrepararBebidaCaliente()  ->  Jugar()
    //   Cafe, Te, MateCocido      ->  AventuraCueva, AventuraRio, AventuraBosque
    // =====================================================================
    public abstract class Aventura
    {
        // -----------------------------------------------------------------
        // MÉTODO PLANTILLA: define el flujo general.
        // Es público y NO es virtual: las subclases no pueden cambiarlo.
        // -----------------------------------------------------------------
        public void Jugar()
        {
            MostrarIntroduccion();          // 1. fijo
            int eleccion = ValidarEleccion(); // 2. fijo
            EjecutarAccion(eleccion);       // 3. abstracto: cada aventura lo resuelve
            MostrarDesenlace();             // 4. fijo
        }

        // ------------------- LO QUE COMPLETA CADA AVENTURA -------------------
        // abstract = cada subclase TIENE que definirlo.

        // Nombre de la aventura (se usa en la introducción y el desenlace).
        public abstract string Nombre { get; }

        // Texto que cuenta la situación inicial.
        protected abstract string Descripcion { get; }

        // Acciones que puede elegir el jugador (ej: "Encender antorcha").
        protected abstract string[] Acciones { get; }

        // PASO 3: qué pasa según la acción elegida (1, 2, ...).
        protected abstract void EjecutarAccion(int eleccion);

        // ------------------- PASOS COMUNES (iguales para todas) -------------------
        // private = las subclases no los pueden cambiar (como ServirEnTaza en la demo).

        // PASO 1: introducción con el nombre, la descripción y las opciones.
        private void MostrarIntroduccion()
        {
            Console.WriteLine();
            Console.WriteLine($"===== AVENTURA: {Nombre.ToUpper()} =====");
            Console.WriteLine(Descripcion);
            Console.WriteLine("¿Qué querés hacer?");
            for (int i = 0; i < Acciones.Length; i++)
            {
                Console.WriteLine($"  {i + 1}. {Acciones[i]}");
            }
        }

        // PASO 2: pide la opción y la valida hasta que sea correcta.
        // Válida = un número entre 1 y la cantidad de acciones.
        private int ValidarEleccion()
        {
            while (true)
            {
                Console.Write("Tu elección: ");
                string entrada = Console.ReadLine() ?? "";

                if (int.TryParse(entrada, out int eleccion) && eleccion >= 1 && eleccion <= Acciones.Length)
                {
                    Console.WriteLine($"Elegiste: {Acciones[eleccion - 1]}");
                    return eleccion;
                }

                Console.WriteLine($"Opción inválida. Ingresá un número del 1 al {Acciones.Length}.");
            }
        }

        // PASO 4: desenlace común a todas las aventuras.
        private void MostrarDesenlace()
        {
            Console.WriteLine("-----------------------------------------");
            Console.WriteLine($"Fin de la aventura \"{Nombre}\". ¡Gracias por jugar!");
        }
    }
}
