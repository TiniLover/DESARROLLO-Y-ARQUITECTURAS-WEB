﻿using System.Text;
using AventuraTemplate;

// =========================================================================
// PROGRAMA PRINCIPAL
// El jugador elige una aventura y se llama al MÉTODO PLANTILLA Jugar().
// El programa trata a todas como "Aventura" (la clase abstracta): no le
// importa cuál es, el flujo es siempre el mismo.
// =========================================================================

Console.OutputEncoding = Encoding.UTF8;

// Las aventuras disponibles. Para agregar otra, se crea la clase y se suma acá.
Aventura[] aventuras =
{
    new AventuraCueva(),
    new AventuraRio(),
    new AventuraBosque()
};

while (true)
{
    Console.WriteLine();
    Console.WriteLine("===== ELEGÍ TU AVENTURA =====");
    for (int i = 0; i < aventuras.Length; i++)
    {
        Console.WriteLine($"{i + 1}. {aventuras[i].Nombre}");
    }
    Console.WriteLine("0. Salir");
    Console.Write("Opción: ");

    string entrada = Console.ReadLine() ?? "";

    if (entrada == "0")
    {
        Console.WriteLine("¡Hasta la próxima!");
        break;
    }

    if (int.TryParse(entrada, out int opcion) && opcion >= 1 && opcion <= aventuras.Length)
    {
        // Template Method: el mismo llamado para cualquier aventura.
        aventuras[opcion - 1].Jugar();
    }
    else
    {
        Console.WriteLine("Opción inválida.");
    }
}
