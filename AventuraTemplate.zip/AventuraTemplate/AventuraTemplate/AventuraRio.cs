namespace AventuraTemplate
{
    // =====================================================================
    // SUBCLASE CONCRETA: AVENTURA EN EL RÍO  (como Te en la demo)
    // =====================================================================
    public class AventuraRio : Aventura
    {
        public override string Nombre => "El Río";

        protected override string Descripcion =>
            "Llegás a la orilla de un río caudaloso. Del otro lado se ve el camino a casa.";

        protected override string[] Acciones => new[]
        {
            "Construir una balsa",
            "Intentar nadar"
        };

        protected override void EjecutarAccion(int eleccion)
        {
            if (eleccion == 1)
            {
                Console.WriteLine("Juntás troncos y lianas y construís una balsa...");
                Console.WriteLine("Resultado: cruzás con éxito a la otra orilla.");
            }
            else
            {
                Console.WriteLine("Te tirás al agua e intentás nadar...");
                Console.WriteLine("Resultado: la corriente te arrastra y apenas lográs salir con vida.");
            }
        }
    }
}
