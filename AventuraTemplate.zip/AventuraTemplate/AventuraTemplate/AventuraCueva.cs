namespace AventuraTemplate
{
    // =====================================================================
    // SUBCLASE CONCRETA: AVENTURA EN LA CUEVA  (como Cafe en la demo)
    // Solo completa lo que la clase abstracta dejó abierto.
    // =====================================================================
    public class AventuraCueva : Aventura
    {
        public override string Nombre => "La Cueva";

        protected override string Descripcion =>
            "Entrás a una cueva oscura. Se escucha agua goteando en el fondo.";

        protected override string[] Acciones => new[]
        {
            "Encender antorcha",
            "Avanzar a ciegas"
        };

        protected override void EjecutarAccion(int eleccion)
        {
            if (eleccion == 1)
            {
                Console.WriteLine("Encendés la antorcha...");
                Console.WriteLine("Resultado: la luz ilumina el camino y revela un tesoro escondido.");
            }
            else
            {
                Console.WriteLine("Avanzás a ciegas...");
                Console.WriteLine("Resultado: tropezás y caés en un pozo profundo.");
            }
        }
    }
}
