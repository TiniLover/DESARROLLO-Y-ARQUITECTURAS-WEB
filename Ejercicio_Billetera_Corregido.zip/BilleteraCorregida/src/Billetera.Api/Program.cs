// =========================================================================
// API - Inyección de dependencias + endpoints
// (ANTES: proyecto "WebApplication1" -> ver error L9 en CORRECCIONES.txt)
// La inyección de dependencias (Singleton + Scoped) estaba BIEN.
// =========================================================================
using Billetera.Application.Abstracciones;
using Billetera.Application.Cuentas;
using Billetera.Infrastructure;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSingleton<ICuentaRepositorio, CuentaRepositorioEnMemoria>();

// -------------------------------------------------------------------------
// ❌ ERROR L5 - Faltaba registrar el caso de uso de depositar
//    QUÉ PASABA: si no se registra, .NET no sabe crearlo y el endpoint
//                de depositar da error al llamarlo.
//    ✅ CÓMO CORREGIRLO: agregá una línea AddScoped por cada caso de uso
//       nuevo que crees. Acá se agregó:
//           builder.Services.AddScoped<DepositarUseCase>();
// -------------------------------------------------------------------------
builder.Services.AddScoped<AbrirCuentaUseCase>();
builder.Services.AddScoped<ListarCuentasUseCase>();
builder.Services.AddScoped<DepositarUseCase>();
builder.Services.AddScoped<RetirarUseCase>();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// -------------------------------------------------------------------------
// GET /cuentas
// ❌ ERROR L7 - Ruta "/billeteras"
//    ✅ CÓMO CORREGIRLO: cambiá "/billeteras" por "/cuentas" en TODOS los
//       MapGet / MapPost (Ctrl+H: buscar "/billeteras", reemplazar "/cuentas").
// -------------------------------------------------------------------------
app.MapGet("/cuentas", async (ListarCuentasUseCase useCase, CancellationToken ct) =>
    Results.Ok(await useCase.ExecuteAsync(ct)))
.WithName("ListarCuentas")
.WithOpenApi();

// -------------------------------------------------------------------------
// POST /cuentas -> abrir cuenta
// ❌ ERROR E4 - CS1061  (Visual Studio lo marca en rojo, 4 veces en esta línea)
//    MENSAJE: 'CrearProductoRequest' does not contain a definition for 'Titular'
//             (y lo mismo para 'Alias', 'Saldo' y 'Cantidad')
//             ("CrearProductoRequest no contiene una definición para Titular")
//    QUÉ PASABA: el record estaba escrito con minúscula:
//                    CrearProductoRequest(string titular, string alias, ...)
//                En un record, el nombre del PARÁMETRO es el nombre de la
//                PROPIEDAD. Se creaba "request.titular" (minúscula) y vos
//                usabas "request.Titular" (mayúscula). C# los toma distintos.
//    ✅ CÓMO CORREGIRLO:
//       1. Andá al record al FINAL de este archivo.
//       2. Escribí cada parámetro con la PRIMERA LETRA EN MAYÚSCULA:
//              (string Titular, string Alias)
//       3. Compilá: los 4 errores CS1061 desaparecen.
//
// ❌ ERROR L3 - Se mandaban request.Saldo y request.Cantidad
//    ✅ CÓMO CORREGIRLO: borralos de esta llamada (la cuenta arranca en 0).
//    ANTES:  useCase.ExecuteAsync(request.Titular, request.Alias,
//                                 request.Saldo, request.Cantidad, ct);
// -------------------------------------------------------------------------
app.MapPost("/cuentas", async (AbrirCuentaRequest request, AbrirCuentaUseCase useCase, CancellationToken ct) =>
{
    try
    {
        var cuenta = await useCase.ExecuteAsync(request.Titular, request.Alias, ct);
        return Results.Created($"/cuentas/{cuenta.Id}", cuenta);          // 201
    }
    catch (ArgumentException ex)
    {
        return Results.BadRequest(new { error = ex.Message });           // 400
    }
})
.WithName("AbrirCuenta")
.WithOpenApi();

// -------------------------------------------------------------------------
// POST /cuentas/{id}/depositar
// ❌ ERROR L5 - Este endpoint NO EXISTÍA
//    ✅ CÓMO CORREGIRLO:
//       1. Copiá el bloque completo de "retirar" (el de abajo).
//       2. Cambiá la ruta: "/cuentas/{id:guid}/depositar".
//       3. Cambiá RetirarUseCase por DepositarUseCase.
//       4. Borrá el catch de InvalidOperationException (al depositar no
//          puede faltar saldo; solo puede venir un monto <= 0).
//       5. Cambiá .WithName("Retirar") por .WithName("Depositar").
// -------------------------------------------------------------------------
app.MapPost("/cuentas/{id:guid}/depositar", async (
    Guid id, MontoRequest request, DepositarUseCase useCase, CancellationToken ct) =>
{
    try
    {
        var cuenta = await useCase.ExecuteAsync(id, request.Monto, ct);
        return cuenta is null
            ? Results.NotFound(new { error = "No existe una cuenta con ese Id." })   // 404
            : Results.Ok(cuenta);                                                     // 200
    }
    catch (ArgumentException ex)
    {
        return Results.BadRequest(new { error = ex.Message });                       // 400
    }
})
.WithName("Depositar")
.WithOpenApi();

// -------------------------------------------------------------------------
// POST /cuentas/{id}/retirar
// ❌ ERROR L7 - Nombres copiados del Almacén
//    ✅ CÓMO CORREGIRLO:
//       1. "VenderRequest" -> "MontoRequest"  (y "request.Cantidad" -> "request.Monto").
//       2. "RetirarSaldo"  -> "RetirarUseCase".
//       3. .WithName("VenderProducto") -> .WithName("Retirar").
//       4. Mensaje "No existe un titular con ese Id." -> "No existe una cuenta
//          con ese Id." (lo que se busca es la cuenta).
// -------------------------------------------------------------------------
app.MapPost("/cuentas/{id:guid}/retirar", async (
    Guid id, MontoRequest request, RetirarUseCase useCase, CancellationToken ct) =>
{
    try
    {
        var cuenta = await useCase.ExecuteAsync(id, request.Monto, ct);
        return cuenta is null
            ? Results.NotFound(new { error = "No existe una cuenta con ese Id." })   // 404
            : Results.Ok(cuenta);                                                     // 200
    }
    catch (ArgumentException ex)                // monto <= 0
    {
        return Results.BadRequest(new { error = ex.Message });
    }
    catch (InvalidOperationException ex)        // saldo insuficiente
    {
        return Results.BadRequest(new { error = ex.Message });
    }
})
.WithName("Retirar")
.WithOpenApi();

app.Run();

// -------------------------------------------------------------------------
// DTOs DE ENTRADA
// ❌ ERROR E4 (CS1061) + L3 + L7
//    ANTES:  public sealed record CrearProductoRequest(string titular, string alias,
//                                                      decimal saldo, int cantidad);
//    ✅ CÓMO CORREGIRLO:
//       1. Parámetros con MAYÚSCULA: titular -> Titular, alias -> Alias  (arregla E4).
//       2. Borrá "decimal saldo, int cantidad"                         (arregla L3).
//       3. Renombrá CrearProductoRequest -> AbrirCuentaRequest con
//          Ctrl+R, Ctrl+R (se cambia también en el MapPost)            (arregla L7).
// -------------------------------------------------------------------------
public sealed record AbrirCuentaRequest(string Titular, string Alias);

// -------------------------------------------------------------------------
// ❌ ERROR L7 + L6
//    ANTES:  public sealed record VenderRequest(int Cantidad);
//    ✅ CÓMO CORREGIRLO:
//       1. Renombrá VenderRequest -> MontoRequest (Ctrl+R, Ctrl+R).
//       2. Cambiá "int Cantidad" por "decimal Monto" (es plata).
//       Este MISMO record sirve para depositar y para retirar, porque los
//       dos reciben { "monto": ... }.
// -------------------------------------------------------------------------
public sealed record MontoRequest(decimal Monto);
