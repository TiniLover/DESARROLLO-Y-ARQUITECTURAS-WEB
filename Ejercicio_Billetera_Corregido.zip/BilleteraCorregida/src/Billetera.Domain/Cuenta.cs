// =========================================================================
// DOMINIO - Entidad Cuenta   (ANTES: Domain/Billetera.cs)
// Errores de este archivo: L1, L2, L3, L4, L5, L6 (de LÓGICA: Visual Studio
// no los marca, pero el programa no cumple la consigna).
// =========================================================================
namespace Billetera.Domain;

// -------------------------------------------------------------------------
// ❌ ERROR L1 - La entidad se llamaba "Billetera"
//    QUÉ PASABA: la consigna dice "Entidad: Cuenta". "Billetera" es el nombre
//                del sistema, no de la entidad.
//    ✅ CÓMO CORREGIRLO:
//       1. Click derecho en el archivo Billetera.cs > Cambiar nombre > "Cuenta.cs".
//          Visual Studio pregunta si querés renombrar también la clase: Sí.
//       2. Si no lo pregunta: hacé click en la palabra "Billetera" de la línea
//          "public sealed class Billetera", apretá Ctrl+R, Ctrl+R, escribí
//          "Cuenta" y Enter. Así se cambia en TODO el proyecto a la vez.
//    ANTES:  public sealed class Billetera
// -------------------------------------------------------------------------
public sealed class Cuenta
{
    // ---------------------------------------------------------------------
    // ❌ ERROR L2 + L3 - El constructor recibía "saldo" y "cantidad"
    //    QUÉ PASABA: "cantidad" no está en la consigna (quedó del Almacén) y
    //                ni siquiera se asignaba. El saldo no hay que recibirlo
    //                porque toda cuenta nueva arranca en 0.
    //    ✅ CÓMO CORREGIRLO:
    //       1. Borrá los parámetros ", decimal saldo, int cantidad" del constructor.
    //       2. Borrá la línea "Saldo = saldo;" y escribí "Saldo = 0m;"
    //          (la "m" indica que es un número decimal).
    //    ANTES:  private Billetera(Guid id, string titular, string alias,
    //                              decimal saldo, int cantidad, DateTime fechaApertura)
    // ---------------------------------------------------------------------
    private Cuenta(Guid id, string titular, string alias, DateTime fechaApertura)
    {
        Id = id;
        Titular = titular;
        Alias = alias;
        FechaApertura = fechaApertura;
        Saldo = 0m;   // REGLA 3: toda cuenta se abre con saldo 0
    }

    public Guid Id { get; }

    // ✅ MEJORA: Titular, Alias y FechaApertura nunca cambian después de crear
    //    la cuenta -> borrá el "private set;" y dejá solo "{ get; }".
    public string Titular { get; }
    public string Alias { get; }
    public DateTime FechaApertura { get; }

    // Saldo SÍ cambia (al depositar y retirar) -> se queda con "private set".
    public decimal Saldo { get; private set; }

    // -------------------------------------------------------------------------
    // ❌ ERROR L2 - Sobraba la propiedad "Cantidad"
    //    QUÉ PASABA: no existe en la consigna; era el "Stock" del Almacén.
    //    ✅ CÓMO CORREGIRLO:
    //       1. Borrá la línea "public int Cantidad { get; private set; }".
    //       2. Compilá (Ctrl+Shift+B): Visual Studio te marca en rojo todos los
    //          lugares que usaban Cantidad (mapeo, DTO, API, pruebas).
    //          Borrá "Cantidad" de cada uno.
    //    ANTES:  public int Cantidad { get; private set; }
    // -------------------------------------------------------------------------

    // ---------------------------------------------------------------------
    // ❌ ERROR L3 - Crear recibía saldo y exigía saldo > 0
    //    QUÉ PASABA: la regla 3 dice "se abre con saldo 0", pero el código
    //                exigía saldo mayor a 0 -> era IMPOSIBLE abrir una cuenta
    //                cumpliendo la consigna.
    //    ✅ CÓMO CORREGIRLO:
    //       1. Cambiá la firma: borrá ", decimal saldo, int cantidad".
    //       2. Borrá los dos "if" de saldo y de cantidad (ver abajo).
    //       3. En el "return new ...", sacá saldo y cantidad de los parámetros.
    //    ANTES:  public static Billetera Crear(string titular, string alias,
    //                                         decimal saldo, int cantidad)
    // ---------------------------------------------------------------------
    public static Cuenta Crear(string titular, string alias)
    {
        // REGLA 1 (estaba BIEN, no se toca)
        if (string.IsNullOrWhiteSpace(titular))
            throw new ArgumentException("El titular es obligatorio.", nameof(titular));

        if (string.IsNullOrWhiteSpace(alias))
            throw new ArgumentException("El alias es obligatorio.", nameof(alias));

        // ❌ ERROR L3 - ✅ CÓMO CORREGIRLO: BORRAR estas líneas que estaban acá:
        //        if (saldo <= 0)
        //            throw new ArgumentException("El saldo tiene que ser mayor a 0.", ...);
        //
        // ❌ ERROR L2 - ✅ CÓMO CORREGIRLO: BORRAR también estas:
        //        if (cantidad < 0)
        //            throw new ArgumentException("La cantidad inicial no puede ser negativa.", ...);

        // -----------------------------------------------------------------
        // ❌ ERROR L4 - FALTABA la regla 2 (alias >= 6 caracteres, sin espacios)
        //    ✅ CÓMO CORREGIRLO: agregar estas validaciones DEBAJO de las de
        //       la regla 1:
        //       1. Guardá el alias sin espacios a los costados:
        //              string aliasLimpio = alias.Trim();
        //       2. Si tiene menos de 6 caracteres -> ArgumentException
        //              if (aliasLimpio.Length < 6) throw ...
        //       3. Si tiene algún espacio adentro -> ArgumentException
        //              if (aliasLimpio.Contains(' ')) throw ...
        //       4. En el "return new Cuenta(...)" usá aliasLimpio.
        // -----------------------------------------------------------------
        string aliasLimpio = alias.Trim();
        if (aliasLimpio.Length < 6)
            throw new ArgumentException("El alias tiene que tener al menos 6 caracteres.", nameof(alias));

        if (aliasLimpio.Contains(' '))
            throw new ArgumentException("El alias no puede contener espacios.", nameof(alias));

        return new Cuenta(Guid.NewGuid(), titular.Trim(), aliasLimpio, DateTime.UtcNow);
    }

    // ---------------------------------------------------------------------
    // ❌ ERROR L5 - FALTABA el método Depositar (regla 4)
    //    QUÉ PASABA: "Al depositar..." es una ACCIÓN que cambia el saldo, así
    //                que tiene que ser un método de la entidad.
    //    ✅ CÓMO CORREGIRLO:
    //       1. Copiá el método Retirar y pegalo arriba.
    //       2. Cambiale el nombre a "Depositar".
    //       3. Dejá solo la validación "monto <= 0" (al depositar no importa
    //          el saldo que haya).
    //       4. Cambiá "Saldo -= monto" por "Saldo += monto" (SUMA en vez de resta).
    // ---------------------------------------------------------------------
    public void Depositar(decimal monto)
    {
        if (monto <= 0)
            throw new ArgumentException("El monto a depositar tiene que ser mayor a 0.", nameof(monto));

        Saldo += monto;
    }

    // ---------------------------------------------------------------------
    // ❌ ERROR L6 - "retirar(int cantidad)": minúscula y con int
    //    QUÉ PASABA: los métodos públicos en C# van con MAYÚSCULA, y como es
    //                plata tiene que ser decimal (con int no se puede retirar
    //                $150,50).
    //    ✅ CÓMO CORREGIRLO:
    //       1. Click en "retirar" > Ctrl+R, Ctrl+R > escribí "Retirar" > Enter
    //          (se renombra también en RetirarSaldo.cs).
    //       2. Cambiá "int cantidad" por "decimal monto".
    //       3. Adentro del método, reemplazá "cantidad" por "monto"
    //          (Ctrl+H dentro del método).
    //    ANTES:  public void retirar(int cantidad)
    // ---------------------------------------------------------------------
    public void Retirar(decimal monto)
    {
        // Estas 2 validaciones estaban BIEN (solo cambia cantidad -> monto).
        if (monto <= 0)
            throw new ArgumentException("El monto a retirar tiene que ser mayor a 0.", nameof(monto));

        if (monto > Saldo)
            throw new InvalidOperationException($"Saldo insuficiente. Disponible: {Saldo}.");

        Saldo -= monto;
    }
}
