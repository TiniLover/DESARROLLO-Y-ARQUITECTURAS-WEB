// =========================================================================
// APLICACIÓN - Interfaz del repositorio
// (ANTES: IBilleteraRepositorio.cs - estaba BIEN, sin errores)
// Único detalle: el parámetro se llamaba "producto" (copiado del Almacén)
// -> ahora "cuenta". No daba error, pero confunde al leerlo.
// =========================================================================
using Billetera.Domain;

namespace Billetera.Application.Abstracciones;

public interface ICuentaRepositorio
{
    Task AddAsync(Cuenta cuenta, CancellationToken cancellationToken = default);
    Task<IReadOnlyCollection<Cuenta>> GetAllAsync(CancellationToken cancellationToken = default);
    Task<Cuenta?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default);
    Task UpdateAsync(Cuenta cuenta, CancellationToken cancellationToken = default);
}
