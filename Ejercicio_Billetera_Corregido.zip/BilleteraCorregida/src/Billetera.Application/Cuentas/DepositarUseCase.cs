// =========================================================================
// APLICACIÓN - Caso de uso: Depositar
// -------------------------------------------------------------------------
// ❌ ERROR L5 - Este archivo NO EXISTÍA (la consigna pide depositar).
//    ✅ CÓMO CORREGIRLO:
//       1. Click derecho en la carpeta "Casos de uso" > Agregar > Clase >
//          "DepositarUseCase.cs".
//       2. Borrá todo lo que crea Visual Studio y copiá el contenido de
//          RetirarUseCase.cs.
//       3. Cambiá el nombre de la clase a DepositarUseCase.
//       4. Cambiá "cuenta.Retirar(monto)" por "cuenta.Depositar(monto)".
//       5. Registralo en Program.cs:  builder.Services.AddScoped<DepositarUseCase>();
//
// NOTA: "ObtenerBilleteraPorId" se quitó porque esta consigna no pide
// GET /cuentas/{id} (era del Almacén). No daba error; si lo dejás no pasa
// nada, pero no suma puntos.
// =========================================================================
using Billetera.Application.Abstracciones;

namespace Billetera.Application.Cuentas;

public sealed class DepositarUseCase(ICuentaRepositorio repositorio)
{
    public async Task<CuentaDto?> ExecuteAsync(Guid id, decimal monto, CancellationToken cancellationToken = default)
    {
        var cuenta = await repositorio.GetByIdAsync(id, cancellationToken);
        if (cuenta is null)
            return null;                         // la API responde 404

        cuenta.Depositar(monto);                 // la regla 4 vive en la entidad

        await repositorio.UpdateAsync(cuenta, cancellationToken);
        return cuenta.ToDto();
    }
}
