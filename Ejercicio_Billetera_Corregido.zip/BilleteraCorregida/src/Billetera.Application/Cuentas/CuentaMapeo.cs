// =========================================================================
// APLICACIÓN - Mapeo Entidad -> DTO   (ANTES: BilletraMapeo.cs, sin la "e")
// =========================================================================
using Billetera.Domain;

namespace Billetera.Application.Cuentas;

internal static class CuentaMapeo
{
    // ---------------------------------------------------------------------
    // ❌ ERROR E2 - CS1729  (aparece cuando arreglás E1)
    //    MENSAJE: 'Billetera' does not contain a constructor that takes 6 arguments
    //             ("Billetera no contiene un constructor que tome 6 argumentos")
    //
    // ❌ ERROR E3 - CS0029  (aparece 4 veces, una en cada caso de uso)
    //    MENSAJE: Cannot implicitly convert type 'Domain.Billetera' to
    //             'Aplication.Casos_de_uso.BilleteraDTO'
    //             ("No se puede convertir implícitamente Billetera en BilleteraDTO")
    //
    //    QUÉ PASABA: el método decía que devolvía la ENTIDAD en vez del DTO:
    //        public static Billetera ToDto(this Billetera billetera) => new(...)
    //                      ^^^^^^^^^  <- acá está el error
    //      - E2: el "new(...)" intentaba crear una Billetera (cuyo
    //            constructor es privado y tiene otros parámetros).
    //      - E3: los casos de uso esperaban un DTO y recibían una Billetera.
    //      UNA sola palabra mal generaba 5 errores.
    //
    //    ✅ CÓMO CORREGIRLO:
    //       1. En la línea "public static Billetera ToDto(...)", cambiá la
    //          PRIMERA palabra "Billetera" (la del tipo de retorno) por el
    //          nombre del DTO:  public static CuentaDto ToDto(this Cuenta cuenta)
    //       2. Revisá que dentro del new(...) vayan los MISMOS datos y en el
    //          MISMO orden que en el record del DTO
    //          (Id, Titular, Alias, Saldo, FechaApertura). Sacá Cantidad.
    //       3. Compilá: desaparecen E2 y los 4 E3 a la vez.
    // ---------------------------------------------------------------------
    public static CuentaDto ToDto(this Cuenta cuenta) =>
        new(cuenta.Id, cuenta.Titular, cuenta.Alias, cuenta.Saldo, cuenta.FechaApertura);
}
