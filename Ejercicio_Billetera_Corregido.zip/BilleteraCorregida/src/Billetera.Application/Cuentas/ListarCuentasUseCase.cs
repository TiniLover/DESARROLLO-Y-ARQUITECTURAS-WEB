// =========================================================================
// APLICACIÓN - Caso de uso: Listar cuentas   (ANTES: ListarBilleteras.cs)
// La lógica estaba BIEN.
// =========================================================================
using Billetera.Application.Abstracciones;

namespace Billetera.Application.Cuentas;

public sealed class ListarCuentasUseCase(ICuentaRepositorio repositorio)
{
    // ❌ ERROR E1 (CS0050) lo marcaba en esta línea.
    //    ✅ CÓMO CORREGIRLO: no se toca acá; se arregla en CuentaDto.cs.
    public async Task<IReadOnlyCollection<CuentaDto>> ExecuteAsync(CancellationToken cancellationToken = default)
    {
        var cuentas = await repositorio.GetAllAsync(cancellationToken);

        // ❌ ERROR E3 (CS0029) lo marcaba en esta línea.
        //    ✅ CÓMO CORREGIRLO: no se toca acá; se arregla en CuentaMapeo.cs.
        return cuentas.Select(c => c.ToDto()).ToArray();
    }
}
