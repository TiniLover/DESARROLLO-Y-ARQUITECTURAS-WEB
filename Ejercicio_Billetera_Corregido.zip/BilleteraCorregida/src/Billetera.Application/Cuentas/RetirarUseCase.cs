// =========================================================================
// APLICACIÓN - Caso de uso: Retirar   (ANTES: RetirarSaldo.cs)
// =========================================================================
using Billetera.Application.Abstracciones;

namespace Billetera.Application.Cuentas;

public sealed class RetirarUseCase(ICuentaRepositorio repositorio)
{
    // ❌ ERROR E1 (CS0050) lo marcaba en esta línea.
    //    ✅ CÓMO CORREGIRLO: no se toca acá; se arregla en CuentaDto.cs.
    //
    // ❌ ERROR L6 - Recibía "int cantidad"
    //    ✅ CÓMO CORREGIRLO: cambiá "int cantidad" por "decimal monto".
    //    ANTES:  ExecuteAsync(Guid id, int cantidad, ...)
    public async Task<CuentaDto?> ExecuteAsync(Guid id, decimal monto, CancellationToken cancellationToken = default)
    {
        var cuenta = await repositorio.GetByIdAsync(id, cancellationToken);
        if (cuenta is null)
            return null;

        // ❌ ERROR L6
        //    ✅ CÓMO CORREGIRLO: si renombraste "retirar" con Ctrl+R, Ctrl+R en
        //       Cuenta.cs, esta línea se cambia sola. Si no, escribí
        //       "Retirar" con mayúscula y pasale "monto".
        //    ANTES:  billetera.retirar(cantidad);
        cuenta.Retirar(monto);

        await repositorio.UpdateAsync(cuenta, cancellationToken);

        // ❌ ERROR E3 (CS0029) lo marcaba en esta línea.
        //    ✅ CÓMO CORREGIRLO: no se toca acá; se arregla en CuentaMapeo.cs.
        return cuenta.ToDto();
    }
}
