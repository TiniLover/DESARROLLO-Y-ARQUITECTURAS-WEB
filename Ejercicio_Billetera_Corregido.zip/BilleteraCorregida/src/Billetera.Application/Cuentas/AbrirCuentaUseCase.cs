// =========================================================================
// APLICACIÓN - Caso de uso: Abrir cuenta   (ANTES: CrearBilletera.cs)
// =========================================================================
using Billetera.Application.Abstracciones;
using Billetera.Domain;

namespace Billetera.Application.Cuentas;

public sealed class AbrirCuentaUseCase(ICuentaRepositorio repositorio)
{
    // ❌ ERROR E1 (CS0050) lo marcaba en esta línea.
    //    ✅ CÓMO CORREGIRLO: no se toca acá; se arregla en CuentaDto.cs.
    //
    // ❌ ERROR L3 - Recibía saldo y cantidad
    //    ✅ CÓMO CORREGIRLO: borrá ", decimal saldo, int cantidad" de los
    //       parámetros y también en la llamada a Cuenta.Crear(...) de abajo.
    //    ANTES:  ExecuteAsync(string titular, string alias, decimal saldo, int cantidad, ...)
    public async Task<CuentaDto> ExecuteAsync(string titular, string alias, CancellationToken cancellationToken = default)
    {
        var cuenta = Cuenta.Crear(titular, alias);
        await repositorio.AddAsync(cuenta, cancellationToken);

        // ❌ ERROR E3 (CS0029) lo marcaba en esta línea.
        //    ✅ CÓMO CORREGIRLO: no se toca acá; se arregla en CuentaMapeo.cs.
        return cuenta.ToDto();
    }
}
