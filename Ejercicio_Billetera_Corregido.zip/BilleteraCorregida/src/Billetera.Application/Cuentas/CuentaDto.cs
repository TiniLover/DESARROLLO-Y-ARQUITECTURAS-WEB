// =========================================================================
// APLICACIÓN - DTO de salida   (ANTES: Aplication/Casos de uso/BilleteraDTO.cs)
// =========================================================================
namespace Billetera.Application.Cuentas;

// -------------------------------------------------------------------------
// ❌ ERROR E1 - CS0050  (Visual Studio lo marca en rojo, 4 veces)
//    MENSAJE: Inconsistent accessibility: return type 'Task<BilleteraDTO>'
//             is less accessible than method 'CrearBilletera.ExecuteAsync(...)'
//             ("Accesibilidad incoherente: el tipo de valor devuelto es
//              menos accesible que el método")
//    DÓNDE LO MARCABA: CrearBilletera.cs, ListarBilleteras.cs,
//                      ObtenerBilleteraPorId.cs y RetirarSaldo.cs
//
//    QUÉ PASABA:
//      - La clase era "internal" (solo visible dentro del proyecto
//        Application), pero los casos de uso son "public" y la devuelven
//        hacia la API. Un método public no puede devolver algo internal.
//      - Además estaba VACÍA: Visual Studio crea las clases así cuando hacés
//        "Agregar > Clase".
//
//    ✅ CÓMO CORREGIRLO:
//       1. Abrí BilleteraDTO.cs y BORRÁ todo esto:
//              internal class BilleteraDTO
//              {
//              }
//       2. Escribí en su lugar el record, PUBLIC y con los datos de la cuenta:
//              public sealed record CuentaDto(Guid Id, string Titular,
//                  string Alias, decimal Saldo, DateTime FechaApertura);
//       3. Compilá (Ctrl+Shift+B): los 4 errores CS0050 desaparecen.
//    TIP: cada vez que crees una clase con "Agregar > Clase", cambiá
//         "internal" por "public" ANTES de seguir.
// -------------------------------------------------------------------------
public sealed record CuentaDto(
    Guid Id,
    string Titular,
    string Alias,
    decimal Saldo,
    DateTime FechaApertura);
