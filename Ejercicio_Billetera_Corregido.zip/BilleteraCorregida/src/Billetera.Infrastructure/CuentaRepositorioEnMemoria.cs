// =========================================================================
// INFRAESTRUCTURA - Repositorio en memoria
// (ANTES: BilleteraRepositorioEnMemoria.cs - estaba BIEN, sin errores.
//  Solo cambia Billetera -> Cuenta por el error L1.)
// =========================================================================
using System.Collections.Concurrent;
using Billetera.Application.Abstracciones;
using Billetera.Domain;

namespace Billetera.Infrastructure;

public sealed class CuentaRepositorioEnMemoria : ICuentaRepositorio
{
    private readonly ConcurrentDictionary<Guid, Cuenta> cuentas = new();

    public Task AddAsync(Cuenta cuenta, CancellationToken cancellationToken = default)
    {
        cuentas[cuenta.Id] = cuenta;
        return Task.CompletedTask;
    }

    public Task<IReadOnlyCollection<Cuenta>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        IReadOnlyCollection<Cuenta> resultado = cuentas.Values.OrderBy(c => c.FechaApertura).ToArray();
        return Task.FromResult(resultado);
    }

    public Task<Cuenta?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
    {
        cuentas.TryGetValue(id, out var cuenta);
        return Task.FromResult(cuenta);
    }

    public Task UpdateAsync(Cuenta cuenta, CancellationToken cancellationToken = default)
    {
        cuentas[cuenta.Id] = cuenta;
        return Task.CompletedTask;
    }
}
