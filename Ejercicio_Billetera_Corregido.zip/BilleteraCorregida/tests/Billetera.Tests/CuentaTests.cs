// =========================================================================
// PRUEBAS (ANTES: Test/UnitTest1.cs)
// -------------------------------------------------------------------------
// Hay 2 tipos de error en las pruebas:
//   E5      -> error de COMPILACIÓN (Visual Studio no deja ejecutar nada).
//   P1..P3  -> la prueba COMPILA, pero al ejecutarla FALLA (cruz roja en
//              el Explorador de pruebas). Se ven en "Prueba > Ejecutar todas".
// Además, las pruebas eran las del Almacén ("precio 0", "stock negativo")
// y no las 5 que pide esta consigna.
// ✅ CÓMO CORREGIRLO: escribí UNA prueba por cada punto de "Pruebas mínimas"
//    de la consigna, con un nombre que diga lo que prueba.
//    Renombrá también el archivo UnitTest1.cs -> CuentaTests.cs.
// =========================================================================
using Billetera.Application.Abstracciones;
using Billetera.Application.Cuentas;
using Billetera.Domain;

namespace Billetera.Tests;

public sealed class CuentaTests
{
    // Prueba 1 de la consigna
    // ❌ ANTES había "Crear_con_precio_0_lanza_excepcion" (del Almacén).
    // ✅ Se reemplaza por: crear con alias "abc" (3 letras) tiene que fallar.
    [Fact]
    public void Alias_corto_lanza_excepcion()
    {
        Assert.Throws<ArgumentException>(() => Cuenta.Crear("Ana López", "abc"));
    }

    // Prueba 2 de la consigna
    // ❌ ANTES había "Crear_con_stock_negativo_lanza_excepcion" (del Almacén).
    // ✅ Se reemplaza por: crear con alias con espacio tiene que fallar.
    [Fact]
    public void Alias_con_espacio_lanza_excepcion()
    {
        Assert.Throws<ArgumentException>(() => Cuenta.Crear("Ana López", "sol rio"));
    }

    // Prueba 3 de la consigna
    // ❌ ANTES no existía. ✅ Se agrega: una cuenta nueva tiene saldo 0.
    [Fact]
    public void Cuenta_nueva_tiene_saldo_0()
    {
        var cuenta = Cuenta.Crear("Ana López", "sol.rio.mate");
        Assert.Equal(0m, cuenta.Saldo);
    }

    // ---------------------------------------------------------------------
    // Prueba 4 de la consigna
    // ❌ ERROR P2 - La prueba FALLABA al ejecutarse
    //    ANTES:
    //        var billetera = Billetera.Crear("juan", "juan.perez", 3500m, 10);
    //        billetera.retirar(3);
    //        Assert.Equal(7, billetera.Saldo);
    //    RESULTADO: "Assert.Equal() Failure: Expected: 7  Actual: 3497"
    //    POR QUÉ: el 10 era la CANTIDAD (copiado del stock del Almacén), pero
    //             se retiraba del SALDO, que era 3500. 3500 - 3 = 3497.
    //    ✅ CÓMO CORREGIRLO:
    //       1. Cambiá el nombre de la prueba por lo que pide la consigna:
    //          Depositar_5000_y_retirar_2000_deja_3000
    //       2. Creá la cuenta SIN saldo:  Cuenta.Crear("Ana López", "sol.rio.mate")
    //       3. Depositá 5000m y retirá 2000m (la "m" = número decimal).
    //       4. Verificá con Assert.Equal(3000m, cuenta.Saldo).
    // ---------------------------------------------------------------------
    [Fact]
    public void Depositar_5000_y_retirar_2000_deja_3000()
    {
        var cuenta = Cuenta.Crear("Ana López", "sol.rio.mate");

        cuenta.Depositar(5000m);
        cuenta.Retirar(2000m);

        Assert.Equal(3000m, cuenta.Saldo);
    }

    // ---------------------------------------------------------------------
    // Prueba 5 de la consigna
    // ❌ ERROR E5 - CS0120 (lo marca Visual Studio)
    //    MENSAJE: An object reference is required for the non-static field,
    //             method, or property 'Billetera.retirar(int)'
    //             ("Se requiere una referencia de objeto para el campo,
    //              método o propiedad no estáticos 'Billetera.retirar(int)'")
    //    ANTES:   Assert.Throws<InvalidOperationException>(() => Billetera.retirar(5));
    //                                                             ^^^^^^^^^
    //    QUÉ PASABA: se llamaba sobre la CLASE (Billetera) en vez de sobre la
    //             VARIABLE (producto). Solo los métodos "static" (como Crear)
    //             se llaman sobre la clase; Retirar es de CADA cuenta.
    //    ✅ CÓMO CORREGIRLO: cambiá "Billetera.retirar(5)" por el nombre de
    //       la VARIABLE que creaste arriba:  cuenta.Retirar(5000m)
    //
    // ❌ ERROR P3 - Además, aun arreglando E5, la prueba FALLABA:
    //    RESULTADO: "Assert.Throws() Failure: No exception was thrown"
    //    QUÉ PASABA: el saldo era 3500 y se retiraba 5: alcanzaba, no hay error.
    //    ✅ CÓMO CORREGIRLO: para probar "retirar más que el saldo", el monto
    //       a retirar tiene que ser MAYOR al saldo. Depositá 1000m y
    //       intentá retirar 5000m.
    // ---------------------------------------------------------------------
    [Fact]
    public void Retirar_mas_que_el_saldo_lanza_excepcion()
    {
        var cuenta = Cuenta.Crear("Ana López", "sol.rio.mate");
        cuenta.Depositar(1000m);

        Assert.Throws<InvalidOperationException>(() => cuenta.Retirar(5000m));
    }

    // ---------------------------------------------------------------------
    // Extra: el caso de uso guarda y devuelve el DTO
    // ❌ ERROR P1 - La prueba FALLABA al ejecutarse
    //    ANTES:
    //        var resultado = await useCase.ExecuteAsync("  Julia  ", "julia.gomez", 1500000m, 19);
    //        Assert.Equal("julia", resultado.Titular);
    //    RESULTADO: "Assert.Equal() Failure: Strings differ
    //                Expected: "julia"   Actual: "Julia""
    //    QUÉ PASABA: Trim() saca los ESPACIOS, pero NO cambia las mayúsculas.
    //             "  Julia  " queda "Julia" (con J mayúscula).
    //    ✅ CÓMO CORREGIRLO:
    //       1. En el Assert, escribí el resultado esperado con la MISMA
    //          mayúscula que el dato de entrada: "Julia" (o "Julia Gómez").
    //       2. Borrá ", 1500000m, 19" de ExecuteAsync (error L3).
    //       3. Cambiá Assert.Equal(19, resultado.Cantidad) por
    //          Assert.Equal(0m, resultado.Saldo) (Cantidad ya no existe, L2).
    // ---------------------------------------------------------------------
    [Fact]
    public async Task Abrir_cuenta_guarda_y_devuelve_dto()
    {
        var repositorio = new RepositorioFalso();
        var useCase = new AbrirCuentaUseCase(repositorio);

        var resultado = await useCase.ExecuteAsync("  Julia Gómez  ", "julia.gomez");

        Assert.Equal("Julia Gómez", resultado.Titular);
        Assert.Equal(0m, resultado.Saldo);
        Assert.Single(repositorio.Cuentas);
    }

    // Repositorio falso (estaba BIEN; solo Billetera -> Cuenta).
    private sealed class RepositorioFalso : ICuentaRepositorio
    {
        public List<Cuenta> Cuentas { get; } = [];

        public Task AddAsync(Cuenta cuenta, CancellationToken cancellationToken = default)
        {
            Cuentas.Add(cuenta);
            return Task.CompletedTask;
        }

        public Task<IReadOnlyCollection<Cuenta>> GetAllAsync(CancellationToken cancellationToken = default)
            => Task.FromResult<IReadOnlyCollection<Cuenta>>(Cuentas);

        public Task<Cuenta?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
            => Task.FromResult(Cuentas.FirstOrDefault(c => c.Id == id));

        public Task UpdateAsync(Cuenta cuenta, CancellationToken cancellationToken = default)
            => Task.CompletedTask;
    }
}
