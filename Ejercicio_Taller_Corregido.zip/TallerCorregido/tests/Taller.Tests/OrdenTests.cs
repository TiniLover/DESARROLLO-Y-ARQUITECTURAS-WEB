// =========================================================================
// PRUEBAS   (ANTES: Test/UnitTest1.cs)
// -------------------------------------------------------------------------
// Compilaban, pero al ejecutarlas: 3 de 4 FALLABAN. Así aparecía en el
// Explorador de pruebas:
//   Con error! - Con error: 3, Superado: 1, Total: 4
//
// ❌ ERROR L11 - Faltaban pruebas de la consigna (había 4 y piden 5, y
//    ninguna probaba la patente con espacio ni el presupuesto 0).
//    ✅ CÓMO CORREGIRLO: una [Fact] por cada "prueba mínima" de la consigna.
// =========================================================================
using Taller.Application.Abstracciones;
using Taller.Application.Ordenes;
using Taller.Domain;

namespace Taller.Tests;

public sealed class OrdenTests
{
    // ---------------------------------------------------------------------
    // Prueba 1 de la consigna: patente con espacio
    // ❌ ERROR P1 - Tu prueba "Crear_Taller_lanza_excepcion" FALLABA:
    //      Assert.Throws() Failure: No exception was thrown
    //      Expected: typeof(System.ArgumentException)
    //    QUÉ PASABA: le pasabas una patente válida ("AB395BE"), presupuesto
    //                válido y una fecha de ayer. Esperabas error por la
    //                fecha, pero Crear ya no valida la fecha -> no hay error.
    //    ✅ CÓMO CORREGIRLO: probá lo que pide la consigna: patente "AB 123".
    // ---------------------------------------------------------------------
    [Fact]
    public void Crear_con_patente_con_espacio_lanza_excepcion()
    {
        Assert.Throws<ArgumentException>(() => Orden.Crear("AB 123", "Lucas Ferreyra", 250000m));
    }

    // Prueba 2 de la consigna (❌ ANTES no existía)
    [Fact]
    public void Crear_con_presupuesto_0_lanza_excepcion()
    {
        Assert.Throws<ArgumentException>(() => Orden.Crear("AB123CD", "Lucas Ferreyra", 0m));
    }

    // Prueba 3 de la consigna (✅ tu "Taller_nueva_esta_Recibida" estaba bien;
    // se agrega que el costo final sea 0, como pide la consigna)
    [Fact]
    public void Orden_nueva_esta_recibida_y_con_costo_0()
    {
        var orden = Orden.Crear("AB123CD", "Lucas Ferreyra", 250000m);

        Assert.Equal(EstadoOrden.Recibida, orden.Estado);
        Assert.Equal(0m, orden.CostoFinal);
    }

    // ---------------------------------------------------------------------
    // Prueba 4 de la consigna
    // ❌ ERROR P2 - Tu prueba "EnReparacion_y_Lista_la_orden" FALLABA:
    //      System.ArgumentException : La fecha de ingreso no puede ser futura.
    //      (Parameter 'FechaIngreso')
    //    QUÉ PASABA: Reparar() comparaba FechaIngreso (UtcNow) con Now ->
    //                ver ERROR L5 en Orden.cs.
    //    ✅ CÓMO CORREGIRLO: con Iniciar() + Finalizar(230000m) y verificar
    //       el estado Y el costo final.
    // ---------------------------------------------------------------------
    [Fact]
    public void Iniciar_y_finalizar_deja_la_orden_lista_con_el_costo()
    {
        var orden = Orden.Crear("AB123CD", "Lucas Ferreyra", 250000m);

        orden.Iniciar();
        orden.Finalizar(230000m);

        Assert.Equal(EstadoOrden.Lista, orden.Estado);
        Assert.Equal(230000m, orden.CostoFinal);
    }

    // Prueba 5 de la consigna (❌ ANTES no existía)
    [Fact]
    public void Finalizar_una_orden_recibida_lanza_excepcion()
    {
        var orden = Orden.Crear("AB123CD", "Lucas Ferreyra", 250000m);

        Assert.Throws<InvalidOperationException>(() => orden.Finalizar(230000m));
    }

    // ---------------------------------------------------------------------
    // Extra: el caso de uso guarda y devuelve el DTO
    // ❌ ERROR P3 - Tu prueba FALLABA:
    //      Assert.Equal() Failure: Values differ
    //      Expected: 45000
    //      Actual:   0
    //    QUÉ PASABA (3 cosas):
    //      a) Esperabas CostoFinal 45000, pero una orden nueva SIEMPRE tiene
    //         costo 0 (regla 4). Además le habías mandado 30000, no 45000.
    //      b) Esperabas estado "Pendiente": eso era de Fútbol. Acá es "Recibida".
    //      c) El nombre decía "Crear_reserva_..." (de Fútbol).
    //    ✅ CÓMO CORREGIRLO: esperá CostoFinal 0 y Estado "Recibida".
    // ---------------------------------------------------------------------
    [Fact]
    public async Task Crear_orden_guarda_y_devuelve_dto_recibida()
    {
        var repositorio = new RepositorioFalso();
        var useCase = new CrearOrdenUseCase(repositorio);

        var resultado = await useCase.ExecuteAsync("ab123cd", "  Julia Gómez  ", 250000m);

        Assert.Equal("AB123CD", resultado.Patente);     // se guarda en mayúscula
        Assert.Equal("Julia Gómez", resultado.Cliente);
        Assert.Equal(0m, resultado.CostoFinal);
        Assert.Equal("Recibida", resultado.Estado);
        Assert.Single(repositorio.Ordenes);
    }

    // ✅ El repositorio falso estaba bien (solo: la lista se llamaba "Taller"
    //    igual que la clase -> confunde; ahora "Ordenes").
    private sealed class RepositorioFalso : IOrdenRepositorio
    {
        public List<Orden> Ordenes { get; } = [];

        public Task AddAsync(Orden orden, CancellationToken cancellationToken = default)
        {
            Ordenes.Add(orden);
            return Task.CompletedTask;
        }

        public Task<IReadOnlyCollection<Orden>> GetAllAsync(CancellationToken cancellationToken = default)
            => Task.FromResult<IReadOnlyCollection<Orden>>(Ordenes);

        public Task<Orden?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
            => Task.FromResult(Ordenes.FirstOrDefault(o => o.Id == id));

        public Task UpdateAsync(Orden orden, CancellationToken cancellationToken = default)
            => Task.CompletedTask;
    }
}
