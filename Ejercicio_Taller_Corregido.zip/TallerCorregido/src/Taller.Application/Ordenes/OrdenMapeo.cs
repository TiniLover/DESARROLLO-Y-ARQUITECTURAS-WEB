// APLICACIÓN - Mapeo   (✅ estaba bien; solo Estado -> Estado.ToString(), error L7)
using Taller.Domain;

namespace Taller.Application.Ordenes;

internal static class OrdenMapeo
{
    public static OrdenDto ToDto(this Orden orden) =>
        new(orden.Id, orden.Patente, orden.Cliente, orden.Presupuesto,
            orden.CostoFinal, orden.Estado.ToString(), orden.FechaIngreso);
}
