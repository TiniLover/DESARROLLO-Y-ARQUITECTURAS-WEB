// =========================================================================
// APLICACIÓN - Iniciar   (ANTES: Reparar.cs)
// ❌ ERROR L5 (nombre) - "Reparar" -> "IniciarOrdenUseCase", y adentro
//    "taller.Reparar()" -> "orden.Iniciar()".
//    ✅ La estructura (buscar, null -> 404, acción, guardar) estaba BIEN.
// =========================================================================
using Taller.Application.Abstracciones;

namespace Taller.Application.Ordenes;

public sealed class IniciarOrdenUseCase(IOrdenRepositorio repositorio)
{
    public async Task<OrdenDto?> ExecuteAsync(Guid id, CancellationToken cancellationToken = default)
    {
        var orden = await repositorio.GetByIdAsync(id, cancellationToken);
        if (orden is null)
            return null;

        orden.Iniciar();

        await repositorio.UpdateAsync(orden, cancellationToken);
        return orden.ToDto();
    }
}
