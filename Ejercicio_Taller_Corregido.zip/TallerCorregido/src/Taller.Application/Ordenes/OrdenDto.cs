// =========================================================================
// APLICACIÓN - DTO   (ANTES: TallerDTO.cs)
// ✅ public + record + todos los datos: bien.
// ❌ ERROR L7 - El estado iba como enum (Swagger muestra un número) y
//    sobraban las llaves vacías { } al final del record.
//    ✅ CÓMO CORREGIRLO:
//       1. "EnumTaller Estado" -> "string Estado".
//       2. En el mapeo: taller.Estado.ToString().
//       3. Borrá el "{ }" vacío y terminá el record con ";".
// =========================================================================
namespace Taller.Application.Ordenes;

public sealed record OrdenDto(
    Guid Id,
    string Patente,
    string Cliente,
    decimal Presupuesto,
    decimal CostoFinal,
    string Estado,
    DateTime FechaIngreso);
