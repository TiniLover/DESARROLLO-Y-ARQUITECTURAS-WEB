// =========================================================================
// APLICACIÓN - Finalizar
// ❌ ERROR L6 - NO EXISTÍA.
//    ✅ CÓMO CORREGIRLO: copiá IniciarOrdenUseCase y cambiá 2 cosas:
//       1. ExecuteAsync recibe también "decimal costoFinal".
//       2. Llama a "orden.Finalizar(costoFinal)".
//       Y registralo en Program.cs con AddScoped.
// =========================================================================
using Taller.Application.Abstracciones;

namespace Taller.Application.Ordenes;

public sealed class FinalizarOrdenUseCase(IOrdenRepositorio repositorio)
{
    public async Task<OrdenDto?> ExecuteAsync(Guid id, decimal costoFinal, CancellationToken cancellationToken = default)
    {
        var orden = await repositorio.GetByIdAsync(id, cancellationToken);
        if (orden is null)
            return null;

        orden.Finalizar(costoFinal);

        await repositorio.UpdateAsync(orden, cancellationToken);
        return orden.ToDto();
    }
}
