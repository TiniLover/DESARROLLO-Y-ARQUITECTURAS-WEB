// =========================================================================
// APLICACIÓN - Caso de uso: Crear   (ANTES: CrearTaller.cs)
// =========================================================================
using Taller.Application.Abstracciones;
using Taller.Domain;

namespace Taller.Application.Ordenes;

public sealed class CrearOrdenUseCase(IOrdenRepositorio repositorio)
{
    // ❌ ERROR L2 - Recibía costoFinal, estado y fechaIngreso
    //    QUÉ PASABA: ninguno de los tres viene del cliente (arrancan solos).
    //               "estado" ni siquiera se usaba adentro.
    //    ✅ CÓMO CORREGIRLO: dejá solo (patente, cliente, presupuesto, ct) y
    //       llamá a Crear con esos 3 datos.
    //    ANTES:  ExecuteAsync(string patente, string cliente, decimal presupuesto,
    //                         decimal costoFinal, EnumTaller estado, DateTime fechaIngreso, ...)
    public async Task<OrdenDto> ExecuteAsync(string patente, string cliente, decimal presupuesto,
        CancellationToken cancellationToken = default)
    {
        var orden = Orden.Crear(patente, cliente, presupuesto);
        await repositorio.AddAsync(orden, cancellationToken);
        return orden.ToDto();
    }
}
