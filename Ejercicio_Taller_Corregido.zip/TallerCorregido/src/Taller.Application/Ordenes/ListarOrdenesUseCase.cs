// APLICACIÓN - Listar   (ANTES: ListarTaller.cs)
// ✅ Estaba bien. Solo: la variable se llamaba "reservas" (de Fútbol) -> "ordenes".
using Taller.Application.Abstracciones;

namespace Taller.Application.Ordenes;

public sealed class ListarOrdenesUseCase(IOrdenRepositorio repositorio)
{
    public async Task<IReadOnlyCollection<OrdenDto>> ExecuteAsync(CancellationToken cancellationToken = default)
    {
        var ordenes = await repositorio.GetAllAsync(cancellationToken);
        return ordenes.Select(o => o.ToDto()).ToArray();
    }
}
