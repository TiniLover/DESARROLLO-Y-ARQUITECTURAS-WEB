// APLICACIÓN - Interfaz del repositorio
// ✅ Estaba BIEN. Solo cambia Taller -> Orden.
using Taller.Domain;

namespace Taller.Application.Abstracciones;

public interface IOrdenRepositorio
{
    Task AddAsync(Orden orden, CancellationToken cancellationToken = default);
    Task<IReadOnlyCollection<Orden>> GetAllAsync(CancellationToken cancellationToken = default);
    Task<Orden?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default);
    Task UpdateAsync(Orden orden, CancellationToken cancellationToken = default);
}
