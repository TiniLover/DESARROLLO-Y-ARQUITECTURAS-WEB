// =========================================================================
// DOMINIO - Entidad Orden   (ANTES: Domain/Taller.cs)
// -------------------------------------------------------------------------
// ✅ ¡BIEN! El constructor ya no recibe costoFinal, estado ni fechaIngreso:
//    los pone adentro (lo que te expliqué ayer). Reglas 1 y 3: bien.
//
// ❌ ERROR L1 - La clase se llama "Taller"
//    QUÉ PASABA: la consigna dice "Entidad: Orden". Con los proyectos bien
//                nombrados (Taller.Domain, Taller.Api...), una clase "Taller"
//                choca con el namespace "Taller" y aparecen errores raros.
//    ✅ CÓMO CORREGIRLO: Ctrl+R, Ctrl+R sobre "Taller" (el de la clase) > "Orden".
// =========================================================================
namespace Taller.Domain;

public sealed class Orden
{
    private Orden(Guid id, string patente, string cliente, decimal presupuesto)
    {
        Id = id;
        Patente = patente;
        Cliente = cliente;
        Presupuesto = presupuesto;
        CostoFinal = 0m;                  // regla 4
        Estado = EstadoOrden.Recibida;    // regla 4
        FechaIngreso = DateTime.UtcNow;   // se carga sola
    }

    public Guid Id { get; }

    // ✅ MEJORA: estos no cambian nunca -> solo { get; } (sacá el "private set").
    public string Patente { get; }
    public string Cliente { get; }
    public decimal Presupuesto { get; }
    public DateTime FechaIngreso { get; }

    // Estos SÍ cambian (al iniciar y al finalizar) -> private set.
    public decimal CostoFinal { get; private set; }
    public EstadoOrden Estado { get; private set; }

    // ---------------------------------------------------------------------
    // ❌ ERROR L2 - Crear seguía recibiendo CostoFinal y FechaIngreso
    //    QUÉ PASABA: los sacaste del constructor (bien), pero quedaron en
    //                Crear. No se usan para nada, y obligan a la API y a las
    //                pruebas a mandar datos que no sirven.
    //    ✅ CÓMO CORREGIRLO: borrá ", decimal CostoFinal, DateTime FechaIngreso"
    //       de los parámetros de Crear. Después compilá: Visual Studio te
    //       marca en rojo los lugares que todavía los mandan (CrearTaller.cs,
    //       Program.cs y las pruebas). Sacalos ahí también.
    //
    // ❌ ERROR L3 - Parámetros con MAYÚSCULA (Patente, Cliente, Presupuesto)
    //    ✅ CÓMO CORREGIRLO: escribilos en minúscula. Los parámetros van en
    //       minúscula; con mayúscula se confunden con las propiedades.
    //    ANTES:  Crear(string Patente, string Cliente, decimal Presupuesto,
    //                  decimal CostoFinal, DateTime FechaIngreso)
    // ---------------------------------------------------------------------
    public static Orden Crear(string patente, string cliente, decimal presupuesto)
    {
        if (string.IsNullOrWhiteSpace(cliente))
            throw new ArgumentException("El cliente es obligatorio.", nameof(cliente));

        if (string.IsNullOrWhiteSpace(patente))
            throw new ArgumentException("La patente es obligatoria.", nameof(patente));

        // -----------------------------------------------------------------
        // ❌ ERROR L4 - Regla 2 incompleta
        //    QUÉ PASABA:
        //      a) Faltaba "no puede tener espacios". Con tu código "AB 123"
        //         (6 caracteres) se aceptaba.
        //      b) Se medía el largo ANTES del Trim: " AB123C " (8 con los
        //         espacios) se rechazaba aunque la patente real tiene 6.
        //    (Tu "Length != 6 && Length != 7" estaba BIEN pensado.)
        //    ✅ CÓMO CORREGIRLO:
        //       1. Guardá la patente limpia:  string patenteLimpia = patente.Trim().ToUpper();
        //       2. Medí el largo de patenteLimpia.
        //       3. Agregá:  if (patenteLimpia.Contains(' ')) throw ...
        //       4. En el return usá patenteLimpia.
        // -----------------------------------------------------------------
        string patenteLimpia = patente.Trim().ToUpper();
        if (patenteLimpia.Length != 6 && patenteLimpia.Length != 7)
            throw new ArgumentException("La patente debe tener 6 o 7 caracteres.", nameof(patente));

        if (patenteLimpia.Contains(' '))
            throw new ArgumentException("La patente no puede tener espacios.", nameof(patente));

        if (presupuesto <= 0)
            throw new ArgumentException("El presupuesto tiene que ser mayor a 0.", nameof(presupuesto));

        return new Orden(Guid.NewGuid(), patenteLimpia, cliente.Trim(), presupuesto);
    }

    // ---------------------------------------------------------------------
    // ❌ ERROR L5 - "Reparar" (el error MÁS IMPORTANTE)
    //    QUÉ PASABA (3 problemas):
    //      a) Validaba "if (FechaIngreso > DateTime.Now)". FechaIngreso se
    //         guarda con UtcNow (hora de Londres = 3 horas MÁS que en
    //         Argentina) y se compara con Now (hora de Argentina). Entonces en
    //         Argentina FechaIngreso SIEMPRE parece "futura" y Reparar tiraba
    //         SIEMPRE este error. Por eso fallaba tu prueba:
    //           Test.UnitTest1.EnReparacion_y_Lista_la_orden
    //           System.ArgumentException : La fecha de ingreso no puede ser
    //           futura. (Parameter 'FechaIngreso')
    //         Además, esa validación no está en la consigna.
    //      b) Validaba "CostoFinal < 0": el costo final es 0 hasta finalizar,
    //         así que esto no sirve acá.
    //      c) Hacía las DOS acciones juntas (igual que Reservar en Fútbol):
    //         pone EnReparacion y en la línea siguiente pregunta
    //         "if (Estado != EnReparacion)", que NUNCA se cumple. Con UNA
    //         llamada pasaba de Recibida a Lista y nunca cargaba el costo.
    //    ✅ CÓMO CORREGIRLO:
    //       1. Borrá los "if" de CostoFinal y FechaIngreso.
    //       2. Partí el método en DOS:
    //            Iniciar()                   -> regla 5
    //            Finalizar(decimal costoFinal) -> regla 6
    //    ANTES:
    //        public void Reparar()
    //        {
    //            if (CostoFinal < 0) throw ...
    //            if (FechaIngreso > DateTime.Now) throw ...
    //            if (Estado != EnumTaller.Recibida) throw ...
    //            Estado = EnumTaller.EnReparacion;
    //            if (Estado != EnumTaller.EnReparacion) throw ...   <- nunca se cumple
    //            Estado = EnumTaller.Lista;
    //        }
    // ---------------------------------------------------------------------

    // REGLA 5
    public void Iniciar()
    {
        if (Estado != EstadoOrden.Recibida)
            throw new InvalidOperationException("Solo se puede iniciar una orden Recibida.");

        Estado = EstadoOrden.EnReparacion;
    }

    // ---------------------------------------------------------------------
    // ❌ ERROR L6 - FALTABA Finalizar (regla 6)
    //    ✅ CÓMO CORREGIRLO: método nuevo que RECIBE el costo final (como
    //       Vender(cantidad) del Almacén) y además chequea el estado (como
    //       Despachar de Pedidos). Orden de las validaciones:
    //       1) estado (si no está en reparación, ni miro el costo)
    //       2) costo > 0
    //       3) costo <= Presupuesto (se compara con la PROPIEDAD)
    // ---------------------------------------------------------------------
    public void Finalizar(decimal costoFinal)
    {
        if (Estado != EstadoOrden.EnReparacion)
            throw new InvalidOperationException("Solo se puede finalizar una orden EnReparacion.");

        if (costoFinal <= 0)
            throw new ArgumentException("El costo final tiene que ser mayor a 0.", nameof(costoFinal));

        if (costoFinal > Presupuesto)
            throw new ArgumentException("El costo final no puede superar el presupuesto.", nameof(costoFinal));

        CostoFinal = costoFinal;
        Estado = EstadoOrden.Lista;
    }
}
