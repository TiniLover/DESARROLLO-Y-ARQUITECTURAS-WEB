// =========================================================================
// DOMINIO - Enum de estados   (ANTES: Domain/EnumTaller.cs)
// ✅ Los 3 estados estaban BIEN escritos.
// ❌ Nombre: "EnumTaller" -> "EstadoOrden" (es el estado de una ORDEN).
//    ✅ CÓMO CORREGIRLO: Ctrl+R, Ctrl+R sobre "EnumTaller" > "EstadoOrden".
// =========================================================================
namespace Taller.Domain;

public enum EstadoOrden
{
    Recibida,
    EnReparacion,
    Lista
}
