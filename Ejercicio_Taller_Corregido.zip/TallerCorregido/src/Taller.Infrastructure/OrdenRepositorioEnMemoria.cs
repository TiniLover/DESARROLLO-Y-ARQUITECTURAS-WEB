// INFRAESTRUCTURA - Repositorio en memoria
// ✅ Estaba BIEN. Solo cambia Taller -> Orden.
using System.Collections.Concurrent;
using Taller.Application.Abstracciones;
using Taller.Domain;

namespace Taller.Infrastructure;

public sealed class OrdenRepositorioEnMemoria : IOrdenRepositorio
{
    private readonly ConcurrentDictionary<Guid, Orden> ordenes = new();

    public Task AddAsync(Orden orden, CancellationToken cancellationToken = default)
    {
        ordenes[orden.Id] = orden;
        return Task.CompletedTask;
    }

    public Task<IReadOnlyCollection<Orden>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        IReadOnlyCollection<Orden> resultado = ordenes.Values.OrderBy(o => o.FechaIngreso).ToArray();
        return Task.FromResult(resultado);
    }

    public Task<Orden?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
    {
        ordenes.TryGetValue(id, out var orden);
        return Task.FromResult(orden);
    }

    public Task UpdateAsync(Orden orden, CancellationToken cancellationToken = default)
    {
        ordenes[orden.Id] = orden;
        return Task.CompletedTask;
    }
}
