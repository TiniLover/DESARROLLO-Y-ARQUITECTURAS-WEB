// =========================================================================
// API - Inyección + endpoints   (ANTES: WebApplication1/Program.cs)
// ✅ ¡Compilaba sin errores! La inyección (Singleton + Scoped) estaba bien.
// =========================================================================
using Taller.Application.Abstracciones;
using Taller.Application.Ordenes;
using Taller.Infrastructure;

// ❌ ERROR L8 - Había unas llaves vacías sueltas acá arriba:
//        {
//
//        }
//    QUÉ PASABA: no da error (es un bloque vacío), pero no hace nada y
//                confunde. Seguramente quedó de borrar algo.
//    ✅ CÓMO CORREGIRLO: borrá esas 3 líneas.

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSingleton<IOrdenRepositorio, OrdenRepositorioEnMemoria>();

// ❌ ERROR L6 - Faltaba registrar FinalizarOrdenUseCase
//    ✅ CÓMO CORREGIRLO: agregá un AddScoped por cada caso de uso nuevo.
builder.Services.AddScoped<CrearOrdenUseCase>();
builder.Services.AddScoped<ListarOrdenesUseCase>();
builder.Services.AddScoped<IniciarOrdenUseCase>();
builder.Services.AddScoped<FinalizarOrdenUseCase>();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// ❌ ERROR L9 - Rutas "/Taller" -> la consigna pide "/ordenes"
//    ✅ CÓMO CORREGIRLO: Ctrl+H, buscar "/Taller", reemplazar "/ordenes".
app.MapGet("/ordenes", async (ListarOrdenesUseCase useCase, CancellationToken ct) =>
    Results.Ok(await useCase.ExecuteAsync(ct)))
.WithName("ListarOrdenes")
.WithOpenApi();

// -------------------------------------------------------------------------
// POST /ordenes
// ❌ ERROR L10 - Los datos se pasaban CRUZADOS (error silencioso, el peor)
//    QUÉ PASABA: el caso de uso pedía (patente, cliente, PRESUPUESTO,
//                COSTOFINAL, ...) y vos le pasabas
//                (request.Patente, request.Cliente, request.CostoFinal,
//                 request.Presupuesto, ...)  <- al revés.
//                Como los dos son decimal, C# NO da error: compila y guarda
//                el costo final en el lugar del presupuesto. Nadie te avisa.
//    ✅ CÓMO CORREGIRLO: pasá SOLO los 3 datos, en el MISMO orden que pide
//       ExecuteAsync: (request.Patente, request.Cliente, request.Presupuesto, ct).
//    TRUCO: si dudás del orden, pasá el mouse sobre "ExecuteAsync" y Visual
//           Studio te muestra los parámetros en orden.
//    ANTES:  useCase.ExecuteAsync(request.Patente, request.Cliente, request.CostoFinal,
//                                 request.Presupuesto, request.Estado, request.FechaIngreso, ct);
// -------------------------------------------------------------------------
app.MapPost("/ordenes", async (CrearOrdenRequest request, CrearOrdenUseCase useCase, CancellationToken ct) =>
{
    try
    {
        var orden = await useCase.ExecuteAsync(request.Patente, request.Cliente, request.Presupuesto, ct);
        return Results.Created($"/ordenes/{orden.Id}", orden);           // 201
    }
    catch (ArgumentException ex)
    {
        return Results.BadRequest(new { error = ex.Message });          // 400
    }
})
.WithName("CrearOrden")
.WithOpenApi();

// -------------------------------------------------------------------------
// POST /ordenes/{id}/iniciar
// ❌ ERROR L9 - Ruta "/confirmar" y nombre "ConfirmarTaller" (copiados de Fútbol)
//    ✅ CÓMO CORREGIRLO: "/confirmar" -> "/iniciar"; "Reparar" -> "IniciarOrdenUseCase";
//       .WithName("IniciarOrden"). Variable "reserva" -> "orden".
// -------------------------------------------------------------------------
app.MapPost("/ordenes/{id:guid}/iniciar", async (Guid id, IniciarOrdenUseCase useCase, CancellationToken ct) =>
{
    try
    {
        var orden = await useCase.ExecuteAsync(id, ct);
        return orden is null
            ? Results.NotFound(new { error = "No existe una orden con ese Id." })   // 404
            : Results.Ok(orden);                                                     // 200
    }
    catch (InvalidOperationException ex)
    {
        return Results.BadRequest(new { error = ex.Message });                      // 400
    }
})
.WithName("IniciarOrden")
.WithOpenApi();

// -------------------------------------------------------------------------
// POST /ordenes/{id}/finalizar   { "costoFinal": 230000 }
// ❌ ERROR L6 + L9 - Era "/cancelar" (de Fútbol) y llamaba otra vez a Reparar
//    QUÉ PASABA: los dos endpoints hacían lo mismo, y no había forma de
//                cargar el costo final.
//    ✅ CÓMO CORREGIRLO:
//       1. Ruta "/finalizar".
//       2. Recibe un "FinalizarRequest request" (el costo viene en el JSON),
//          además del id de la ruta. Igual que Vender del Almacén.
//       3. Llama a FinalizarOrdenUseCase con (id, request.CostoFinal, ct).
//       4. Atrapa las DOS excepciones: ArgumentException (costo mal cargado)
//          e InvalidOperationException (no estaba EnReparacion).
// -------------------------------------------------------------------------
app.MapPost("/ordenes/{id:guid}/finalizar", async (
    Guid id, FinalizarRequest request, FinalizarOrdenUseCase useCase, CancellationToken ct) =>
{
    try
    {
        var orden = await useCase.ExecuteAsync(id, request.CostoFinal, ct);
        return orden is null
            ? Results.NotFound(new { error = "No existe una orden con ese Id." })   // 404
            : Results.Ok(orden);                                                     // 200
    }
    catch (ArgumentException ex)            // costo <= 0 o mayor al presupuesto
    {
        return Results.BadRequest(new { error = ex.Message });
    }
    catch (InvalidOperationException ex)    // no estaba EnReparacion
    {
        return Results.BadRequest(new { error = ex.Message });
    }
})
.WithName("FinalizarOrden")
.WithOpenApi();

app.Run();

// -------------------------------------------------------------------------
// DTOs DE ENTRADA
// ❌ ERROR L2 + L9 - "CrearReservaRequest" con 6 datos
//    QUÉ PASABA: se llamaba como el de Fútbol, y pedía FechaIngreso,
//                CostoFinal y Estado, que el cliente NO tiene que mandar.
//                (En Swagger aparecían esos campos para completar.)
//    ✅ CÓMO CORREGIRLO: renombralo CrearOrdenRequest y dejá solo 3 datos.
//    ANTES:  record CrearReservaRequest(string Patente, string Cliente, DateTime FechaIngreso,
//                                       decimal CostoFinal, decimal Presupuesto, EnumTaller Estado);
// -------------------------------------------------------------------------
public sealed record CrearOrdenRequest(string Patente, string Cliente, decimal Presupuesto);

// ❌ ERROR L6 - FALTABA: el JSON de finalizar { "costoFinal": 230000 }
public sealed record FinalizarRequest(decimal CostoFinal);
