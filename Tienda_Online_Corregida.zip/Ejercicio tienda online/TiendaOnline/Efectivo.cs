﻿using System;

namespace TiendaOnline
{
    // Subclase concreta: NO sobrescribe ningún hook.
    //   - DatoRequerido queda en null  -> no pide datos
    //   - CuotasPermitidas queda en null -> no pregunta cuotas
    // Solo completa lo obligatorio (pasos 3 y 4).
    public class Efectivo : MedioDePago
    {
        public override string Nombre => "Efectivo";

        // PASO 3: 15% de descuento
        protected override decimal CalcularMontoFinal(decimal monto)
        {
            Console.WriteLine("Se aplica un 15% de descuento por pago en efectivo.");
            return monto * 0.85m;
        }

        // PASO 4
        protected override void ProcesarPago(decimal montoFinal)
        {
            Console.WriteLine("Pague en caja al retirar el producto.");
        }
    }
}
