﻿using System;

namespace TiendaOnline
{
    // Subclase concreta: completa los pasos abstractos y sobrescribe los
    // hooks que necesita (datos y cuotas).
    public class TarjetaDeCredito : MedioDePago
    {
        public override string Nombre => "Tarjeta de crédito";

        // Hooks del paso 2
        protected override string DatoRequerido => "número de tarjeta (16 dígitos)";

        protected override bool DatoValido(string dato)
        {
            return TieneDigitos(dato, 16);
        }

        // Hook del desafío: la tarjeta permite cuotas.
        protected override int[] CuotasPermitidas => new[] { 1, 3, 6 };

        // PASO 3: 10% de recargo
        protected override decimal CalcularMontoFinal(decimal monto)
        {
            Console.WriteLine("Se aplica un 10% de recargo por pago con tarjeta.");
            return monto * 1.10m;
        }

        // PASO 4
        protected override void ProcesarPago(decimal montoFinal)
        {
            Console.WriteLine("Conectando con el banco emisor... Pago aprobado.");
        }
    }
}
