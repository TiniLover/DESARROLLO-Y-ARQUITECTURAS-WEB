﻿using System;
using System.Text;

namespace TiendaOnline
{
    // =====================================================================
    // PROGRAMA PRINCIPAL
    // El usuario elige el medio de pago UNA vez (acá) y se llama al
    // MÉTODO PLANTILLA ProcesarCompra(). El flujo es siempre el mismo.
    // =====================================================================
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            MedioDePago[] medios =
            {
                new TarjetaDeCredito(),
                new Transferencia(),
                new Efectivo()
            };

            while (true)
            {
                Console.WriteLine();
                Console.WriteLine("===== TIENDA ONLINE: ELEGÍ TU MEDIO DE PAGO =====");
                for (int i = 0; i < medios.Length; i++)
                {
                    Console.WriteLine($"{i + 1}. {medios[i].Nombre}");
                }
                Console.WriteLine("0. Salir");
                Console.Write("Opción: ");

                string entrada = Console.ReadLine() ?? "";

                if (entrada == "0")
                {
                    Console.WriteLine("¡Hasta la próxima!");
                    break;
                }

                if (int.TryParse(entrada, out int opcion) && opcion >= 1 && opcion <= medios.Length)
                {
                    // Template Method: el mismo llamado para cualquier medio.
                    medios[opcion - 1].ProcesarCompra();
                }
                else
                {
                    Console.WriteLine("Opción inválida.");
                }
            }
        }
    }
}
