﻿using System;

namespace TiendaOnline
{
    // Subclase concreta: pide CBU, no permite cuotas (no sobrescribe ese hook).
    public class Transferencia : MedioDePago
    {
        public override string Nombre => "Transferencia";

        // Hooks del paso 2
        protected override string DatoRequerido => "CBU (22 dígitos)";

        protected override bool DatoValido(string dato)
        {
            return TieneDigitos(dato, 22);
        }

        // PASO 3: 5% de descuento
        protected override decimal CalcularMontoFinal(decimal monto)
        {
            Console.WriteLine("Se aplica un 5% de descuento por pago con transferencia.");
            return monto * 0.95m;
        }

        // PASO 4
        protected override void ProcesarPago(decimal montoFinal)
        {
            Console.WriteLine("Esperando acreditación de la transferencia... Pago recibido.");
        }
    }
}
