﻿using System;
using System.Linq;

namespace TiendaOnline
{
    // =====================================================================
    // PATRÓN TEMPLATE METHOD — CLASE ABSTRACTA
    // ---------------------------------------------------------------------
    // ¿Por qué Template Method?
    //   Todos los medios de pago siguen el MISMO flujo y en el MISMO orden:
    //     1. Mostrar el resumen de la compra          (fijo)
    //     2. Pedir y validar los datos del medio      (cambia: hooks)
    //     3. Calcular el monto final                  (cambia: abstracto)
    //     4. Procesar el pago                         (cambia: abstracto)
    //     5. Emitir el comprobante                    (fijo)
    //   El flujo se escribe UNA vez acá y cada medio completa solo lo suyo.
    // =====================================================================
    public abstract class MedioDePago
    {
        // Datos de la compra: son de la COMPRA, no del medio de pago,
        // por eso están acá (iguales para todos) y no en cada subclase.
        protected const string Producto = "Auriculares inalámbricos";
        protected const decimal MontoCompra = 10000m;

        // -----------------------------------------------------------------
        // MÉTODO PLANTILLA: público y NO virtual (nadie cambia el orden).
        // -----------------------------------------------------------------
        public void ProcesarCompra()
        {
            MostrarResumen();                                       // 1. fijo
            PedirYValidarDatos();                                   // 2. fijo, usa hooks
            decimal montoFinal = CalcularMontoFinal(MontoCompra);   // 3. abstracto (devuelve el monto)
            int cuotas = PedirCuotas();                             // desafío: hook (por defecto 1)
            ProcesarPago(montoFinal);                               // 4. abstracto
            EmitirComprobante(montoFinal, cuotas);                  // 5. fijo, usa el monto del paso 3
        }

        // ------------- OBLIGATORIO PARA CADA MEDIO (abstract) -------------
        public abstract string Nombre { get; }

        // PASO 3: recibe el monto de la compra y devuelve el monto final
        // con el recargo o descuento de este medio.
        protected abstract decimal CalcularMontoFinal(decimal monto);

        // PASO 4: cómo se procesa el pago con este medio.
        protected abstract void ProcesarPago(decimal montoFinal);

        // ------------- OPCIONAL (hooks: virtual con valor por defecto) -------------

        // Qué dato pide este medio. null = no pide datos (ej: efectivo).
        protected virtual string DatoRequerido => null;

        // Si el dato ingresado es válido. Por defecto, todo es válido.
        protected virtual bool DatoValido(string dato)
        {
            return true;
        }

        // Cuotas que acepta este medio. null = no permite cuotas.
        protected virtual int[] CuotasPermitidas => null;

        // ------------- PASOS FIJOS (private) -------------

        // PASO 1
        private void MostrarResumen()
        {
            Console.WriteLine();
            Console.WriteLine($"===== RESUMEN DE COMPRA =====");
            Console.WriteLine($"Producto: {Producto}");
            Console.WriteLine($"Monto: ${MontoCompra:N2}");
            Console.WriteLine($"Medio de pago: {Nombre}");
        }

        // PASO 2: el algoritmo de "pedir hasta que sea válido" es el mismo
        // para todos; QUÉ se pide y CÓMO se valida lo define cada medio (hooks).
        private void PedirYValidarDatos()
        {
            if (DatoRequerido == null)
            {
                Console.WriteLine("Este medio de pago no requiere datos.");
                return;
            }

            while (true)
            {
                Console.Write($"Ingresá el {DatoRequerido}: ");
                string dato = (Console.ReadLine() ?? "").Trim();
                if (DatoValido(dato))
                {
                    Console.WriteLine("Datos válidos.");
                    return;
                }
                Console.WriteLine("Datos inválidos. Intentá de nuevo.");
            }
        }

        // DESAFÍO: pide cuotas solo si el medio las permite.
        private int PedirCuotas()
        {
            if (CuotasPermitidas == null)
            {
                return 1;
            }

            while (true)
            {
                Console.Write($"¿En cuántas cuotas? ({string.Join(", ", CuotasPermitidas)}): ");
                if (int.TryParse(Console.ReadLine(), out int cuotas) && CuotasPermitidas.Contains(cuotas))
                {
                    return cuotas;
                }
                Console.WriteLine("Cantidad de cuotas inválida.");
            }
        }

        // PASO 5: comprobante común con el monto final.
        private void EmitirComprobante(decimal montoFinal, int cuotas)
        {
            Console.WriteLine("--------- COMPROBANTE ---------");
            Console.WriteLine($"Producto: {Producto}");
            Console.WriteLine($"Medio de pago: {Nombre}");
            Console.WriteLine($"Monto original: ${MontoCompra:N2}");
            Console.WriteLine($"Monto final: ${montoFinal:N2}");
            if (cuotas > 1)
            {
                Console.WriteLine($"{cuotas} cuotas de ${montoFinal / cuotas:N2}");
            }
            Console.WriteLine("¡Gracias por tu compra!");
        }

        // Ayuda para las subclases: true si el texto tiene exactamente N dígitos.
        protected static bool TieneDigitos(string texto, int cantidad)
        {
            return texto.Length == cantidad && texto.All(char.IsDigit);
        }
    }
}
