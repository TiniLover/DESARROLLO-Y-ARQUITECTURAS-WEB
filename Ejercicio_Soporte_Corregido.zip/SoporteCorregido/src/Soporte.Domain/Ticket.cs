// =========================================================================
// DOMINIO - Entidad Ticket   (ANTES: Domain/Ticket.cs)
// -------------------------------------------------------------------------
// ✅ BIEN: IniciarTicket (regla 5) estaba perfecto, el título se valida, y
//    adentro del constructor ponés HorasTrabajadas = 0 y Estado = Abierto.
// =========================================================================
namespace Soporte.Domain;

public sealed class Ticket
{
    // ---------------------------------------------------------------------
    // ❌ ERROR L1 - El constructor tenía parámetros que no usaba
    //    QUÉ PASABA: recibía horasTrabajadas, estado y fechaCreacion, pero
    //                adentro ponías HorasTrabajadas = 0 y Estado = Abierto
    //                (bien) sin usar esos parámetros. Quedan de adorno y
    //                obligan a pasarlos en el "return new".
    //    ✅ CÓMO CORREGIRLO: borrá "decimal horasTrabajadas, EnumEstado estado,
    //       DateTime fechaCreacion" del constructor; FechaCreacion se pone
    //       adentro con DateTime.Now.
    //
    // ❌ ERROR L2 - Sobraba "cliente"
    //    QUÉ PASABA: la consigna no tiene "Cliente" (quedó copiado del
    //                Taller). El ticket solo tiene Solicitante.
    //    ✅ CÓMO CORREGIRLO: borrá el parámetro, la propiedad Cliente y su "if".
    //       Después compilá: Visual Studio te marca dónde más se usa.
    //    (Detalle: "fehaLimite" estaba mal escrito -> "fechaLimite".)
    //
    //    ANTES: private Ticket(Guid id, string titulo, string cliente, string solicitante,
    //                          DateTime fehaLimite, decimal horasTrabajadas,
    //                          EnumEstado estado, DateTime fechaCreacion)
    // ---------------------------------------------------------------------
    private Ticket(Guid id, string titulo, string solicitante, DateTime fechaLimite)
    {
        Id = id;
        Titulo = titulo;
        Solicitante = solicitante;
        FechaLimite = fechaLimite;
        HorasTrabajadas = 0m;               // regla 4
        Estado = EstadoTicket.Abierto;      // regla 4
        FechaCreacion = DateTime.Now;       // se carga sola
    }

    public Guid Id { get; }

    // ✅ MEJORA: estos no cambian -> solo { get; }
    public string Titulo { get; }
    public string Solicitante { get; }
    public DateTime FechaLimite { get; }
    public DateTime FechaCreacion { get; }

    // Estos SÍ cambian -> private set
    public decimal HorasTrabajadas { get; private set; }
    public EstadoTicket Estado { get; private set; }

    // ---------------------------------------------------------------------
    // ❌ ERROR L3 - Crear NO recibía la fecha límite (el más importante de Crear)
    //    QUÉ PASABA: en el "return new" pasabas DateTime.MinValue, que es
    //                01/01/0001. TODOS los tickets quedaban con fecha límite
    //                año 1, y la regla 3 (fecha futura) nunca se validaba.
    //    ✅ CÓMO CORREGIRLO:
    //       1. Agregá "DateTime fechaLimite" a los parámetros de Crear.
    //       2. Validá:  if (fechaLimite <= DateTime.Now) throw ...
    //       3. En el return pasá "fechaLimite" en vez de DateTime.MinValue.
    //
    // ❌ ERROR L4 - Crear recibía "horasTrabajadas" (y "cliente", ver L2)
    //    QUÉ PASABA: las horas se cargan al CERRAR, no al crear (regla 4:
    //                arranca en 0). Ese parámetro no se usaba.
    //    ✅ CÓMO CORREGIRLO: borralo.
    //
    //    ANTES: Crear(string titulo, string cliente, string solicitante, decimal horasTrabajadas)
    // ---------------------------------------------------------------------
    public static Ticket Crear(string titulo, string solicitante, DateTime fechaLimite)
    {
        // Regla 1
        if (string.IsNullOrWhiteSpace(titulo))
            throw new ArgumentException("El título es obligatorio.", nameof(titulo));

        if (string.IsNullOrWhiteSpace(solicitante))
            throw new ArgumentException("El solicitante es obligatorio.", nameof(solicitante));

        // Regla 2  (✅ estaba bien; solo se agrega Trim() antes de medir,
        //           para que "   Ayuda    " no cuente los espacios)
        if (titulo.Trim().Length < 10)
            throw new ArgumentException("El título debe tener al menos 10 caracteres.", nameof(titulo));

        // Regla 3 (❌ FALTABA, ver L3) - con DateTime.Now, como vimos hoy
        if (fechaLimite <= DateTime.Now)
            throw new ArgumentException("La fecha límite tiene que ser futura.", nameof(fechaLimite));

        return new Ticket(Guid.NewGuid(), titulo.Trim(), solicitante.Trim(), fechaLimite);
    }

    // ---------------------------------------------------------------------
    // REGLA 5 - ✅ Estaba PERFECTO. Solo el nombre: la consigna dice "tomar".
    //    ANTES: IniciarTicket()  ->  AHORA: Tomar()
    // ---------------------------------------------------------------------
    public void Tomar()
    {
        if (Estado != EstadoTicket.Abierto)
            throw new InvalidOperationException("Solo se puede tomar un ticket Abierto.");

        Estado = EstadoTicket.EnProgreso;
    }

    // ---------------------------------------------------------------------
    // ❌ ERROR L5 - CerrarTicket (el MÁS IMPORTANTE del ejercicio)
    //    QUÉ PASABA (4 problemas):
    //      a) El parámetro se llamaba "v" y era INT. Las horas pueden ser
    //         3,5 -> tiene que ser decimal. Encima el caso de uso hacía
    //         "(int)horasTrabajadas": 3,5 horas se guardaban como 3.
    //      b) Validaba la PROPIEDAD HorasTrabajadas (que vale 0) en vez del
    //         parámetro "v". O sea: validaba el dato viejo, no el nuevo.
    //         Por eso cerrar con 50 horas NO daba error.
    //      c) NUNCA guardaba las horas: faltaba "HorasTrabajadas = ...".
    //         Todos los tickets cerrados quedaban con 0 horas.
    //      d) Usaba "< 0": la regla dice "mayores a 0" -> "<= 0".
    //    (Visual Studio te lo marcaba en gris: el parámetro "v" sin usar.)
    //    ✅ CÓMO CORREGIRLO:
    //       1. Cambiá "int v" por "decimal horasTrabajadas".
    //       2. Primero el estado (si no está EnProgreso, ni miro las horas).
    //       3. En los "if" usá el PARÁMETRO horasTrabajadas (minúscula),
    //          no la propiedad HorasTrabajadas (mayúscula).
    //       4. Antes de cambiar el estado, guardá:  HorasTrabajadas = horasTrabajadas;
    //       5. En CerrarTickets.cs, sacá el "(int)".
    //    TRUCO: parámetro en minúscula = el dato que LLEGA;
    //           propiedad en Mayúscula = el dato que YA TIENE el objeto.
    //    ANTES:
    //        public void CerrarTicket(int v)
    //        {
    //            if (HorasTrabajadas < 0 || HorasTrabajadas > 40) throw ...
    //            if (Estado != EnumEstado.EnProgreso) throw ...
    //            Estado = EnumEstado.Cerrado;
    //        }
    // ---------------------------------------------------------------------
    public void Cerrar(decimal horasTrabajadas)
    {
        if (Estado != EstadoTicket.EnProgreso)
            throw new InvalidOperationException("Solo se puede cerrar un ticket EnProgreso.");

        if (horasTrabajadas <= 0 || horasTrabajadas > 40)
            throw new ArgumentException("Las horas trabajadas tienen que ser mayores a 0 y no pueden superar 40.", nameof(horasTrabajadas));

        HorasTrabajadas = horasTrabajadas;   // ← esto faltaba
        Estado = EstadoTicket.Cerrado;
    }
}
