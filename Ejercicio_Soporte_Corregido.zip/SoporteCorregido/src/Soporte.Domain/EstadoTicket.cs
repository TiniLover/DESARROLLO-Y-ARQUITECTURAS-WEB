// =========================================================================
// DOMINIO - Enum   (ANTES: Domain/EnumEstado.cs)
// ✅ Los 3 estados estaban bien.
// ❌ Nombre: "EnumEstado" -> "EstadoTicket" (Ctrl+R, Ctrl+R).
//    (Detalle: conviene ponerlos en el orden en que pasan:
//     Abierto -> EnProgreso -> Cerrado. No da error, pero se lee mejor.)
// =========================================================================
namespace Soporte.Domain;

public enum EstadoTicket
{
    Abierto,
    EnProgreso,
    Cerrado
}
