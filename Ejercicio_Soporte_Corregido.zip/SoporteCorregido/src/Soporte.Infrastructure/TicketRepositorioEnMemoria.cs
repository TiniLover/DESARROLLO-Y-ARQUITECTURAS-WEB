// INFRAESTRUCTURA - Repositorio en memoria   (✅ estaba BIEN)
using System.Collections.Concurrent;
using Soporte.Application.Abstracciones;
using Soporte.Domain;

namespace Soporte.Infrastructure;

public sealed class TicketRepositorioEnMemoria : ITicketRepositorio
{
    private readonly ConcurrentDictionary<Guid, Ticket> tickets = new();

    public Task AddAsync(Ticket ticket, CancellationToken cancellationToken = default)
    {
        tickets[ticket.Id] = ticket;
        return Task.CompletedTask;
    }

    public Task<IReadOnlyCollection<Ticket>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        IReadOnlyCollection<Ticket> resultado = tickets.Values.OrderBy(t => t.FechaCreacion).ToArray();
        return Task.FromResult(resultado);
    }

    public Task<Ticket?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
    {
        tickets.TryGetValue(id, out var ticket);
        return Task.FromResult(ticket);
    }

    public Task UpdateAsync(Ticket ticket, CancellationToken cancellationToken = default)
    {
        tickets[ticket.Id] = ticket;
        return Task.CompletedTask;
    }
}
