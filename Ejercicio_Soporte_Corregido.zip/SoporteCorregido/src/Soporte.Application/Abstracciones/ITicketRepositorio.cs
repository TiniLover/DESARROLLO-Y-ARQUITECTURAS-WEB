// APLICACIÓN - Interfaz del repositorio   (✅ estaba BIEN)
using Soporte.Domain;

namespace Soporte.Application.Abstracciones;

public interface ITicketRepositorio
{
    Task AddAsync(Ticket ticket, CancellationToken cancellationToken = default);
    Task<IReadOnlyCollection<Ticket>> GetAllAsync(CancellationToken cancellationToken = default);
    Task<Ticket?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default);
    Task UpdateAsync(Ticket ticket, CancellationToken cancellationToken = default);
}
