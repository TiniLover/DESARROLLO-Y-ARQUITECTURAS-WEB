// =========================================================================
// APLICACIÓN - DTO   (ANTES: TicketDTO.cs)
// ❌ ERROR L6
//    QUÉ PASABA:
//      - Tenía "Cliente" (sobra, ver L2).
//      - Estado como enum (Swagger muestra un número).
//      - Se llamaba "FechaIngreso" (del Taller), pero en la entidad es
//        FechaCreacion: el nombre del DTO tiene que coincidir.
//    ✅ CÓMO CORREGIRLO: sacá Cliente, "EnumEstado Estado" -> "string Estado",
//       "FechaIngreso" -> "FechaCreacion". En el mapeo: Estado.ToString().
// =========================================================================
namespace Soporte.Application.Tickets;

public sealed record TicketDto(
    Guid Id,
    string Titulo,
    string Solicitante,
    DateTime FechaLimite,
    decimal HorasTrabajadas,
    string Estado,
    DateTime FechaCreacion);
