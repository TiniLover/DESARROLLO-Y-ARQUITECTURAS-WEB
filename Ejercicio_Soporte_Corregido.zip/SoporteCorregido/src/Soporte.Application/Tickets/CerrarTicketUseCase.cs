// =========================================================================
// APLICACIÓN - Cerrar   (ANTES: CerrarTickets.cs)
// ❌ ERROR L5 (parte) - "ticket.CerrarTicket((int)horasTrabajadas)"
//    QUÉ PASABA: el "(int)" convierte a número ENTERO cortando los
//                decimales: 3,5 horas -> 3. Pusiste el (int) porque el
//                método del Dominio pedía int: el arreglo era cambiar el
//                método a decimal, no convertir acá.
//    ✅ CÓMO CORREGIRLO: sacá el "(int)" -> ticket.Cerrar(horasTrabajadas).
// =========================================================================
using Soporte.Application.Abstracciones;

namespace Soporte.Application.Tickets;

public sealed class CerrarTicketUseCase(ITicketRepositorio repositorio)
{
    public async Task<TicketDto?> ExecuteAsync(Guid id, decimal horasTrabajadas, CancellationToken cancellationToken = default)
    {
        var ticket = await repositorio.GetByIdAsync(id, cancellationToken);
        if (ticket is null)
            return null;

        ticket.Cerrar(horasTrabajadas);

        await repositorio.UpdateAsync(ticket, cancellationToken);
        return ticket.ToDto();
    }
}
