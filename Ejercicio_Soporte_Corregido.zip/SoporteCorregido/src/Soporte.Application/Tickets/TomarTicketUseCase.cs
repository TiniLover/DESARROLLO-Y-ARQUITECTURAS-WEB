// APLICACIÓN - Tomar   (ANTES: IniciarTickets.cs)
// ✅ Estaba BIEN. Solo los nombres: IniciarTickets -> TomarTicketUseCase,
//    ticket.IniciarTicket() -> ticket.Tomar().
using Soporte.Application.Abstracciones;

namespace Soporte.Application.Tickets;

public sealed class TomarTicketUseCase(ITicketRepositorio repositorio)
{
    public async Task<TicketDto?> ExecuteAsync(Guid id, CancellationToken cancellationToken = default)
    {
        var ticket = await repositorio.GetByIdAsync(id, cancellationToken);
        if (ticket is null)
            return null;

        ticket.Tomar();

        await repositorio.UpdateAsync(ticket, cancellationToken);
        return ticket.ToDto();
    }
}
