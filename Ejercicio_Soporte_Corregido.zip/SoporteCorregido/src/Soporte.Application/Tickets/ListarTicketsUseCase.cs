// APLICACIÓN - Listar   (✅ estaba BIEN)
using Soporte.Application.Abstracciones;

namespace Soporte.Application.Tickets;

public sealed class ListarTicketsUseCase(ITicketRepositorio repositorio)
{
    public async Task<IReadOnlyCollection<TicketDto>> ExecuteAsync(CancellationToken cancellationToken = default)
    {
        var tickets = await repositorio.GetAllAsync(cancellationToken);
        return tickets.Select(t => t.ToDto()).ToArray();
    }
}
