// =========================================================================
// APLICACIÓN - Crear   (ANTES: CrearTicket.cs)
// ❌ ERROR L3 + L4 - Recibía cliente y horasTrabajadas, y no la fecha límite
//    ✅ CÓMO CORREGIRLO: (titulo, solicitante, fechaLimite, ct) y llamar a
//       Ticket.Crear con esos 3 datos.
// (Detalle: devolvía "TicketDTO?" con "?". Crear SIEMPRE devuelve un ticket
//  o lanza error; nunca null -> va sin "?".)
// =========================================================================
using Soporte.Application.Abstracciones;
using Soporte.Domain;

namespace Soporte.Application.Tickets;

public sealed class CrearTicketUseCase(ITicketRepositorio repositorio)
{
    public async Task<TicketDto> ExecuteAsync(string titulo, string solicitante, DateTime fechaLimite,
        CancellationToken cancellationToken = default)
    {
        var ticket = Ticket.Crear(titulo, solicitante, fechaLimite);
        await repositorio.AddAsync(ticket, cancellationToken);
        return ticket.ToDto();
    }
}
