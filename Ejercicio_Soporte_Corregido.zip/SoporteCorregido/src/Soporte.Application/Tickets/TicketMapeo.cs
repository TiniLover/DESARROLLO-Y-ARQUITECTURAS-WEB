// APLICACIÓN - Mapeo   (✅ estaba bien; cambios por L6: sin Cliente y Estado.ToString())
using Soporte.Domain;

namespace Soporte.Application.Tickets;

internal static class TicketMapeo
{
    public static TicketDto ToDto(this Ticket ticket) =>
        new(ticket.Id, ticket.Titulo, ticket.Solicitante, ticket.FechaLimite,
            ticket.HorasTrabajadas, ticket.Estado.ToString(), ticket.FechaCreacion);
}
