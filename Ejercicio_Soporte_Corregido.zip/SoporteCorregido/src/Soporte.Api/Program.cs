// =========================================================================
// API   (ANTES: WebApplication1/Program.cs)
// ✅ ¡Compilaba sin errores! Inyección (Singleton + 4 Scoped): bien.
//    Los catch de Cerrar (ArgumentException + InvalidOperationException): bien.
// =========================================================================
using Soporte.Application.Abstracciones;
using Soporte.Application.Tickets;
using Soporte.Infrastructure;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSingleton<ITicketRepositorio, TicketRepositorioEnMemoria>();

builder.Services.AddScoped<CrearTicketUseCase>();
builder.Services.AddScoped<ListarTicketsUseCase>();
builder.Services.AddScoped<TomarTicketUseCase>();
builder.Services.AddScoped<CerrarTicketUseCase>();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// ❌ ERROR L7 - Rutas
//    QUÉ PASABA: "/Tickets" con mayúscula (la consigna dice "/tickets"),
//                "/Iniciar" (la consigna dice "/tomar") y, lo más grave,
//                el de cerrar decía "/Ticket/..." en SINGULAR: una ruta
//                distinta a las otras. Quien use la API se confunde.
//    ✅ CÓMO CORREGIRLO: todas en minúscula y plural: /tickets, /tickets/{id}/tomar,
//       /tickets/{id}/cerrar.
app.MapGet("/tickets", async (ListarTicketsUseCase useCase, CancellationToken ct) =>
    Results.Ok(await useCase.ExecuteAsync(ct)))
.WithName("ListarTickets")
.WithOpenApi();

// -------------------------------------------------------------------------
// POST /tickets
// ❌ ERROR L3 + L4 - Se mandaban Cliente y HorasTrabajadas, y faltaba FechaLimite
//    ✅ CÓMO CORREGIRLO: (request.Titulo, request.Solicitante, request.FechaLimite, ct)
//    ANTES:  useCase.ExecuteAsync(request.Titulo, request.Cliente, request.Solicitante,
//                                 request.HorasTrabajadas, ct);
// -------------------------------------------------------------------------
app.MapPost("/tickets", async (CrearTicketRequest request, CrearTicketUseCase useCase, CancellationToken ct) =>
{
    try
    {
        var ticket = await useCase.ExecuteAsync(request.Titulo, request.Solicitante, request.FechaLimite, ct);
        return Results.Created($"/tickets/{ticket.Id}", ticket);          // 201
    }
    catch (ArgumentException ex)
    {
        return Results.BadRequest(new { error = ex.Message });           // 400
    }
})
.WithName("CrearTicket")
.WithOpenApi();

// POST /tickets/{id}/tomar   (✅ estaba bien; solo ruta y nombres, L7)
app.MapPost("/tickets/{id:guid}/tomar", async (Guid id, TomarTicketUseCase useCase, CancellationToken ct) =>
{
    try
    {
        var ticket = await useCase.ExecuteAsync(id, ct);
        return ticket is null
            ? Results.NotFound(new { error = "No existe un ticket con ese Id." })   // 404
            : Results.Ok(ticket);                                                    // 200
    }
    catch (InvalidOperationException ex)
    {
        return Results.BadRequest(new { error = ex.Message });                      // 400
    }
})
.WithName("TomarTicket")
.WithOpenApi();

// POST /tickets/{id}/cerrar   { "horasTrabajadas": 3.5 }
// (✅ la estructura estaba bien; ruta en plural y record renombrado, L7/L8)
app.MapPost("/tickets/{id:guid}/cerrar", async (
    Guid id, CerrarTicketRequest request, CerrarTicketUseCase useCase, CancellationToken ct) =>
{
    try
    {
        var ticket = await useCase.ExecuteAsync(id, request.HorasTrabajadas, ct);
        return ticket is null
            ? Results.NotFound(new { error = "No existe un ticket con ese Id." })   // 404
            : Results.Ok(ticket);                                                    // 200
    }
    catch (ArgumentException ex)            // horas <= 0 o > 40
    {
        return Results.BadRequest(new { error = ex.Message });
    }
    catch (InvalidOperationException ex)    // no estaba EnProgreso
    {
        return Results.BadRequest(new { error = ex.Message });
    }
})
.WithName("CerrarTicket")
.WithOpenApi();

app.Run();

// -------------------------------------------------------------------------
// ❌ ERROR L3 + L4 - El request de crear
//    ANTES:  record CrearTicketRequest(string Titulo, string Cliente,
//                                      string Solicitante, decimal HorasTrabajadas);
//    ✅ CÓMO CORREGIRLO: sacá Cliente y HorasTrabajadas; agregá DateTime FechaLimite.
// -------------------------------------------------------------------------
public sealed record CrearTicketRequest(string Titulo, string Solicitante, DateTime FechaLimite);

// -------------------------------------------------------------------------
// ❌ ERROR L8 - "FinalizarRequest(decimal horasTrabajadas)"
//    QUÉ PASABA: el nombre quedó del Taller, y el parámetro en minúscula.
//    ✅ CÓMO CORREGIRLO: CerrarTicketRequest(decimal HorasTrabajadas).
// -------------------------------------------------------------------------
public sealed record CerrarTicketRequest(decimal HorasTrabajadas);
