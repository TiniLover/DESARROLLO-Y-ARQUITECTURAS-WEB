// =========================================================================
// PRUEBAS   (ANTES: Test/Test.cs)
// -------------------------------------------------------------------------
// Compilaban, pero al ejecutarlas (Ctrl+R, A) 4 de 6 FALLABAN:
//   Con error! - Con error: 4, Superado: 2, Total: 6
//
// ❌ ERROR L9 - Los nombres de las pruebas eran del Taller
//    ("Crear_con_patente_con_espacio", "Finalizar_una_orden_recibida") y no
//    probaban lo que pide ESTA consigna.
//    ✅ CÓMO CORREGIRLO: escribí cada prueba leyendo la lista "Pruebas mínimas".
// =========================================================================
using Soporte.Application.Abstracciones;
using Soporte.Application.Tickets;
using Soporte.Domain;

namespace Soporte.Tests;

public sealed class TicketTests
{
    private static DateTime FechaFutura => DateTime.Now.AddDays(7);

    // ---------------------------------------------------------------------
    // Prueba 1 de la consigna: título de menos de 10 caracteres
    // ❌ ERROR P1 - Tu prueba "Crear_con_patente_con_espacio" FALLABA:
    //      Assert.Throws() Failure: No exception was thrown
    //    QUÉ PASABA: "Electromecanico" tiene 15 letras (es VÁLIDO) y el resto
    //                de los datos también. Con datos válidos no hay error.
    //    ✅ CÓMO CORREGIRLO: usá un título corto como pide la consigna: "Ayuda".
    // ---------------------------------------------------------------------
    [Fact]
    public void Crear_con_titulo_corto_lanza_excepcion()
    {
        Assert.Throws<ArgumentException>(() => Ticket.Crear("Ayuda", "Carla Vega", FechaFutura));
    }

    // ---------------------------------------------------------------------
    // Prueba 2 de la consigna: fecha límite de ayer
    // ❌ ERROR P2 - Tu prueba "Crear_con_horas_mayores_a_40" FALLABA:
    //      Assert.Throws() Failure: No exception was thrown
    //    QUÉ PASABA: era IGUAL a la prueba 1 (copiada) y le pasaba 45 horas a
    //                Crear. Pero Crear no valida las horas (se validan al
    //                CERRAR), así que no había error.
    //    ✅ CÓMO CORREGIRLO: la consigna pide probar la fecha de ayer.
    // ---------------------------------------------------------------------
    [Fact]
    public void Crear_con_fecha_limite_de_ayer_lanza_excepcion()
    {
        Assert.Throws<ArgumentException>(() =>
            Ticket.Crear("No anda la impresora", "Carla Vega", DateTime.Now.AddDays(-1)));
    }

    // Prueba 3 de la consigna (✅ tu prueba estaba BIEN; solo cambian los datos)
    [Fact]
    public void Ticket_nuevo_esta_abierto_y_con_0_horas()
    {
        var ticket = Ticket.Crear("No anda la impresora", "Carla Vega", FechaFutura);

        Assert.Equal(EstadoTicket.Abierto, ticket.Estado);
        Assert.Equal(0m, ticket.HorasTrabajadas);
    }

    // ---------------------------------------------------------------------
    // Prueba 4 de la consigna: tomar y cerrar con 3,5 horas
    // ❌ ERROR P3 - Tu prueba "Iniciar_y_cerrar_el_ticket" FALLABA:
    //      Assert.Equal() Failure: Values differ
    //      Expected: Abierto
    //    QUÉ PASABA (2 cosas):
    //      a) Después de tomar y cerrar, el estado es CERRADO, no Abierto.
    //      b) Esperabas 230000 horas (el número quedó del Taller).
    //         Además, con tu CerrarTicket las horas nunca se guardaban
    //         (ver L5 en Ticket.cs): aunque pusieras 23, iba a dar 0.
    //    ✅ CÓMO CORREGIRLO: cerrar con 3.5m y esperar Cerrado y 3.5m.
    //       (3,5 en C# se escribe con PUNTO: 3.5m)
    // ---------------------------------------------------------------------
    [Fact]
    public void Tomar_y_cerrar_deja_el_ticket_cerrado_con_las_horas()
    {
        var ticket = Ticket.Crear("No anda la impresora", "Carla Vega", FechaFutura);

        ticket.Tomar();
        ticket.Cerrar(3.5m);

        Assert.Equal(EstadoTicket.Cerrado, ticket.Estado);
        Assert.Equal(3.5m, ticket.HorasTrabajadas);
    }

    // ---------------------------------------------------------------------
    // Prueba 5 de la consigna: cerrar con 50 horas
    // (Tu "Finalizar_una_orden_recibida" pasaba, pero probaba OTRA cosa:
    //  cerrar un ticket Abierto. La consigna pide cerrar con 50 horas.)
    // Pregunta 4: para llegar a validar las horas, primero hay que TOMARLO
    // (si no, salta antes el error de estado).
    // Con tu CerrarTicket original esta prueba fallaba: validaba la propiedad
    // (0) y no las 50 horas que llegaban (ver L5).
    // ---------------------------------------------------------------------
    [Fact]
    public void Cerrar_con_50_horas_lanza_excepcion()
    {
        var ticket = Ticket.Crear("No anda la impresora", "Carla Vega", FechaFutura);
        ticket.Tomar();

        Assert.Throws<ArgumentException>(() => ticket.Cerrar(50m));
    }

    // ---------------------------------------------------------------------
    // Extra: el caso de uso guarda y devuelve el DTO
    // ❌ ERROR P4 - Tu prueba FALLABA:
    //      System.ArgumentException : El titulo debe tener al menos 10
    //      caracteres. (Parameter 'titulo')
    //    QUÉ PASABA: el título era "Empleada" (8 letras). ¡Tu propia regla 2
    //                lo rechazó! (O sea, la regla andaba bien.) Además
    //                esperabas 25 horas (un ticket nuevo tiene 0) y el estado
    //                "Recibida" (era del Taller; acá es "Abierto").
    //    ✅ CÓMO CORREGIRLO: título de 10+ letras, esperar 0 horas y "Abierto".
    // ---------------------------------------------------------------------
    [Fact]
    public async Task Crear_ticket_guarda_y_devuelve_dto_abierto()
    {
        var repositorio = new RepositorioFalso();
        var useCase = new CrearTicketUseCase(repositorio);

        var resultado = await useCase.ExecuteAsync("  No anda la impresora  ", "Carla Vega", FechaFutura);

        Assert.Equal("No anda la impresora", resultado.Titulo);
        Assert.Equal(0m, resultado.HorasTrabajadas);
        Assert.Equal("Abierto", resultado.Estado);
        Assert.Single(repositorio.Tickets);
    }

    // ✅ El repositorio falso estaba BIEN.
    private sealed class RepositorioFalso : ITicketRepositorio
    {
        public List<Ticket> Tickets { get; } = [];

        public Task AddAsync(Ticket ticket, CancellationToken cancellationToken = default)
        {
            Tickets.Add(ticket);
            return Task.CompletedTask;
        }

        public Task<IReadOnlyCollection<Ticket>> GetAllAsync(CancellationToken cancellationToken = default)
            => Task.FromResult<IReadOnlyCollection<Ticket>>(Tickets);

        public Task<Ticket?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
            => Task.FromResult(Tickets.FirstOrDefault(t => t.Id == id));

        public Task UpdateAsync(Ticket ticket, CancellationToken cancellationToken = default)
            => Task.CompletedTask;
    }
}
