// =========================================================================
// APLICACIÓN - Caso de uso: Listar pedidos   (ANTES: ListarPedidos.cs)
// =========================================================================
using Delivery.Application.Abstracciones;

namespace Delivery.Application.Pedidos;

public sealed class ListarPedidosUseCase(IPedidoRepositorio repositorio)
{
    public async Task<IReadOnlyCollection<PedidoDto>> ExecuteAsync(CancellationToken cancellationToken = default)
    {
        // ❌ ERROR L11 - Variable "productos" (copiado del Almacén)
        //    ✅ CÓMO CORREGIRLO: Ctrl+R, Ctrl+R sobre "productos" > "pedidos".
        var pedidos = await repositorio.GetAllAsync(cancellationToken);
        return pedidos.Select(p => p.ToDto()).ToArray();
    }
}
