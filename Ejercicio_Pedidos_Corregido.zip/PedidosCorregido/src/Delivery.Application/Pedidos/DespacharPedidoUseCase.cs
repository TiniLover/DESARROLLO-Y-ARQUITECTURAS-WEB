// =========================================================================
// APLICACIÓN - Caso de uso: Despachar   (ANTES: DespacharPedido.cs)
// =========================================================================
using Delivery.Application.Abstracciones;

namespace Delivery.Application.Pedidos;

public sealed class DespacharPedidoUseCase(IPedidoRepositorio repositorio)
{
    // ---------------------------------------------------------------------
    // ❌ ERROR L3 - Recibía "decimal total"
    //    QUÉ PASABA: despachar solo cambia el estado; no necesita ningún dato
    //                más que el Id del pedido (pregunta 5 del ejercicio).
    //    ✅ CÓMO CORREGIRLO:
    //       1. Borrá ", decimal total" de los parámetros.
    //       2. Cambiá "pedido.Despachar(total)" por "pedido.Despachar()".
    //    ANTES:  ExecuteAsync(Guid id, decimal total, ...)
    // ---------------------------------------------------------------------
    public async Task<PedidoDto?> ExecuteAsync(Guid id, CancellationToken cancellationToken = default)
    {
        var pedido = await repositorio.GetByIdAsync(id, cancellationToken);
        if (pedido is null)
            return null;

        pedido.Despachar();

        await repositorio.UpdateAsync(pedido, cancellationToken);
        return pedido.ToDto();
    }
}
