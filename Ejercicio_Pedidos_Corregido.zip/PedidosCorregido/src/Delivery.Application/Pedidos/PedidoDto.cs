// =========================================================================
// APLICACIÓN - DTO de salida   (ANTES: PedidoDTo.cs)
// ¡BIEN! Esta vez es "public" y es un record (no repetiste el error E1 de
// la Billetera).
// =========================================================================
namespace Delivery.Application.Pedidos;

// -------------------------------------------------------------------------
// ❌ ERROR L7 - El estado iba como enum y faltaba la fecha
//    QUÉ PASABA:
//      - Con "EnumEstado Estado", Swagger muestra un NÚMERO ("estado": 1) y
//        no se entiende qué es. Además, el DTO quedaba dependiendo de un
//        tipo del Dominio (tenía "using Domain;").
//      - Faltaba FechaPedido (está en la entidad de la consigna).
//      - Nombre "PedidoDTo" (con la o minúscula) -> "PedidoDto".
//    ✅ CÓMO CORREGIRLO:
//       1. Cambiá "EnumEstado Estado" por "string Estado".
//       2. Agregá ", DateTime FechaPedido" al final.
//       3. Borrá el "using Domain;" de arriba (ya no hace falta).
//       4. En PedidoMapeo.cs, pasá el estado como texto: pedido.Estado.ToString()
//       5. Renombrá PedidoDTo -> PedidoDto con Ctrl+R, Ctrl+R.
//    ANTES:  public sealed record PedidoDTo(Guid Id, string Cliente,
//                string Direccion, decimal Total, EnumEstado Estado);
// -------------------------------------------------------------------------
public sealed record PedidoDto(
    Guid Id,
    string Cliente,
    string Direccion,
    decimal Total,
    string Estado,
    DateTime FechaPedido);
