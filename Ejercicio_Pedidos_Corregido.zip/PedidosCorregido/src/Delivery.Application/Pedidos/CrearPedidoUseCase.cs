// =========================================================================
// APLICACIÓN - Caso de uso: Crear pedido   (ANTES: CrearPedido.cs)
// =========================================================================
using Delivery.Application.Abstracciones;
using Delivery.Domain;

namespace Delivery.Application.Pedidos;

public sealed class CrearPedidoUseCase(IPedidoRepositorio repositorio)
{
    // ---------------------------------------------------------------------
    // (Por este parámetro "estado" aparecía en Program.cs el error:
    //      Código:      CS7036
    //      Descripción: No se ha dado ningún argumento que corresponda al parámetro requerido "estado" de "CrearPedido.ExecuteAsync(string, string, decimal, EnumEstado, CancellationToken)"
    //  ver ERROR E3 en Program.cs)
    //
    // ❌ ERROR L1 - Recibía "EnumEstado estado"
    //    ✅ CÓMO CORREGIRLO: borrá ", EnumEstado estado" de los parámetros y
    //       de la llamada a Pedido.Crear(...).
    //    ANTES:  ExecuteAsync(string cliente, string direccion, decimal total,
    //                         EnumEstado estado, ...)
    // ---------------------------------------------------------------------
    public async Task<PedidoDto> ExecuteAsync(
        string cliente, string direccion, decimal total,
        CancellationToken cancellationToken = default)
    {
        // ❌ ERROR L11 - La variable se llamaba "producto" (copiado del Almacén)
        //    ✅ CÓMO CORREGIRLO: click en "producto" > Ctrl+R, Ctrl+R > "pedido".
        //    ANTES:  var producto = Pedido.Crear(cliente, direccion, total, estado);
        var pedido = Pedido.Crear(cliente, direccion, total);
        await repositorio.AddAsync(pedido, cancellationToken);
        return pedido.ToDto();
    }
}
