// =========================================================================
// APLICACIÓN - Mapeo Entidad -> DTO
// ✅ Estaba BIEN (devuelve el DTO, no la entidad: no repetiste el error E2
//    de la Billetera).
// =========================================================================
using Delivery.Domain;

namespace Delivery.Application.Pedidos;

internal static class PedidoMapeo
{
    // ❌ ERROR L7 (continuación)
    //    ✅ CÓMO CORREGIRLO: cambiá "pedido.Estado" por "pedido.Estado.ToString()"
    //       (convierte Pendiente -> "Pendiente") y agregá "pedido.FechaPedido".
    //    ANTES:  new(pedido.Id, pedido.Cliente, pedido.Direccion, pedido.Total, pedido.Estado);
    public static PedidoDto ToDto(this Pedido pedido) =>
        new(pedido.Id, pedido.Cliente, pedido.Direccion, pedido.Total,
            pedido.Estado.ToString(), pedido.FechaPedido);
}
