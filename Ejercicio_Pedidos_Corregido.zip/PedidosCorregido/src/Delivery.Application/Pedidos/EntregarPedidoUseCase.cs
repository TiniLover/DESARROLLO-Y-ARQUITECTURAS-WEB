// =========================================================================
// APLICACIÓN - Caso de uso: Entregar   (ANTES: EntregarPedido.cs)
// =========================================================================
using Delivery.Application.Abstracciones;

namespace Delivery.Application.Pedidos;

public sealed class EntregarPedidoUseCase(IPedidoRepositorio repositorio)
{
    // ---------------------------------------------------------------------
    // ❌ ERROR E4 - Este parámetro causaba el error de Program.cs:
    //      Gravedad:    Error
    //      Código:      CS1503
    //      Descripción: Argumento 2: no se puede convertir de 'System.Threading.CancellationToken' a 'decimal'
    //      Proyecto:    WebApplication1
    //      Archivo:     Program.cs
    //      Línea:       71
    //    QUÉ PASABA: el método pedía "decimal total" (que ni se usaba
    //                adentro), y en Program.cs lo llamabas así:
    //                    useCase.ExecuteAsync(id, ct)
    //                C# intentaba poner "ct" en el lugar de "total" -> error.
    //    ✅ CÓMO CORREGIRLO: borrá ", decimal total" de los parámetros.
    //       Entregar no necesita ningún dato además del Id.
    //    ANTES:  ExecuteAsync(Guid id, decimal total, CancellationToken ...)
    // ---------------------------------------------------------------------
    public async Task<PedidoDto?> ExecuteAsync(Guid id, CancellationToken cancellationToken = default)
    {
        var pedido = await repositorio.GetByIdAsync(id, cancellationToken);
        if (pedido is null)
            return null;

        pedido.Entregar();

        await repositorio.UpdateAsync(pedido, cancellationToken);
        return pedido.ToDto();
    }
}
