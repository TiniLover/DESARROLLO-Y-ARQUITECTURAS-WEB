// =========================================================================
// APLICACIÓN - Interfaz del repositorio
// ✅ Estaba BIEN (sin errores). Solo cambia el namespace.
// =========================================================================
using Delivery.Domain;

namespace Delivery.Application.Abstracciones;

public interface IPedidoRepositorio
{
    Task AddAsync(Pedido pedido, CancellationToken cancellationToken = default);
    Task<IReadOnlyCollection<Pedido>> GetAllAsync(CancellationToken cancellationToken = default);
    Task<Pedido?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default);
    Task UpdateAsync(Pedido pedido, CancellationToken cancellationToken = default);
}
