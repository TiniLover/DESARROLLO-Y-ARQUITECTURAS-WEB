// =========================================================================
// DOMINIO - Entidad Pedido   (ANTES: Domain/Pedido.cs)
// Errores de este archivo: L1, L2, L3 (de LÓGICA: Visual Studio no los
// marca, pero no cumplen la consigna). El método Entregar estaba BIEN.
// =========================================================================
namespace Delivery.Domain;

public sealed class Pedido
{
    // ---------------------------------------------------------------------
    // ❌ ERROR L1 - El constructor recibía el estado
    //    QUÉ PASABA: por la regla 3, TODO pedido nuevo arranca en Pendiente,
    //                así que el estado no viene de afuera (igual que el saldo
    //                en 0 de la Billetera).
    //    ✅ CÓMO CORREGIRLO:
    //       1. Borrá el parámetro ", EnumEstado estado" del constructor.
    //       2. Cambiá "Estado = estado;" por "Estado = EstadoPedido.Pendiente;".
    //    ANTES:  private Pedido(Guid id, string cliente, string direccion,
    //                           decimal total, EnumEstado estado, DateTime fechapedido)
    // ---------------------------------------------------------------------
    private Pedido(Guid id, string cliente, string direccion, decimal total, DateTime fechaPedido)
    {
        Id = id;
        Cliente = cliente;
        Direccion = direccion;
        Total = total;
        FechaPedido = fechaPedido;
        Estado = EstadoPedido.Pendiente;   // REGLA 3: todo pedido arranca en Pendiente
    }

    public Guid Id { get; }

    // ✅ MEJORA: Cliente, Direccion y Total NO cambian después de crear el
    //    pedido -> borrá "private set;" y dejá solo "{ get; }".
    public string Cliente { get; }
    public string Direccion { get; }
    public decimal Total { get; }
    public DateTime FechaPedido { get; }

    // Estado SÍ cambia (al despachar y al entregar) -> private set. (Estaba bien.)
    public EstadoPedido Estado { get; private set; }

    // ---------------------------------------------------------------------
    // ❌ ERROR L1 - Crear recibía "EnumEstado estado" y no lo usaba
    //    ✅ CÓMO CORREGIRLO: borrá ", EnumEstado estado" de los parámetros.
    //    ANTES:  public static Pedido Crear(string cliente, string direccion,
    //                                       decimal total, EnumEstado estado)
    // ---------------------------------------------------------------------
    public static Pedido Crear(string cliente, string direccion, decimal total)
    {
        // REGLA 1 (estaba BIEN)
        if (string.IsNullOrWhiteSpace(cliente))
            throw new ArgumentException("El cliente es obligatorio.", nameof(cliente));

        if (string.IsNullOrWhiteSpace(direccion))
            throw new ArgumentException("La dirección es obligatoria.", nameof(direccion));

        // -----------------------------------------------------------------
        // ❌ ERROR L2 - Faltaba validar el total ACÁ (regla 2)
        //    QUÉ PASABA: las validaciones del total estaban en Despachar.
        //                Pero el total se carga al CREAR el pedido: es ahí
        //                donde tiene que validarse. Con tu código se podía
        //                crear un pedido con total -500 sin ningún error.
        //    ✅ CÓMO CORREGIRLO:
        //       1. Cortá (Ctrl+X) los dos "if" del total que estaban en
        //          Despachar y pegalos ACÁ, debajo de los de la regla 1.
        //       2. En el segundo, agregá la "m" al número: 500000m (decimal).
        // -----------------------------------------------------------------
        if (total <= 0)
            throw new ArgumentException("El total tiene que ser mayor a 0.", nameof(total));

        if (total > 500000m)
            throw new ArgumentException("El total no puede superar los $500.000.", nameof(total));

        // -----------------------------------------------------------------
        // ❌ ERROR L2 - El total se guardaba en 0  (por esto fallaba la prueba P1)
        //    QUÉ PASABA: en el "return new Pedido(...)" estaba escrito "0m"
        //                en lugar de la variable "total". El total que
        //                mandaba el usuario se perdía.
        //    ✅ CÓMO CORREGIRLO: en el return, reemplazá "0m" por "total".
        //       Y borrá "EnumEstado.Pendiente" (ahora lo pone el constructor).
        //    ANTES:  return new Pedido(Guid.NewGuid(), cliente.Trim(), direccion.Trim(),
        //                              0m, EnumEstado.Pendiente, DateTime.UtcNow);
        // -----------------------------------------------------------------
        return new Pedido(Guid.NewGuid(), cliente.Trim(), direccion.Trim(), total, DateTime.UtcNow);
    }

    // ---------------------------------------------------------------------
    // ❌ ERROR L3 - Despachar estaba hecho al revés (el error más importante)
    //    QUÉ PASABA (4 problemas):
    //      a) Recibía "decimal total" y lo SUMABA al Total. Despachar no
    //         tiene nada que ver con el total: solo cambia el ESTADO.
    //      b) Tenía "if (Estado == Pendiente) throw ...": lanzaba error
    //         justamente cuando el pedido está Pendiente, que es el ÚNICO
    //         caso en el que SÍ se puede despachar (regla 4). O sea, nunca
    //         se podía despachar un pedido.
    //      c) Nunca cambiaba el estado a EnCamino.
    //      d) Validaba el total (eso va en Crear, ver error L2).
    //    ✅ CÓMO CORREGIRLO:
    //       1. Borrá el parámetro "decimal total" -> queda "Despachar()".
    //       2. Borrá todo lo de adentro.
    //       3. Escribilo IGUAL que tu método Entregar (que estaba bien),
    //          cambiando los estados:
    //              if (Estado != EstadoPedido.Pendiente)  -> throw
    //              Estado = EstadoPedido.EnCamino;
    //    TRUCO: "solo se puede X si está en Y" siempre se escribe
    //           "if (Estado != Y) throw ..." (con DISTINTO, !=).
    //    ANTES:
    //        public void Despachar(decimal total)
    //        {
    //            if (total <= 0) throw ...
    //            Total += total;
    //            if (total > 500000) throw ...
    //            if (Estado == EnumEstado.Pendiente) throw ...
    //            if (Estado == EnumEstado.Encamino) throw ...
    //        }
    // ---------------------------------------------------------------------
    public void Despachar()
    {
        // REGLA 4: solo se puede despachar si está Pendiente.
        if (Estado != EstadoPedido.Pendiente)
            throw new InvalidOperationException("Solo se pueden despachar pedidos en estado Pendiente.");

        Estado = EstadoPedido.EnCamino;
    }

    // ---------------------------------------------------------------------
    // ✅ Este método estaba BIEN (regla 5). Solo cambia Encamino -> EnCamino.
    // ---------------------------------------------------------------------
    public void Entregar()
    {
        if (Estado != EstadoPedido.EnCamino)
            throw new InvalidOperationException("Solo se pueden entregar pedidos en estado EnCamino.");

        Estado = EstadoPedido.Entregado;
    }
}
