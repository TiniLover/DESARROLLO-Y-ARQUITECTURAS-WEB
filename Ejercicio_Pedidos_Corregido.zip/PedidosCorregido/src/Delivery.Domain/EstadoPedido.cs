// =========================================================================
// DOMINIO - Enum de estados   (ANTES: Domain/EnumEstado.cs)
// -------------------------------------------------------------------------
// ¡BIEN! Usaste un enum (no un bool), que era lo correcto para 3 estados.
//
// ❌ ERROR L9 - Nombres del enum y de un valor
//    QUÉ PASABA:
//      - "EnumEstado" no dice de QUÉ es el estado. Por convención el nombre
//        describe lo que representa, sin la palabra "Enum".
//      - "Encamino" (c minúscula): la consigna dice "EnCamino". En C# cada
//        palabra va con mayúscula (PascalCase).
//      - Sobraba el ";" después de la "}" (no da error, pero no va).
//    ✅ CÓMO CORREGIRLO:
//       1. Click en "EnumEstado" > Ctrl+R, Ctrl+R > "EstadoPedido" > Enter
//          (se renombra en todo el proyecto, incluido el nombre del archivo).
//       2. Click en "Encamino" > Ctrl+R, Ctrl+R > "EnCamino" > Enter.
//       3. Borrá el ";" de "};" al final del enum.
//    ANTES:
//        public enum EnumEstado { Pendiente, Encamino, Entregado, };
// =========================================================================
namespace Delivery.Domain;

public enum EstadoPedido
{
    Pendiente,
    EnCamino,
    Entregado
}
