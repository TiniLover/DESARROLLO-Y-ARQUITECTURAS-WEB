// =========================================================================
// API - Inyección de dependencias + endpoints   (ANTES: WebApplication1/Program.cs)
// Errores de COMPILACIÓN de este archivo: E1, E2, E3, E4 (Visual Studio los
// marca en rojo). Arreglalos en ese orden: E1 tapa a los demás.
// NOTA: los números de "Línea" son los de TU archivo original (no los de
// este archivo corregido, que tiene comentarios agregados).
// =========================================================================

// ❌ ERROR E2 (parte 1) - Faltaba este using
//    QUÉ PASABA: sin él, Visual Studio no encuentra "IPedidoRepositorio".
//    ✅ CÓMO CORREGIRLO: agregá arriba "using Delivery.Application.Abstracciones;"
//       (o hacé click en la palabra subrayada > Ctrl+. > elegí el "using ...").
using Delivery.Application.Abstracciones;
using Delivery.Application.Pedidos;
using Delivery.Infrastructure;

var builder = WebApplication.CreateBuilder(args);

// -------------------------------------------------------------------------
// ❌ ERROR E2
//    TAL CUAL APARECÍA EN VISUAL STUDIO (Lista de errores):
//      Gravedad:    Error
//      Código:      CS0311
//      Descripción: El tipo 'Infraestructura.PedidoRepositorioEnMemoria' no se puede usar como parámetro de tipo 'TImplementation' en el tipo o método genérico 'ServiceCollectionServiceExtensions.AddSingleton<TService, TImplementation>(IServiceCollection)'. No hay ninguna conversión de referencia implícita de 'Infraestructura.PedidoRepositorioEnMemoria' a 'System.InvalidProgramException'.
//      Proyecto:    WebApplication1
//      Archivo:     Program.cs
//      Línea:       6
//    QUÉ PASABA: escribiste "InvalidProgramException" (una excepción del
//                sistema) en vez de la INTERFAZ del repositorio. Seguramente
//                el autocompletado de Visual Studio eligió la palabra
//                equivocada al escribir "I..." y apretar Enter/Tab.
//                Además sobraba "IServiceCollection serviceCollection =".
//    ✅ CÓMO CORREGIRLO:
//       1. Borrá "IServiceCollection serviceCollection = " del principio.
//       2. Reemplazá "InvalidProgramException" por "IPedidoRepositorio".
//       3. Cuando el autocompletado te sugiera algo, MIRÁ qué elige antes
//          de apretar Enter.
//    ANTES:
//        IServiceCollection serviceCollection =
//            builder.Services.AddSingleton<InvalidProgramException, PedidoRepositorioEnMemoria>();
// -------------------------------------------------------------------------
builder.Services.AddSingleton<IPedidoRepositorio, PedidoRepositorioEnMemoria>();

builder.Services.AddScoped<CrearPedidoUseCase>();
builder.Services.AddScoped<ListarPedidosUseCase>();
builder.Services.AddScoped<DespacharPedidoUseCase>();
builder.Services.AddScoped<EntregarPedidoUseCase>();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// GET /pedidos  (estaba BIEN)
app.MapGet("/pedidos", async (ListarPedidosUseCase useCase, CancellationToken ct) =>
    Results.Ok(await useCase.ExecuteAsync(ct)))
.WithName("ListarPedidos")
.WithOpenApi();

// -------------------------------------------------------------------------
// POST /pedidos
// ❌ ERROR E3
//    TAL CUAL APARECÍA EN VISUAL STUDIO (Lista de errores):
//      Gravedad:    Error
//      Código:      CS7036
//      Descripción: No se ha dado ningún argumento que corresponda al parámetro requerido "estado" de "CrearPedido.ExecuteAsync(string, string, decimal, EnumEstado, CancellationToken)"
//      Proyecto:    WebApplication1
//      Archivo:     Program.cs
//      Línea:       35
//    QUÉ PASABA: el caso de uso pedía 4 datos (cliente, direccion, total,
//                estado) y acá le pasabas solo 2 (cliente, direccion).
//                Faltaba el TOTAL, y el estado no tendría que pedirse (L1).
//    ✅ CÓMO CORREGIRLO:
//       1. En el record CrearPedidoRequest (al final del archivo) agregá
//          "decimal Total", para que el cliente lo mande en el JSON.
//       2. Sacá "EnumEstado estado" del caso de uso (ver CrearPedidoUseCase.cs).
//       3. Acá pasá los 3 datos: request.Cliente, request.Direccion, request.Total.
//    ANTES:  useCase.ExecuteAsync(request.cliente, request.direccion, ct);
// -------------------------------------------------------------------------
app.MapPost("/pedidos", async (CrearPedidoRequest request, CrearPedidoUseCase useCase, CancellationToken ct) =>
{
    try
    {
        var pedido = await useCase.ExecuteAsync(request.Cliente, request.Direccion, request.Total, ct);
        return Results.Created($"/pedidos/{pedido.Id}", pedido);          // 201
    }
    catch (ArgumentException ex)
    {
        return Results.BadRequest(new { error = ex.Message });           // 400
    }
})
.WithName("CrearPedido")
.WithOpenApi();

// -------------------------------------------------------------------------
// POST /pedidos/{id}/despachar
// ❌ ERROR L5 - Recibía un "DespacharPedidoRequest request" con un total
//    QUÉ PASABA: despachar no necesita datos en el cuerpo: alcanza con el Id
//                de la ruta (igual que "prestar libro"). Era la pregunta 5.
//    ✅ CÓMO CORREGIRLO:
//       1. Borrá "DespacharPedidoRequest request," de los parámetros.
//       2. Cambiá "useCase.ExecuteAsync(id, request.total, ct)" por
//          "useCase.ExecuteAsync(id, ct)".
//       3. Borrá el record DespacharPedidoRequest del final del archivo.
//
// ❌ ERROR L6 - Faltaba atrapar InvalidOperationException
//    QUÉ PASABA: si se intenta despachar un pedido que NO está Pendiente,
//                el Dominio lanza InvalidOperationException. Sin este catch,
//                la API responde 500 (error del servidor) en vez de 400.
//    ✅ CÓMO CORREGIRLO: cambiá "catch (ArgumentException ex)" por
//       "catch (InvalidOperationException ex)" (despachar ya no recibe datos,
//       así que no puede haber ArgumentException).
// -------------------------------------------------------------------------
app.MapPost("/pedidos/{id:guid}/despachar", async (Guid id, DespacharPedidoUseCase useCase, CancellationToken ct) =>
{
    try
    {
        var pedido = await useCase.ExecuteAsync(id, ct);
        return pedido is null
            ? Results.NotFound(new { error = "No existe un pedido con ese Id." })   // 404
            : Results.Ok(pedido);                                                    // 200
    }
    catch (InvalidOperationException ex)        // no estaba Pendiente
    {
        return Results.BadRequest(new { error = ex.Message });                      // 400
    }
})
.WithName("DespacharPedido")
.WithOpenApi();

// -------------------------------------------------------------------------
// POST /pedidos/{id}/entregar
// ❌ ERROR E1  (Visual Studio marca 3 errores juntos, en la misma línea)
//    TAL CUAL APARECÍAN EN VISUAL STUDIO (Lista de errores):
//      Gravedad  Código  Descripción                                   Proyecto         Archivo     Línea
//      Error     CS1003  Error de sintaxis, se esperaba ':'            WebApplication1  Program.cs  79
//      Error     CS1525  El término de expresión ';' no es válido      WebApplication1  Program.cs  79
//      Error     CS1513  Se esperaba }                                 WebApplication1  Program.cs  79
//    QUÉ PASABA: en el primer catch quedaron mezcladas líneas del bloque de
//                arriba (las del "? Results.NotFound ... : Results.Ok"), con
//                un ";" en el medio. Eso rompe la sintaxis y C# no entiende
//                nada de lo que sigue (por eso pide ":" y "}").
//                Además había DOS "catch (ArgumentException ex)" iguales.
//    ✅ CÓMO CORREGIRLO:
//       1. Borrá el PRIMER catch completo (las 6 líneas de abajo, en ANTES).
//       2. Dejá un solo catch de InvalidOperationException.
//    ANTES:
//        catch (ArgumentException ex)
//        {
//            return Results.BadRequest(new { error = ex.Message })
//                ? Results.NotFound(new { error = "No existe un pedido con ese Id." });
//                : Results.Ok(pedido);
//        }
//        catch (ArgumentException ex)        <- repetido
//        { ... }
//
// ❌ ERROR E4  (aparecen al arreglar E1)
//    TAL CUAL APARECÍAN EN VISUAL STUDIO (Lista de errores):
//      Gravedad:    Error
//      Código:      CS1503
//      Descripción: Argumento 2: no se puede convertir de 'System.Threading.CancellationToken' a 'decimal'
//      Proyecto:    WebApplication1
//      Archivo:     Program.cs
//      Línea:       71
//
//      Gravedad:    Error   (aparece 2 veces: líneas 78 y 82)
//      Código:      CS4010
//      Descripción: No se puede convertir el elemento expresión lambda asincrónico en el tipo delegado 'Task<?>'. Un elemento expresión lambda asincrónico puede devolver void, Task o Task<T>, ninguno de los cuales se puede convertir en 'Task<?>'.
//      Proyecto:    WebApplication1
//      Archivo:     Program.cs
//      Línea:       78 y 82
//    QUÉ PASABA: EntregarPedido.ExecuteAsync pedía (id, total, ct) y acá se
//                llamaba con (id, ct). El CS4010 es consecuencia del CS1503:
//                al arreglar uno, desaparece el otro.
//    ✅ CÓMO CORREGIRLO: sacá el parámetro "decimal total" del caso de uso
//       (ver EntregarPedidoUseCase.cs). Esta línea queda igual.
//
// ❌ ERROR L5 - "EntregarPedidoRequest request" sobraba (no hay cuerpo)
//    ✅ CÓMO CORREGIRLO: borralo de los parámetros y borrá el record del final.
//
// ❌ ERROR L8 - .WithName("Retirar") quedó copiado de la Billetera
//    ✅ CÓMO CORREGIRLO: cambialo por .WithName("EntregarPedido").
// -------------------------------------------------------------------------
app.MapPost("/pedidos/{id:guid}/entregar", async (Guid id, EntregarPedidoUseCase useCase, CancellationToken ct) =>
{
    try
    {
        var pedido = await useCase.ExecuteAsync(id, ct);
        return pedido is null
            ? Results.NotFound(new { error = "No existe un pedido con ese Id." })   // 404
            : Results.Ok(pedido);                                                    // 200
    }
    catch (InvalidOperationException ex)        // no estaba EnCamino
    {
        return Results.BadRequest(new { error = ex.Message });                      // 400
    }
})
.WithName("EntregarPedido")
.WithOpenApi();

app.Run();

// -------------------------------------------------------------------------
// DTO DE ENTRADA
// ❌ ERROR E3 + L8
//    QUÉ PASABA: faltaba el Total (por eso no se podía pasar al caso de uso)
//                y los parámetros estaban en minúscula (cliente, direccion).
//                Compilaba porque usabas "request.cliente" en minúscula en
//                los dos lados, pero la convención en C# es MAYÚSCULA (en la
//                Billetera esto mismo dio el error CS1061).
//    ✅ CÓMO CORREGIRLO:
//       1. Escribí los parámetros con mayúscula: Cliente, Direccion.
//       2. Agregá ", decimal Total".
//       3. Arriba, cambiá request.cliente -> request.Cliente, etc.
//    ANTES:  public sealed record CrearPedidoRequest(string cliente, string direccion);
//
// ❌ ERROR L5 - Sobraban estos dos records (despachar y entregar no reciben datos)
//    ✅ CÓMO CORREGIRLO: borralos.
//    ANTES:  public sealed record EntregarPedidoRequest(decimal total);
//            public sealed record DespacharPedidoRequest(decimal total);
// -------------------------------------------------------------------------
public sealed record CrearPedidoRequest(string Cliente, string Direccion, decimal Total);
