// =========================================================================
// INFRAESTRUCTURA - Repositorio en memoria
// ✅ Estaba BIEN (sin errores). Solo cambia el namespace.
// =========================================================================
using System.Collections.Concurrent;
using Delivery.Application.Abstracciones;
using Delivery.Domain;

namespace Delivery.Infrastructure;

public sealed class PedidoRepositorioEnMemoria : IPedidoRepositorio
{
    private readonly ConcurrentDictionary<Guid, Pedido> pedidos = new();

    public Task AddAsync(Pedido pedido, CancellationToken cancellationToken = default)
    {
        pedidos[pedido.Id] = pedido;
        return Task.CompletedTask;
    }

    public Task<IReadOnlyCollection<Pedido>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        IReadOnlyCollection<Pedido> resultado = pedidos.Values.OrderBy(p => p.FechaPedido).ToArray();
        return Task.FromResult(resultado);
    }

    public Task<Pedido?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
    {
        pedidos.TryGetValue(id, out var pedido);
        return Task.FromResult(pedido);
    }

    public Task UpdateAsync(Pedido pedido, CancellationToken cancellationToken = default)
    {
        pedidos[pedido.Id] = pedido;
        return Task.CompletedTask;
    }
}
