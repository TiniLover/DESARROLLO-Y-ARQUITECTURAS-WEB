// =========================================================================
// PRUEBAS   (ANTES: Test/UnitTest1.cs)
// -------------------------------------------------------------------------
// ❌ ERROR L10 - Había UNA sola prueba y la consigna pide 5
//    ✅ CÓMO CORREGIRLO: escribí una prueba [Fact] por cada punto de
//       "Pruebas mínimas" de la consigna, con un nombre que diga qué prueba.
//       Renombrá UnitTest1.cs -> PedidoTests.cs (click derecho > Cambiar nombre).
//
// ❌ ERROR L11 - El proyecto de pruebas referenciaba Infraestructura
//    ✅ CÓMO CORREGIRLO: Test > Dependencias > Proyectos > click derecho en
//       Infraestructura > Quitar. (Las pruebas usan un repositorio FALSO.)
// =========================================================================
using Delivery.Application.Abstracciones;
using Delivery.Application.Pedidos;
using Delivery.Domain;

namespace Delivery.Tests;

public sealed class PedidoTests
{
    // Prueba 1 de la consigna (❌ ANTES no existía)
    [Fact]
    public void Crear_con_total_0_lanza_excepcion()
    {
        Assert.Throws<ArgumentException>(() => Pedido.Crear("Marta Ruiz", "Av. Maipú 1234", 0m));
    }

    // Prueba 2 de la consigna (❌ ANTES no existía)
    [Fact]
    public void Crear_con_total_600000_lanza_excepcion()
    {
        Assert.Throws<ArgumentException>(() => Pedido.Crear("Marta Ruiz", "Av. Maipú 1234", 600000m));
    }

    // Prueba 3 de la consigna (❌ ANTES no existía)
    [Fact]
    public void Pedido_nuevo_esta_pendiente()
    {
        var pedido = Pedido.Crear("Marta Ruiz", "Av. Maipú 1234", 18500m);
        Assert.Equal(EstadoPedido.Pendiente, pedido.Estado);
    }

    // Prueba 4 de la consigna (❌ ANTES no existía)
    // Con tu Despachar original esta prueba fallaba: lanzaba error justo
    // porque el pedido estaba Pendiente (ver error L3 en Pedido.cs).
    [Fact]
    public void Despachar_y_entregar_deja_el_pedido_entregado()
    {
        var pedido = Pedido.Crear("Marta Ruiz", "Av. Maipú 1234", 18500m);

        pedido.Despachar();
        pedido.Entregar();

        Assert.Equal(EstadoPedido.Entregado, pedido.Estado);
    }

    // Prueba 5 de la consigna (❌ ANTES no existía)
    [Fact]
    public void Entregar_un_pedido_pendiente_lanza_excepcion()
    {
        var pedido = Pedido.Crear("Marta Ruiz", "Av. Maipú 1234", 18500m);

        Assert.Throws<InvalidOperationException>(() => pedido.Entregar());
    }

    // ---------------------------------------------------------------------
    // Tu prueba (extra): el caso de uso guarda y devuelve el DTO
    // ❌ ERROR P1 - La prueba FALLABA al ejecutarla
    //    TAL CUAL APARECÍA EN VISUAL STUDIO (Explorador de pruebas, cruz roja):
    //      Prueba:  Test.UnitTest1.despachar_pedido_guarda_y_estadoPendiente_dto
    //      Mensaje: Assert.Equal() Failure: Values differ
    //               Expected: 15000
    //               Actual:   0
    //    (Los mensajes de xUnit salen en inglés aunque Visual Studio esté en
    //     español: "Expected" = lo que esperabas, "Actual" = lo que dio.)
    //    QUÉ PASABA: Pedido.Crear guardaba "0m" en lugar del total (error L2
    //                en Pedido.cs). La prueba estaba BIEN pensada: fue la que
    //                encontró el error.
    //    ✅ CÓMO CORREGIRLO:
    //       1. Arreglá el return de Pedido.Crear (poner "total" en vez de "0m").
    //       2. Acá, sacá ",EnumEstado.Pendiente" de ExecuteAsync (error L1).
    //       3. Escribí 15000m (con m) porque Total es decimal.
    //       4. El nombre decía "despachar_..." pero prueba CREAR -> renombrala.
    //    ANTES:
    //        despachar_pedido_guarda_y_estadoPendiente_dto()
    //        useCase.ExecuteAsync("  Julia Gómez  ", "azopardo 668", 15000, EnumEstado.Pendiente);
    //        Assert.Equal(15000, resultado.Total);
    // ---------------------------------------------------------------------
    [Fact]
    public async Task Crear_pedido_guarda_y_devuelve_dto_pendiente()
    {
        var repositorio = new RepositorioFalso();
        var useCase = new CrearPedidoUseCase(repositorio);

        var resultado = await useCase.ExecuteAsync("  Julia Gómez  ", "Azopardo 668", 15000m);

        Assert.Equal("Julia Gómez", resultado.Cliente);
        Assert.Equal(15000m, resultado.Total);
        Assert.Equal("Pendiente", resultado.Estado);   // en el DTO el estado es texto
        Assert.Single(repositorio.Pedidos);
    }

    // ✅ El repositorio falso estaba BIEN.
    private sealed class RepositorioFalso : IPedidoRepositorio
    {
        public List<Pedido> Pedidos { get; } = [];

        public Task AddAsync(Pedido pedido, CancellationToken cancellationToken = default)
        {
            Pedidos.Add(pedido);
            return Task.CompletedTask;
        }

        public Task<IReadOnlyCollection<Pedido>> GetAllAsync(CancellationToken cancellationToken = default)
            => Task.FromResult<IReadOnlyCollection<Pedido>>(Pedidos);

        public Task<Pedido?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
            => Task.FromResult(Pedidos.FirstOrDefault(p => p.Id == id));

        public Task UpdateAsync(Pedido pedido, CancellationToken cancellationToken = default)
            => Task.CompletedTask;
    }
}
