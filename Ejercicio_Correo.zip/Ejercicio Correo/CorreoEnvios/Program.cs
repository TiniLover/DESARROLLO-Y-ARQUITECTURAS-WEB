﻿using System;
using System.Text;

namespace CorreoEnvios
{
    // =====================================================================
    // PROGRAMA PRINCIPAL
    // El tipo de envío se elige UNA sola vez (acá) y se llama al MÉTODO
    // PLANTILLA Despachar(). El flujo es siempre el mismo.
    // =====================================================================
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            Envio[] envios =
            {
                new EnvioComun(),
                new EnvioExpress(),
                new EnvioInternacional()
            };

            while (true)
            {
                Console.WriteLine();
                Console.WriteLine("===== CORREO: ELEGÍ EL TIPO DE ENVÍO =====");
                for (int i = 0; i < envios.Length; i++)
                {
                    Console.WriteLine($"{i + 1}. {envios[i].Nombre}");
                }
                Console.WriteLine("0. Salir");
                Console.Write("Opción: ");

                string entrada = Console.ReadLine() ?? "";

                if (entrada == "0")
                {
                    Console.WriteLine("¡Hasta la próxima!");
                    break;
                }

                if (int.TryParse(entrada, out int opcion) && opcion >= 1 && opcion <= envios.Length)
                {
                    // Template Method: el mismo llamado para cualquier envío.
                    envios[opcion - 1].Despachar();
                }
                else
                {
                    Console.WriteLine("Opción inválida.");
                }
            }
        }
    }
}
