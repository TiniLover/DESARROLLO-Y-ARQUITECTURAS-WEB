﻿using System;

namespace CorreoEnvios
{
    // Subclase concreta: sobrescribe los hooks del destino (pide país en
    // vez de código postal) y el del seguro.
    public class EnvioInternacional : Envio
    {
        public override string Nombre => "Envío internacional";

        // Hooks del paso 2: pide el país
        protected override string DatoDestino => "país";

        protected override bool DestinoValido(string destino)
        {
            return destino != "" && destino.ToLower() != "argentina";
        }

        // PASO 3: $15.000 fijos + $1.500 por kg
        protected override decimal CalcularCosto(decimal peso)
        {
            return 15000m + 1500m * peso;
        }

        // PASO 4: siempre 15 días
        protected override int CalcularDiasEntrega(decimal peso)
        {
            return 15;
        }

        // PASO 5
        protected override void RealizarDespacho()
        {
            Console.WriteLine("Paquete enviado a aduana para su control.");
        }

        // Hook del desafío: el internacional SÍ ofrece seguro.
        protected override bool PermiteSeguro()
        {
            return true;
        }
    }
}
