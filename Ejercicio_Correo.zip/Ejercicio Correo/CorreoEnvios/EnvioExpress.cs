﻿using System;

namespace CorreoEnvios
{
    // Subclase concreta: usa el código postal por defecto (no lo repite)
    // y sobrescribe el hook del seguro.
    public class EnvioExpress : Envio
    {
        public override string Nombre => "Envío express";

        // PASO 3: $4.000 fijos + $500 por kg
        protected override decimal CalcularCosto(decimal peso)
        {
            return 4000m + 500m * peso;
        }

        // PASO 4: 1 día hasta 5 kg, 2 días si pesa más
        protected override int CalcularDiasEntrega(decimal peso)
        {
            return peso <= 5m ? 1 : 2;
        }

        // PASO 5
        protected override void RealizarDespacho()
        {
            Console.WriteLine("Paquete asignado a un repartidor en moto.");
        }

        // Hook del desafío: el express SÍ ofrece seguro.
        protected override bool PermiteSeguro()
        {
            return true;
        }
    }
}
