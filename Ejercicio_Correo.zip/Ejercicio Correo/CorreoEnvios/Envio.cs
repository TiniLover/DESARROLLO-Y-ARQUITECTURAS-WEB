﻿using System;
using System.Globalization;
using System.Linq;

namespace CorreoEnvios
{
    // =====================================================================
    // PATRÓN TEMPLATE METHOD — CLASE ABSTRACTA
    // ---------------------------------------------------------------------
    // ¿Por qué Template Method?
    //   Todos los envíos siguen el MISMO flujo y en el MISMO orden:
    //     1. Pedir y validar el peso          (fijo)
    //     2. Pedir y validar el destino       (fijo, pero QUÉ se pide y CÓMO se valida = hooks)
    //     3. Calcular el costo                (abstracto, devuelve un valor)
    //     4. Calcular los días de entrega     (abstracto, devuelve un valor)
    //     5. Despachar el paquete             (abstracto)
    //     6. Imprimir la etiqueta             (fijo, usa los valores de 1 a 4)
    //   El flujo se escribe UNA vez acá. Cada tipo de envío completa solo
    //   lo suyo y nadie puede cambiar el orden.
    // =====================================================================
    public abstract class Envio
    {
        private const decimal PesoMaximo = 30m;
        private const decimal RecargoSeguro = 0.10m; // 10%

        // -----------------------------------------------------------------
        // MÉTODO PLANTILLA: público y NO virtual.
        // Los valores que devuelve un paso se guardan en variables y se le
        // pasan a los pasos que los necesitan.
        // -----------------------------------------------------------------
        public void Despachar()
        {
            Console.WriteLine();
            Console.WriteLine($"===== {Nombre.ToUpper()} =====");

            decimal peso = PedirPeso();                    // 1. fijo
            string destino = PedirDestino();               // 2. fijo, usa hooks
            decimal costo = CalcularCosto(peso);           // 3. abstracto

            bool conSeguro = false;                        // desafío: hook
            if (PermiteSeguro())
            {
                conSeguro = PreguntarSeguro();
                if (conSeguro)
                {
                    costo = costo * (1 + RecargoSeguro);   // el seguro modifica el costo del paso 3
                }
            }

            int dias = CalcularDiasEntrega(peso);          // 4. abstracto
            RealizarDespacho();                            // 5. abstracto
            ImprimirEtiqueta(destino, peso, costo, dias, conSeguro); // 6. fijo
        }

        // ------------- OBLIGATORIO PARA CADA TIPO (abstract) -------------
        public abstract string Nombre { get; }

        // PASO 3: costo según el peso.
        protected abstract decimal CalcularCosto(decimal peso);

        // PASO 4: días de entrega (puede depender del peso).
        protected abstract int CalcularDiasEntrega(decimal peso);

        // PASO 5: qué se hace con el paquete.
        protected abstract void RealizarDespacho();

        // ------------- OPCIONAL (hooks: virtual con valor por defecto) -------------

        // Qué destino se pide. Por defecto, un código postal (lo usan el común
        // y el express, así que NO lo tienen que repetir). El internacional lo cambia.
        protected virtual string DatoDestino => "código postal (4 dígitos)";

        // Cómo se valida el destino. Por defecto: exactamente 4 dígitos.
        protected virtual bool DestinoValido(string destino)
        {
            return destino.Length == 4 && destino.All(char.IsDigit);
        }

        // Si este tipo de envío ofrece seguro. Por defecto, no.
        protected virtual bool PermiteSeguro()
        {
            return false;
        }

        // ------------- PASOS FIJOS (private) -------------

        // PASO 1: peso mayor a 0 y hasta 30 kg. Acepta coma o punto (2,5 o 2.5).
        private decimal PedirPeso()
        {
            while (true)
            {
                Console.Write($"Peso del paquete en kg (hasta {PesoMaximo}): ");
                string entrada = (Console.ReadLine() ?? "").Trim().Replace(',', '.');
                if (decimal.TryParse(entrada, NumberStyles.Number, CultureInfo.InvariantCulture, out decimal peso)
                    && peso > 0 && peso <= PesoMaximo)
                {
                    return peso;
                }
                Console.WriteLine($"Peso inválido. Tiene que ser mayor a 0 y como máximo {PesoMaximo} kg.");
            }
        }

        // PASO 2: el bucle "pedir hasta que sea válido" es el mismo para todos.
        private string PedirDestino()
        {
            while (true)
            {
                Console.Write($"Destino - {DatoDestino}: ");
                string destino = (Console.ReadLine() ?? "").Trim();
                if (DestinoValido(destino))
                {
                    return destino;
                }
                Console.WriteLine("Destino inválido. Intentá de nuevo.");
            }
        }

        // DESAFÍO: pregunta el seguro (solo se llama si PermiteSeguro() es true).
        private bool PreguntarSeguro()
        {
            while (true)
            {
                Console.Write("¿Querés agregar seguro? (s/n): ");
                string respuesta = (Console.ReadLine() ?? "").Trim().ToLower();
                if (respuesta == "s") return true;
                if (respuesta == "n") return false;
                Console.WriteLine("Respondé s o n.");
            }
        }

        // PASO 6: etiqueta común con todos los datos.
        private void ImprimirEtiqueta(string destino, decimal peso, decimal costo, int dias, bool conSeguro)
        {
            Console.WriteLine("============ ETIQUETA ============");
            Console.WriteLine($"Tipo de envío:  {Nombre}");
            Console.WriteLine($"Destino:        {destino}");
            Console.WriteLine($"Peso:           {peso} kg");
            Console.WriteLine($"Costo:          ${costo:N2}");
            Console.WriteLine($"Entrega en:     {dias} día(s)");
            if (conSeguro)
            {
                Console.WriteLine("Con seguro");
            }
            Console.WriteLine("==================================");
        }
    }
}
