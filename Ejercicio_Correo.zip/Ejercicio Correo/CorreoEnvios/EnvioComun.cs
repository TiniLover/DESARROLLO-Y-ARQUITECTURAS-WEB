﻿using System;

namespace CorreoEnvios
{
    // Subclase concreta: solo completa lo obligatorio.
    // No sobrescribe ningún hook:
    //   - destino: usa el código postal por defecto
    //   - seguro: usa el "no" por defecto
    public class EnvioComun : Envio
    {
        public override string Nombre => "Envío común";

        // PASO 3: $2.000 fijos + $300 por kg
        protected override decimal CalcularCosto(decimal peso)
        {
            return 2000m + 300m * peso;
        }

        // PASO 4: siempre 5 días
        protected override int CalcularDiasEntrega(decimal peso)
        {
            return 5;
        }

        // PASO 5
        protected override void RealizarDespacho()
        {
            Console.WriteLine("Paquete enviado al centro de distribución.");
        }
    }
}
