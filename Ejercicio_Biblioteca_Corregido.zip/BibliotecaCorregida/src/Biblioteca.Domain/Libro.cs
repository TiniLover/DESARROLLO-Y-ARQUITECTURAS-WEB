// =========================================================================
// PASO 1 - DOMINIO: entidad Libro
// -------------------------------------------------------------------------
// CORRECCIONES respecto de tu versión:
//  1) "Crear" recibía SOLO el título, y al autor y al año los cargaba
//     vacíos (string.Empty y 0). El enunciado pide título, autor y año.
//     -> Ahora Crear(titulo, autor, anioPublicacion).
//  2) Faltaban las REGLAS del enunciado:
//       - autor obligatorio
//       - año entre 1450 y el año actual
//       - no se puede prestar un libro que ya está prestado
//  3) "prestado" y "fechaAlta" se pasaban por el constructor: no hace falta,
//     un libro nuevo SIEMPRE arranca sin prestar y con la fecha de hoy.
//  4) Las propiedades que no cambian nunca (Titulo, Autor, Año, FechaAlta)
//     quedan con { get; } solo lectura, como en el demo.
// =========================================================================
namespace Biblioteca.Domain;

public sealed class Libro
{
    // Constructor PRIVADO: la única forma de crear un libro es Libro.Crear(...),
    // que valida antes. Así no puede existir un libro inválido.
    private Libro(Guid id, string titulo, string autor, int anioPublicacion, DateTime fechaAlta)
    {
        Id = id;
        Titulo = titulo;
        Autor = autor;
        AnioPublicacion = anioPublicacion;
        FechaAlta = fechaAlta;
        Prestado = false;   // todo libro nuevo arranca disponible
    }

    public Guid Id { get; }
    public string Titulo { get; }
    public string Autor { get; }
    public int AnioPublicacion { get; }
    public DateTime FechaAlta { get; }

    // Solo esta clase puede cambiarlo (con Prestar()).
    public bool Prestado { get; private set; }

    // ---------------------------------------------------------------------
    // Método fábrica: VALIDA las reglas 1 y 2 y crea el libro.
    // ---------------------------------------------------------------------
    public static Libro Crear(string titulo, string autor, int anioPublicacion)
    {
        // REGLA 1: título y autor obligatorios.
        if (string.IsNullOrWhiteSpace(titulo))
            throw new ArgumentException("El título es obligatorio.", nameof(titulo));

        if (string.IsNullOrWhiteSpace(autor))
            throw new ArgumentException("El autor es obligatorio.", nameof(autor));

        // REGLA 2: año entre 1450 (imprenta) y el año actual.
        int anioActual = DateTime.UtcNow.Year;
        if (anioPublicacion < 1450 || anioPublicacion > anioActual)
            throw new ArgumentException(
                $"El año de publicación debe estar entre 1450 y {anioActual}.", nameof(anioPublicacion));

        return new Libro(Guid.NewGuid(), titulo.Trim(), autor.Trim(), anioPublicacion, DateTime.UtcNow);
    }

    // ---------------------------------------------------------------------
    // REGLA 3: no se puede prestar un libro que ya está prestado.
    // ---------------------------------------------------------------------
    // CORRECCIÓN: antes ponía Prestado = true sin preguntar nada.
    // La regla va ACÁ, en el Dominio, porque es del propio libro.
    // Se usa InvalidOperationException: "la operación no se puede hacer en
    // el estado actual del objeto" (el dato no está mal, el ESTADO sí).
    public void Prestar()
    {
        if (Prestado)
            throw new InvalidOperationException("El libro ya está prestado.");

        Prestado = true;
    }
}
