// =========================================================================
// PASO 3 - APLICACIÓN: interfaz del repositorio (puerto)
// -------------------------------------------------------------------------
// CORRECCIONES:
//  1) Se agregaron los métodos que necesitan los endpoints opcionales:
//       GetByIdAsync -> buscar un libro por Id (devuelve null si no existe;
//                       el "?" en Libro? indica que PUEDE ser null)
//       UpdateAsync  -> guardar un cambio (cuando se presta el libro).
//     En memoria, UpdateAsync casi no hace nada (el objeto ya cambió),
//     pero con una base de datos real es OBLIGATORIO para grabar el cambio.
//  2) El parámetro se llamaba "task" (copiado del demo): ahora "libro".
// =========================================================================
using Biblioteca.Domain;

namespace Biblioteca.Application.Abstracciones;

public interface ILibroRepositorio
{
    Task AddAsync(Libro libro, CancellationToken cancellationToken = default);
    Task<IReadOnlyCollection<Libro>> GetAllAsync(CancellationToken cancellationToken = default);
    Task<Libro?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default);
    Task UpdateAsync(Libro libro, CancellationToken cancellationToken = default);
}
