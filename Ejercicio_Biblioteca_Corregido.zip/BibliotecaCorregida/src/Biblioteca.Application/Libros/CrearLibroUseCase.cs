// =========================================================================
// PASO 4 - CASO DE USO: Crear libro  (POST /libros)
// -------------------------------------------------------------------------
// CORRECCIONES:
//  1) ExecuteAsync recibía solo el título -> ahora título, autor y año.
//  2) Devolvía "LibroDTO" (la clase vacía) -> ahora LibroDto (el record).
//  3) Nombre: "CrearLibro" -> "CrearLibroUseCase", para que se entienda
//     que es un caso de uso (como CreateTaskUseCase del demo).
// =========================================================================
using Biblioteca.Application.Abstracciones;
using Biblioteca.Domain;

namespace Biblioteca.Application.Libros;

// Constructor primario = inyección del repositorio por constructor.
public sealed class CrearLibroUseCase(ILibroRepositorio repositorio)
{
    public async Task<LibroDto> ExecuteAsync(
        string titulo, string autor, int anioPublicacion,
        CancellationToken cancellationToken = default)
    {
        // 1) El DOMINIO valida y crea (si algo está mal, lanza ArgumentException).
        var libro = Libro.Crear(titulo, autor, anioPublicacion);

        // 2) Guardar a través de la interfaz.
        await repositorio.AddAsync(libro, cancellationToken);

        // 3) Devolver DTO (nunca la entidad).
        return libro.ToDto();
    }
}
