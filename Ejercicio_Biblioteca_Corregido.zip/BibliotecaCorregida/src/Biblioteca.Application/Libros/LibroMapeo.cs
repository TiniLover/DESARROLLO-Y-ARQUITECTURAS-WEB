// =========================================================================
// MAPEO Entidad -> DTO (en UN solo lugar)
// -------------------------------------------------------------------------
// En el demo, ToDto estaba repetido en cada caso de uso. Acá hay 4 casos de
// uso, así que se pone una sola vez y todos lo usan. Si mañana se agrega
// un campo al DTO, se cambia solo acá.
// "internal" = solo se puede usar dentro del proyecto Application.
// "this Libro libro" = método de extensión: se llama como libro.ToDto().
// =========================================================================
using Biblioteca.Domain;

namespace Biblioteca.Application.Libros;

internal static class LibroMapeo
{
    public static LibroDto ToDto(this Libro libro) =>
        new(libro.Id, libro.Titulo, libro.Autor, libro.AnioPublicacion, libro.Prestado, libro.FechaAlta);
}
