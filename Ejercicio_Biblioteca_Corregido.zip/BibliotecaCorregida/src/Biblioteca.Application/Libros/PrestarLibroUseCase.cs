// =========================================================================
// EXTRA 2 - CASO DE USO: Prestar libro  (POST /libros/{id}/prestar)
// -------------------------------------------------------------------------
// No estaba hecho. Pasos:
//   1) Buscar el libro. Si no existe -> null (la API responde 404).
//   2) Llamar a libro.Prestar(): el DOMINIO valida la regla 3 y, si ya
//      estaba prestado, lanza InvalidOperationException (la API responde 400).
//   3) Guardar el cambio con UpdateAsync.
//   4) Devolver el DTO actualizado.
// =========================================================================
using Biblioteca.Application.Abstracciones;

namespace Biblioteca.Application.Libros;

public sealed class PrestarLibroUseCase(ILibroRepositorio repositorio)
{
    public async Task<LibroDto?> ExecuteAsync(Guid id, CancellationToken cancellationToken = default)
    {
        var libro = await repositorio.GetByIdAsync(id, cancellationToken);
        if (libro is null)
            return null;

        libro.Prestar();   // la regla vive en la entidad, no acá

        await repositorio.UpdateAsync(libro, cancellationToken);
        return libro.ToDto();
    }
}
