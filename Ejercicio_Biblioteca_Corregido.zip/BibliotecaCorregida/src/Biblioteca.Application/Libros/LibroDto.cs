// =========================================================================
// PASO 2 - APLICACIÓN: DTO de salida
// -------------------------------------------------------------------------
// CORRECCIÓN IMPORTANTE: tenías el record ADENTRO de una clase:
//
//     public class LibroDTO
//     {
//         public sealed record LibroDto(...);
//     }
//
// Eso crea DOS tipos: "LibroDTO" (una clase VACÍA, sin propiedades ni
// constructor) y "LibroDTO.LibroDto" (el record de verdad). Como los casos
// de uso decían "LibroDTO", hacían new(...) sobre la clase vacía -> error
// "LibroDTO no contiene un constructor que tome 6 argumentos".
// El record va SOLO, directamente en el namespace (como TaskDto del demo).
// =========================================================================
namespace Biblioteca.Application.Libros;

public sealed record LibroDto(
    Guid Id,
    string Titulo,
    string Autor,
    int AnioPublicacion,
    bool Prestado,
    DateTime FechaAlta);
