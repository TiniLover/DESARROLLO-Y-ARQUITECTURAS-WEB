// =========================================================================
// PASO 5 - CASO DE USO: Listar libros  (GET /libros)
// CORRECCIÓN: devolvía la clase vacía "LibroDTO"; nombre "ObtenerLibros"
// -> "ListarLibrosUseCase"; variable "tasks" -> "libros".
// =========================================================================
using Biblioteca.Application.Abstracciones;

namespace Biblioteca.Application.Libros;

public sealed class ListarLibrosUseCase(ILibroRepositorio repositorio)
{
    public async Task<IReadOnlyCollection<LibroDto>> ExecuteAsync(CancellationToken cancellationToken = default)
    {
        var libros = await repositorio.GetAllAsync(cancellationToken);

        // Cada entidad -> DTO.
        return libros.Select(libro => libro.ToDto()).ToArray();
    }
}
