// =========================================================================
// EXTRA 1 - CASO DE USO: Buscar libro por Id  (GET /libros/{id})
// -------------------------------------------------------------------------
// No estaba hecho. Devuelve "LibroDto?" -> null si el libro no existe.
// La API decide qué hacer con ese null (responder 404 Not Found).
// =========================================================================
using Biblioteca.Application.Abstracciones;

namespace Biblioteca.Application.Libros;

public sealed class ObtenerLibroPorIdUseCase(ILibroRepositorio repositorio)
{
    public async Task<LibroDto?> ExecuteAsync(Guid id, CancellationToken cancellationToken = default)
    {
        var libro = await repositorio.GetByIdAsync(id, cancellationToken);

        // "?." = si libro es null, devuelve null sin dar error;
        //        si no, llama a ToDto().
        return libro?.ToDto();
    }
}
