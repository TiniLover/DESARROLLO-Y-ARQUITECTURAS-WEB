// =========================================================================
// PASO 6 - INFRAESTRUCTURA: repositorio en memoria (adaptador)
// -------------------------------------------------------------------------
// CORRECCIONES:
//  1) Había una línea con un "." suelto dentro de AddAsync
//     (quedó al borrar un comentario) -> error de sintaxis que rompía todo
//     el proyecto. Se borró.
//  2) Faltaban GetByIdAsync y UpdateAsync (los pide la interfaz ahora).
//  3) El proyecto se llamaba "Biblioteca.Infraestructura1" y además había
//     otro "Biblioteca.Infraestructura" vacío de .NET Framework.
//     Quedó UNO solo: Biblioteca.Infrastructure (.NET 8).
//  4) "tasks" -> "libros".
// =========================================================================
using System.Collections.Concurrent;
using Biblioteca.Application.Abstracciones;
using Biblioteca.Domain;

namespace Biblioteca.Infrastructure;

public sealed class LibroRepositorioEnMemoria : ILibroRepositorio
{
    // Diccionario seguro para varios pedidos web al mismo tiempo. Clave = Id.
    private readonly ConcurrentDictionary<Guid, Libro> libros = new();

    public Task AddAsync(Libro libro, CancellationToken cancellationToken = default)
    {
        libros[libro.Id] = libro;
        return Task.CompletedTask;
    }

    public Task<IReadOnlyCollection<Libro>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        IReadOnlyCollection<Libro> resultado = libros.Values.OrderBy(l => l.FechaAlta).ToArray();
        return Task.FromResult(resultado);
    }

    public Task<Libro?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
    {
        // TryGetValue: si encuentra el Id, lo pone en "libro" y devuelve true.
        libros.TryGetValue(id, out var libro);
        return Task.FromResult(libro);   // null si no lo encontró
    }

    public Task UpdateAsync(Libro libro, CancellationToken cancellationToken = default)
    {
        // En memoria el objeto ya está modificado; igual se vuelve a guardar
        // para que el código sea el mismo que con una base de datos.
        libros[libro.Id] = libro;
        return Task.CompletedTask;
    }
}
