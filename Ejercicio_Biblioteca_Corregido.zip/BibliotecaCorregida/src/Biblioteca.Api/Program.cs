// =========================================================================
// PASO 7 - API: inyección de dependencias + endpoints
// -------------------------------------------------------------------------
// CORRECCIONES (este era el error MÁS GRANDE):
//  1) El Program.cs seguía siendo el de la PLANTILLA de Visual Studio
//     (el ejemplo del clima: /weatherforecast). Nunca se registraron las
//     dependencias ni se crearon los endpoints de libros.
//  2) El proyecto de la API NO tenía referencias a Application ni a
//     Infrastructure (en su .csproj). Sin eso no puede usar los casos de
//     uso ni el repositorio. (Click derecho > Agregar > Referencia de proyecto.)
//  3) Sobraba "app.UseHttpsRedirection()" de la plantilla: con el perfil
//     http redirige a https y en Swagger puede dar error. Se sacó (el demo
//     tampoco lo tiene).
// =========================================================================
using Biblioteca.Application.Abstracciones;
using Biblioteca.Application.Libros;
using Biblioteca.Infrastructure;

var builder = WebApplication.CreateBuilder(args);

// ---------------------------------------------------------------------
// 7.1 INYECCIÓN DE DEPENDENCIAS (único punto de composición)
// ---------------------------------------------------------------------
// Singleton: UNA sola instancia del repositorio en memoria. Si fuera Scoped,
// cada pedido tendría un repositorio nuevo y vacío -> se perderían los libros.
builder.Services.AddSingleton<ILibroRepositorio, LibroRepositorioEnMemoria>();

// Casos de uso: uno nuevo por pedido HTTP.
builder.Services.AddScoped<CrearLibroUseCase>();
builder.Services.AddScoped<ListarLibrosUseCase>();
builder.Services.AddScoped<ObtenerLibroPorIdUseCase>();
builder.Services.AddScoped<PrestarLibroUseCase>();

// Swagger.
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// ---------------------------------------------------------------------
// 7.2 GET /libros -> listar (obligatorio)
// ---------------------------------------------------------------------
app.MapGet("/libros", async (ListarLibrosUseCase useCase, CancellationToken ct) =>
{
    var libros = await useCase.ExecuteAsync(ct);
    return Results.Ok(libros);                      // 200
})
.WithName("ListarLibros")
.WithOpenApi();

// ---------------------------------------------------------------------
// 7.3 POST /libros -> crear (obligatorio)
// ---------------------------------------------------------------------
app.MapPost("/libros", async (CrearLibroRequest request, CrearLibroUseCase useCase, CancellationToken ct) =>
{
    try
    {
        var libro = await useCase.ExecuteAsync(request.Titulo, request.Autor, request.AnioPublicacion, ct);
        return Results.Created($"/libros/{libro.Id}", libro);   // 201
    }
    catch (ArgumentException ex)
    {
        // El Dominio rechazó algún dato (título/autor vacío, año inválido).
        return Results.BadRequest(new { error = ex.Message });  // 400
    }
})
.WithName("CrearLibro")
.WithOpenApi();

// ---------------------------------------------------------------------
// 7.4 GET /libros/{id} -> buscar por Id (extra)
// ---------------------------------------------------------------------
// "{id:guid}" = la ruta solo acepta un Guid válido en esa posición.
app.MapGet("/libros/{id:guid}", async (Guid id, ObtenerLibroPorIdUseCase useCase, CancellationToken ct) =>
{
    var libro = await useCase.ExecuteAsync(id, ct);
    return libro is null
        ? Results.NotFound(new { error = "No existe un libro con ese Id." })  // 404
        : Results.Ok(libro);                                                  // 200
})
.WithName("ObtenerLibro")
.WithOpenApi();

// ---------------------------------------------------------------------
// 7.5 POST /libros/{id}/prestar -> prestar (extra)
// ---------------------------------------------------------------------
app.MapPost("/libros/{id:guid}/prestar", async (Guid id, PrestarLibroUseCase useCase, CancellationToken ct) =>
{
    try
    {
        var libro = await useCase.ExecuteAsync(id, ct);
        return libro is null
            ? Results.NotFound(new { error = "No existe un libro con ese Id." })  // 404
            : Results.Ok(libro);                                                  // 200
    }
    catch (InvalidOperationException ex)
    {
        // Regla 3 del Dominio: ya estaba prestado.
        return Results.BadRequest(new { error = ex.Message });                    // 400
    }
})
.WithName("PrestarLibro")
.WithOpenApi();

app.Run();

// ---------------------------------------------------------------------
// 7.6 DTO de ENTRADA del POST: { "titulo": "...", "autor": "...", "anioPublicacion": 1985 }
// ---------------------------------------------------------------------
public sealed record CrearLibroRequest(string Titulo, string Autor, int AnioPublicacion);
