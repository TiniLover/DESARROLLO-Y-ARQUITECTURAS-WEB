// =========================================================================
// PASO 8 - PRUEBAS
// -------------------------------------------------------------------------
// CORRECCIONES respecto de tu LibroTareas.cs:
//  1) Llamaba a Libro.Create(...) pero el método se llama Libro.Crear(...).
//  2) Usaba result.Title, pero el DTO tiene "Titulo" (en castellano).
//  3) Faltaban las pruebas del enunciado: año 3000 y prestar dos veces.
//  4) Nombres: FakeTaskRepository -> RepositorioFalso; Tasks -> Libros.
// =========================================================================
using Biblioteca.Application.Abstracciones;
using Biblioteca.Application.Libros;
using Biblioteca.Domain;

namespace Biblioteca.Tests;

public sealed class LibroTests
{
    // ---- Pruebas del DOMINIO ----

    [Fact]
    public void Crear_sin_titulo_lanza_excepcion()
    {
        var accion = () => Libro.Crear(" ", "Borges", 1944);
        Assert.Throws<ArgumentException>(accion);
    }

    [Fact]
    public void Crear_con_anio_3000_lanza_excepcion()
    {
        var accion = () => Libro.Crear("Ficciones", "Borges", 3000);
        Assert.Throws<ArgumentException>(accion);
    }

    [Fact]
    public void Prestar_dos_veces_lanza_excepcion()
    {
        var libro = Libro.Crear("Ficciones", "Borges", 1944);
        libro.Prestar();                                   // primera vez: OK

        Assert.Throws<InvalidOperationException>(() => libro.Prestar());  // segunda: error
    }

    // ---- Prueba del CASO DE USO (con repositorio falso) ----

    [Fact]
    public async Task Crear_libro_guarda_y_devuelve_dto()
    {
        // PREPARAR
        var repositorio = new RepositorioFalso();
        var useCase = new CrearLibroUseCase(repositorio);

        // EJECUTAR
        var resultado = await useCase.ExecuteAsync("  Ficciones  ", "Borges", 1944);

        // VERIFICAR
        Assert.Equal("Ficciones", resultado.Titulo);   // se le sacaron los espacios
        Assert.False(resultado.Prestado);              // arranca sin prestar
        Assert.Single(repositorio.Libros);             // quedó guardado 1 libro
    }

    // Repositorio FALSO: implementa la interfaz con una lista pública para
    // que la prueba pueda revisar qué se guardó.
    private sealed class RepositorioFalso : ILibroRepositorio
    {
        public List<Libro> Libros { get; } = [];

        public Task AddAsync(Libro libro, CancellationToken cancellationToken = default)
        {
            Libros.Add(libro);
            return Task.CompletedTask;
        }

        public Task<IReadOnlyCollection<Libro>> GetAllAsync(CancellationToken cancellationToken = default)
            => Task.FromResult<IReadOnlyCollection<Libro>>(Libros);

        public Task<Libro?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
            => Task.FromResult(Libros.FirstOrDefault(l => l.Id == id));

        public Task UpdateAsync(Libro libro, CancellationToken cancellationToken = default)
            => Task.CompletedTask;
    }
}
