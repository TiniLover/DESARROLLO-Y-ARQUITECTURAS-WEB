// =========================================================================
// API - Inyección de dependencias + endpoints   (ANTES: WebApplication1/Program.cs)
// -------------------------------------------------------------------------
// Errores de COMPILACIÓN de este archivo: E1, E3, E4. Arreglalos EN ESE
// ORDEN (E1 tapa a los demás).
// NOTA: los números de "Línea" son los de TU archivo original.
// ✅ La inyección de dependencias (Singleton + Scoped) estaba BIEN.
// =========================================================================

// ❌ ERROR L9 - Sobraba "using Aplication.NewFolder;"
//    ✅ CÓMO CORREGIRLO: cuando arreglás el namespace de CrearReserva (ver
//       CrearReservaUseCase.cs), borrá este using.
using Futbol.Application.Abstracciones;
using Futbol.Application.Reservas;
using Futbol.Infrastructure;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSingleton<IReservaRepositorio, ReservaRepositorioEnMemoria>();

// ❌ ERROR L5 - Faltaba registrar el caso de uso de cancelar
//    ✅ CÓMO CORREGIRLO: agregá "builder.Services.AddScoped<CancelarReservaUseCase>();"
//    ANTES: CrearReserva, ListarReserva, ReservarCancha (y nada para cancelar)
builder.Services.AddScoped<CrearReservaUseCase>();
builder.Services.AddScoped<ListarReservasUseCase>();
builder.Services.AddScoped<ConfirmarReservaUseCase>();
builder.Services.AddScoped<CancelarReservaUseCase>();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// GET /reservas  (✅ estaba BIEN)
app.MapGet("/reservas", async (ListarReservasUseCase useCase, CancellationToken ct) =>
    Results.Ok(await useCase.ExecuteAsync(ct)))
.WithName("ListarReservas")
.WithOpenApi();

// -------------------------------------------------------------------------
// POST /reservas
//
// ❌ ERROR E3  (aparece cuando arreglás E1)
//    TAL CUAL APARECÍA EN VISUAL STUDIO (Lista de errores, 3 veces):
//      Gravedad:    Error
//      Código:      CS1061
//      Descripción: "CrearReserva" no contiene una definición para "Cliente" ni un método de extensión accesible "Cliente" que acepte un primer argumento del tipo "CrearReserva" (¿falta alguna directiva using o una referencia de ensamblado?)
//      (y lo mismo para "numCancha" y "precio")
//      Proyecto:    WebApplication1
//      Archivo:     Program.cs
//      Línea:       37
//    QUÉ PASABA: el primer parámetro del MapPost decía "CrearReserva request".
//                CrearReserva es el CASO DE USO, no el request. El caso de uso
//                no tiene "Cliente", "numCancha" ni "precio": esos están en el
//                record del final del archivo.
//    ✅ CÓMO CORREGIRLO: en la línea del MapPost, cambiá el PRIMER
//       "CrearReserva" por el nombre del record:
//           (CrearReserva request, ...)  ->  (CrearReservaRequest request, ...)
//    ANTES:  app.MapPost("/reservas", async (CrearReserva request, CrearReserva useCase, ...
//
// ❌ ERROR E4  (aparece cuando arreglás E3)
//    TAL CUAL APARECÍA EN VISUAL STUDIO:
//      Gravedad:    Error
//      Código:      CS7036
//      Descripción: No se ha dado ningún argumento que corresponda al parámetro requerido "estado" de "CrearReserva.ExecuteAsync(string, int, decimal, DateTime, EnumEstado, CancellationToken)"
//      Proyecto:    WebApplication1
//      Archivo:     Program.cs
//      Línea:       37
//    QUÉ PASABA: el caso de uso pedía 5 datos (cliente, cancha, precio,
//                fechaHora, estado) y acá se le pasaban 3. Faltaba la FECHA
//                del partido (el record no la tenía) y el estado no tendría
//                que pedirse (error L1).
//    ✅ CÓMO CORREGIRLO:
//       1. Agregá "DateTime FechaHora" al record del final del archivo.
//       2. Sacá el estado del caso de uso (ver CrearReservaUseCase.cs).
//       3. Acá pasá: request.Cliente, request.NumeroCancha, request.FechaHora, request.Precio.
//    ANTES:  useCase.ExecuteAsync(request.Cliente, request.numCancha, request.precio, ct);
// -------------------------------------------------------------------------
app.MapPost("/reservas", async (CrearReservaRequest request, CrearReservaUseCase useCase, CancellationToken ct) =>
{
    try
    {
        var reserva = await useCase.ExecuteAsync(
            request.Cliente, request.NumeroCancha, request.FechaHora, request.Precio, ct);
        return Results.Created($"/reservas/{reserva.Id}", reserva);      // 201
    }
    catch (ArgumentException ex)
    {
        return Results.BadRequest(new { error = ex.Message });           // 400
    }
})
.WithName("CrearReserva")
.WithOpenApi();

// -------------------------------------------------------------------------
// POST /reservas/{id}/confirmar
//
// ❌ ERROR E1  (el PRIMERO que hay que arreglar)
//    TAL CUAL APARECÍA EN VISUAL STUDIO:
//      Gravedad:    Error
//      Código:      CS1525
//      Descripción: El término de expresión ':' no es válido
//      Proyecto:    WebApplication1
//      Archivo:     Program.cs
//      Línea:       55
//    QUÉ PASABA: al final de la línea del "? Results.NotFound(...)" quedó
//                una barra "/" suelta (seguramente quedó de borrar un
//                comentario "// 404"). C# la toma como una DIVISIÓN y espera
//                un número después; como encuentra ":", da error.
//    ✅ CÓMO CORREGIRLO: andá a la línea 55 y borrá la "/" del final.
//    ANTES:  ? Results.NotFound(new { error = "No existe un pedido con ese Id." })   /
//
// ❌ ERROR L6 - Ruta y nombres copiados de Pedidos
//    QUÉ PASABA: la ruta era "/despachar", el nombre "DespacharPedido" y el
//                mensaje decía "pedido". En este ejercicio es CONFIRMAR una
//                RESERVA.
//    ✅ CÓMO CORREGIRLO: "/despachar" -> "/confirmar", "DespacharPedido" ->
//       "ConfirmarReserva", "pedido" -> "reserva" (Ctrl+H dentro del bloque).
//
// ❌ ERROR L3 - La API no atrapaba el error del Dominio
//    QUÉ PASABA: el catch era de InvalidOperationException (bien), pero el
//                Dominio lanzaba ArgumentException -> respondía 500.
//    ✅ CÓMO CORREGIRLO: no se toca acá; se arregla en Reserva.cs cambiando
//       el throw de Confirmar a InvalidOperationException.
// -------------------------------------------------------------------------
app.MapPost("/reservas/{id:guid}/confirmar", async (Guid id, ConfirmarReservaUseCase useCase, CancellationToken ct) =>
{
    try
    {
        var reserva = await useCase.ExecuteAsync(id, ct);
        return reserva is null
            ? Results.NotFound(new { error = "No existe una reserva con ese Id." })   // 404
            : Results.Ok(reserva);                                                     // 200
    }
    catch (InvalidOperationException ex)        // no estaba Pendiente
    {
        return Results.BadRequest(new { error = ex.Message });                        // 400
    }
})
.WithName("ConfirmarReserva")
.WithOpenApi();

// -------------------------------------------------------------------------
// POST /reservas/{id}/cancelar
// ❌ ERROR L6 + L5 - Ruta "/entregar" (de Pedidos) y usaba ReservarCancha
//    QUÉ PASABA: este endpoint CONFIRMABA (llamaba al mismo caso de uso que
//                el de arriba), así que no había forma de cancelar.
//    ✅ CÓMO CORREGIRLO:
//       1. "/entregar" -> "/cancelar".
//       2. "ReservarCancha useCase" -> "CancelarReservaUseCase useCase".
//       3. .WithName("EntregarReserva") -> .WithName("CancelarReserva").
// -------------------------------------------------------------------------
app.MapPost("/reservas/{id:guid}/cancelar", async (Guid id, CancelarReservaUseCase useCase, CancellationToken ct) =>
{
    try
    {
        var reserva = await useCase.ExecuteAsync(id, ct);
        return reserva is null
            ? Results.NotFound(new { error = "No existe una reserva con ese Id." })   // 404
            : Results.Ok(reserva);                                                     // 200
    }
    catch (InvalidOperationException ex)        // ya estaba cancelada
    {
        return Results.BadRequest(new { error = ex.Message });                        // 400
    }
})
.WithName("CancelarReserva")
.WithOpenApi();

app.Run();

// -------------------------------------------------------------------------
// DTO DE ENTRADA
// ❌ ERROR E4 + L7
//    QUÉ PASABA:
//      - Faltaba "FechaHora" (por eso el caso de uso no recibía la fecha: E4).
//      - Se llamaba "CrearPedidoRequest" (copiado de Pedidos).
//      - "numCancha" y "precio" en minúscula (la convención es mayúscula;
//        "Cliente" sí estaba bien).
//    ✅ CÓMO CORREGIRLO:
//       1. Renombrá CrearPedidoRequest -> CrearReservaRequest (Ctrl+R, Ctrl+R).
//       2. Parámetros con mayúscula: NumeroCancha, Precio.
//       3. Agregá "DateTime FechaHora".
//    ANTES:  public sealed record CrearPedidoRequest(string Cliente, int numCancha, decimal precio);
// -------------------------------------------------------------------------
public sealed record CrearReservaRequest(string Cliente, int NumeroCancha, DateTime FechaHora, decimal Precio);
