// =========================================================================
// APLICACIÓN - Interfaz del repositorio
// ✅ Estaba BIEN (sin errores). Solo cambia el namespace.
// =========================================================================
using Futbol.Domain;

namespace Futbol.Application.Abstracciones;

public interface IReservaRepositorio
{
    Task AddAsync(Reserva reserva, CancellationToken cancellationToken = default);
    Task<IReadOnlyCollection<Reserva>> GetAllAsync(CancellationToken cancellationToken = default);
    Task<Reserva?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default);
    Task UpdateAsync(Reserva reserva, CancellationToken cancellationToken = default);
}
