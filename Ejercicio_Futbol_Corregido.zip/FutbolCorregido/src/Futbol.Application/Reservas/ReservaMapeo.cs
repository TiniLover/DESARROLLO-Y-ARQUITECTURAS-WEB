// =========================================================================
// APLICACIÓN - Mapeo Entidad -> DTO
// ✅ Estaba BIEN (devuelve el DTO).
// =========================================================================
using Futbol.Domain;

namespace Futbol.Application.Reservas;

internal static class ReservaMapeo
{
    // ❌ ERROR L8 (continuación)
    //    ✅ CÓMO CORREGIRLO: "reserva.Estado" -> "reserva.Estado.ToString()"
    //       y agregar "reserva.FechaAlta" al final (mismo orden que el DTO).
    //    ANTES:  new(reserva.Id, reserva.Cliente, reserva.NumCancha,
    //                reserva.Precio, reserva.Estado, reserva.FechaHora);
    public static ReservaDto ToDto(this Reserva reserva) =>
        new(reserva.Id, reserva.Cliente, reserva.NumeroCancha, reserva.FechaHora,
            reserva.Precio, reserva.Estado.ToString(), reserva.FechaAlta);
}
