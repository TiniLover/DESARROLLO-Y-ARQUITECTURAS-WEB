// =========================================================================
// APLICACIÓN - Caso de uso: Crear reserva   (ANTES: CrearReserva.cs)
// =========================================================================
using Futbol.Application.Abstracciones;
using Futbol.Domain;

// -------------------------------------------------------------------------
// ❌ ERROR L9 - Namespace "Aplication.NewFolder"
//    QUÉ PASABA: creaste la carpeta como "NewFolder", le agregaste la clase
//                y DESPUÉS renombraste la carpeta a "Casos de uso". Visual
//                Studio NO cambia el namespace de las clases que ya existen.
//                Por eso esta clase quedó en otro namespace que el resto y
//                tuviste que agregar "using Aplication.NewFolder;" en la API
//                y en las pruebas.
//    ✅ CÓMO CORREGIRLO:
//       1. Cambiá "namespace Aplication.NewFolder" por el mismo que tienen
//          las otras clases de la carpeta.
//       2. Borrá los "using Aplication.NewFolder;" de Program.cs y de las pruebas.
//    TIP: poné el nombre a la carpeta ANTES de crear las clases adentro.
// -------------------------------------------------------------------------
namespace Futbol.Application.Reservas;

public sealed class CrearReservaUseCase(IReservaRepositorio repositorio)
{
    // ❌ ERROR L1 - Recibía "EnumEstado estado"
    //    ✅ CÓMO CORREGIRLO: borrá ", EnumEstado estado" de los parámetros y
    //       de la llamada a Reserva.Crear(...).
    //    ANTES:  ExecuteAsync(string cliente, int numCancha, decimal precio,
    //                         DateTime fechaHora, EnumEstado estado, ...)
    public async Task<ReservaDto> ExecuteAsync(
        string cliente, int numeroCancha, DateTime fechaHora, decimal precio,
        CancellationToken cancellationToken = default)
    {
        var reserva = Reserva.Crear(cliente, numeroCancha, fechaHora, precio);
        await repositorio.AddAsync(reserva, cancellationToken);
        return reserva.ToDto();
    }
}
