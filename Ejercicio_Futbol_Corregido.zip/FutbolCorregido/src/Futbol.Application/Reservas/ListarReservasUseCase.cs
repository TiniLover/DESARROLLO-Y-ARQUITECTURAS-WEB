// =========================================================================
// APLICACIÓN - Caso de uso: Listar reservas   (ANTES: ListarReserva.cs)
// ✅ Estaba BIEN. Solo el nombre: "ListarReserva" -> "ListarReservasUseCase"
//    (lista VARIAS reservas -> en plural).
// =========================================================================
using Futbol.Application.Abstracciones;

namespace Futbol.Application.Reservas;

public sealed class ListarReservasUseCase(IReservaRepositorio repositorio)
{
    public async Task<IReadOnlyCollection<ReservaDto>> ExecuteAsync(CancellationToken cancellationToken = default)
    {
        var reservas = await repositorio.GetAllAsync(cancellationToken);
        return reservas.Select(r => r.ToDto()).ToArray();
    }
}
