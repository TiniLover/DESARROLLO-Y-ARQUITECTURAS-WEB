// =========================================================================
// APLICACIÓN - Caso de uso: Cancelar
// -------------------------------------------------------------------------
// ❌ ERROR L5 - Este caso de uso NO EXISTÍA
//    QUÉ PASABA: los dos endpoints (despachar y entregar) usaban el mismo
//                caso de uso "ReservarCancha", así que no había forma de cancelar.
//    ✅ CÓMO CORREGIRLO:
//       1. Agregar > Clase > "CancelarReservaUseCase.cs" (cambiá internal -> public).
//       2. Copiá el contenido de ConfirmarReservaUseCase.
//       3. Cambiá "reserva.Confirmar()" por "reserva.Cancelar()".
//       4. Registralo en Program.cs:  builder.Services.AddScoped<CancelarReservaUseCase>();
// =========================================================================
using Futbol.Application.Abstracciones;

namespace Futbol.Application.Reservas;

public sealed class CancelarReservaUseCase(IReservaRepositorio repositorio)
{
    public async Task<ReservaDto?> ExecuteAsync(Guid id, CancellationToken cancellationToken = default)
    {
        var reserva = await repositorio.GetByIdAsync(id, cancellationToken);
        if (reserva is null)
            return null;

        reserva.Cancelar();

        await repositorio.UpdateAsync(reserva, cancellationToken);
        return reserva.ToDto();
    }
}
