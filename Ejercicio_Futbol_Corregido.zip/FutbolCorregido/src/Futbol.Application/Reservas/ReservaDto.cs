// =========================================================================
// APLICACIÓN - DTO de salida   (ANTES: ReservaDTO.cs)
// ✅ Es public y es un record: bien.
// =========================================================================
namespace Futbol.Application.Reservas;

// -------------------------------------------------------------------------
// ❌ ERROR L8 - El estado iba como enum y faltaba FechaAlta (igual que en Pedidos)
//    QUÉ PASABA:
//      - Con "EnumEstado Estado", Swagger muestra un NÚMERO ("estado": 0) y
//        el DTO depende de un tipo del Dominio.
//      - Faltaba FechaAlta.
//    ✅ CÓMO CORREGIRLO:
//       1. Cambiá "EnumEstado Estado" por "string Estado".
//       2. Agregá ", DateTime FechaAlta".
//       3. Borrá el "using Domain;" de arriba.
//       4. En ReservaMapeo.cs usá reserva.Estado.ToString().
//    ANTES:  public sealed record ReservaDTO(Guid Id, string Cliente,
//                int NumCancha, decimal Precio, EnumEstado Estado, DateTime FechaHora);
// -------------------------------------------------------------------------
public sealed record ReservaDto(
    Guid Id,
    string Cliente,
    int NumeroCancha,
    DateTime FechaHora,
    decimal Precio,
    string Estado,
    DateTime FechaAlta);
