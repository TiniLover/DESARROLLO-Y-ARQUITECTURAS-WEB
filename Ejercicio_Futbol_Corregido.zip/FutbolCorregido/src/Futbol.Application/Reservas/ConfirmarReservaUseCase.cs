// =========================================================================
// APLICACIÓN - Caso de uso: Confirmar   (ANTES: ReservarCancha.cs)
// -------------------------------------------------------------------------
// ❌ ERROR L3 (nombre) - "ReservarCancha" -> "ConfirmarReservaUseCase"
//    ✅ CÓMO CORREGIRLO: Ctrl+R, Ctrl+R sobre la clase, y adentro cambiá
//       "reserva.Reservar()" por "reserva.Confirmar()".
//    La estructura (buscar, null -> 404, acción, guardar) estaba BIEN.
// =========================================================================
using Futbol.Application.Abstracciones;

namespace Futbol.Application.Reservas;

public sealed class ConfirmarReservaUseCase(IReservaRepositorio repositorio)
{
    public async Task<ReservaDto?> ExecuteAsync(Guid id, CancellationToken cancellationToken = default)
    {
        var reserva = await repositorio.GetByIdAsync(id, cancellationToken);
        if (reserva is null)
            return null;

        reserva.Confirmar();

        await repositorio.UpdateAsync(reserva, cancellationToken);
        return reserva.ToDto();
    }
}
