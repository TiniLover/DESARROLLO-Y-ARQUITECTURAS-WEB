// =========================================================================
// DOMINIO - Enum de estados   (ANTES: Domain/EnumEstado.cs)
// -------------------------------------------------------------------------
// ✅ ¡BIEN! Los 3 estados están bien escritos y sin el ";" de más.
//
// ❌ ERROR L11 - Nombre del enum
//    QUÉ PASABA: "EnumEstado" no dice de QUÉ es el estado (mismo detalle que
//                en Pedidos). No da error, pero el nombre tiene que describir
//                lo que representa.
//    ✅ CÓMO CORREGIRLO: click en "EnumEstado" > Ctrl+R, Ctrl+R >
//       "EstadoReserva" > Enter (se renombra en todo el proyecto).
// =========================================================================
namespace Futbol.Domain;

public enum EstadoReserva
{
    Pendiente,
    Confirmada,
    Cancelada
}
