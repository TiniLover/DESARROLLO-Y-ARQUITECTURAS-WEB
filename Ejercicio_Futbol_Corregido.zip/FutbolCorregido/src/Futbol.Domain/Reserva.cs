// =========================================================================
// DOMINIO - Entidad Reserva   (ANTES: Domain/Reserva.cs)
// Errores de LÓGICA de este archivo: L1, L2, L3, L4, L5 (Visual Studio no
// los marca, pero no cumplen la consigna).
// ✅ Las reglas 1, 2 y 3 (cliente, cancha 1-5, precio > 0) estaban BIEN.
// =========================================================================

// ❌ ERROR L10 - Sobraba "using static System.Runtime.InteropServices.JavaScript.JSType;"
//    QUÉ PASABA: Visual Studio lo agregó solo (seguramente al aceptar una
//                sugerencia del autocompletado). No se usa para nada.
//    ✅ CÓMO CORREGIRLO: borrá esa línea. Truco: Ctrl+R, Ctrl+G borra
//       todos los "using" que no se usan en el archivo.
namespace Futbol.Domain;

public sealed class Reserva
{
    // ---------------------------------------------------------------------
    // ❌ ERROR L1 - El constructor recibía el estado
    //    QUÉ PASABA: por la regla 5, toda reserva nueva arranca en Pendiente;
    //                el estado no viene de afuera (igual que en Pedidos).
    //    ✅ CÓMO CORREGIRLO:
    //       1. Borrá ", EnumEstado estado" de los parámetros del constructor.
    //       2. Cambiá "Estado = estado;" por "Estado = EstadoReserva.Pendiente;".
    //
    // ❌ ERROR L4 - Faltaba FechaAlta (está en la entidad de la consigna)
    //    ✅ CÓMO CORREGIRLO: agregá la propiedad (abajo) y asignala acá con
    //       "FechaAlta = DateTime.UtcNow;" (se carga sola, no es parámetro).
    //
    //    ANTES:  private Reserva(Guid id, string cliente, int numCancha,
    //                            decimal precio, EnumEstado estado, DateTime fechaHora)
    // ---------------------------------------------------------------------
    private Reserva(Guid id, string cliente, int numeroCancha, DateTime fechaHora, decimal precio)
    {
        Id = id;
        Cliente = cliente;
        NumeroCancha = numeroCancha;
        FechaHora = fechaHora;
        Precio = precio;
        Estado = EstadoReserva.Pendiente;   // REGLA 5
        FechaAlta = DateTime.UtcNow;        // se carga sola
    }

    public Guid Id { get; }

    // ✅ MEJORA: estos datos NO cambian después de crear la reserva
    //    -> borrá "private set;" y dejá solo "{ get; }".
    // ❌ ERROR L8 (detalle) - "NumCancha" -> la consigna dice "NumeroCancha".
    //    ✅ CÓMO CORREGIRLO: Ctrl+R, Ctrl+R sobre NumCancha > "NumeroCancha".
    public string Cliente { get; }
    public int NumeroCancha { get; }
    public DateTime FechaHora { get; }      // día y hora del PARTIDO
    public decimal Precio { get; }
    public DateTime FechaAlta { get; }      // cuándo se HIZO la reserva (L4)

    // Estado SÍ cambia (al confirmar y cancelar) -> private set. (Estaba bien.)
    public EstadoReserva Estado { get; private set; }

    // ---------------------------------------------------------------------
    // ❌ ERROR L1 - Crear recibía "EnumEstado estado"
    //    ✅ CÓMO CORREGIRLO: borrá ", EnumEstado estado" de los parámetros y
    //       del "return new Reserva(...)".
    //    ANTES:  Crear(string cliente, int numCancha, decimal precio,
    //                  EnumEstado estado, DateTime fechaHora)
    // ---------------------------------------------------------------------
    public static Reserva Crear(string cliente, int numeroCancha, DateTime fechaHora, decimal precio)
    {
        // REGLA 1 (estaba BIEN)
        if (string.IsNullOrWhiteSpace(cliente))
            throw new ArgumentException("El cliente es obligatorio.", nameof(cliente));

        // REGLA 2 (estaba BIEN)
        if (numeroCancha < 1 || numeroCancha > 5)
            throw new ArgumentException("El número de cancha debe ser entre 1 y 5.", nameof(numeroCancha));

        // REGLA 3 (estaba BIEN)
        if (precio <= 0)
            throw new ArgumentException("El precio tiene que ser mayor a 0.", nameof(precio));

        // -----------------------------------------------------------------
        // ❌ ERROR L2 - La validación de la fecha dejaba pasar horarios ya pasados
        //    QUÉ PASABA:
        //      a) ".Date" se queda solo con el DÍA y borra la hora. Entonces
        //         "hoy a las 10:00" pasaba la validación aunque ya fueran las
        //         17:00. La regla 4 dice "un horario que ya pasó".
        //      b) Se comparaba con UtcNow (hora de Londres, +3 h respecto de
        //         Argentina) contra una fecha que el usuario escribe en hora
        //         local: entre las 21:00 y las 24:00 la comparación da mal.
        //    ✅ CÓMO CORREGIRLO:
        //       1. Sacá los dos ".Date".
        //       2. Usá DateTime.Now (hora local) en vez de DateTime.UtcNow.
        //       3. Usá "<=" para que tampoco se pueda reservar para "ahora mismo".
        //    ANTES:  if (fechaHora.Date < DateTime.UtcNow.Date)
        // -----------------------------------------------------------------
        if (fechaHora <= DateTime.Now)
            throw new ArgumentException("La fecha y hora del partido tiene que ser futura.", nameof(fechaHora));

        return new Reserva(Guid.NewGuid(), cliente.Trim(), numeroCancha, fechaHora, precio);
    }

    // ---------------------------------------------------------------------
    // ❌ ERROR L3 - El método "Reservar" mezclaba confirmar y cancelar
    //    QUÉ PASABA (4 problemas):
    //      a) Se llamaba "Reservar", pero la acción de la regla 6 es CONFIRMAR.
    //      b) Lanzaba ArgumentException. Cuando el dato está bien pero el
    //         ESTADO no lo permite, va InvalidOperationException (por eso
    //         la API no lo atrapaba: tenía catch de InvalidOperationException).
    //      c) Después de "Estado = Confirmada" preguntaba "if (Estado ==
    //         Cancelada)": eso NUNCA se cumple (lo acabás de poner en
    //         Confirmada). Era la regla de CANCELAR metida en el lugar
    //         equivocado.
    //      d) No existía el método Cancelar (ver L5).
    //    ✅ CÓMO CORREGIRLO:
    //       1. Renombrá "Reservar" -> "Confirmar" (Ctrl+R, Ctrl+R).
    //       2. Cambiá ArgumentException por InvalidOperationException.
    //       3. Borrá las 2 últimas líneas (el "if (Estado == Cancelada)" y su
    //          throw): esa regla va en Cancelar.
    //    ANTES:
    //        public void Reservar()
    //        {
    //            if (Estado != EnumEstado.Pendiente)
    //                throw new ArgumentException("Solo se puede reservar si ...");
    //            Estado = EnumEstado.Confirmada;
    //            if (Estado == EnumEstado.Cancelada)
    //                throw new ArgumentException("La reserva tiene que estar ...");
    //        }
    // ---------------------------------------------------------------------
    public void Confirmar()
    {
        // REGLA 6: solo si está Pendiente -> se compara con != (distinto)
        if (Estado != EstadoReserva.Pendiente)
            throw new InvalidOperationException("Solo se puede confirmar una reserva Pendiente.");

        Estado = EstadoReserva.Confirmada;
    }

    // ---------------------------------------------------------------------
    // ❌ ERROR L5 - FALTABA el método Cancelar (regla 7)
    //    QUÉ PASABA: la regla 7 es otra acción distinta ("al cancelar...").
    //    ✅ CÓMO CORREGIRLO:
    //       1. Escribí un método nuevo "public void Cancelar()".
    //       2. Adentro, el "if" que tenías al final de Reservar, pero con
    //          InvalidOperationException.
    //       3. Después, "Estado = EstadoReserva.Cancelada;".
    //    POR QUÉ ACÁ SE USA "==" Y NO "!=" (pregunta 4 del ejercicio):
    //       - Regla 6: "solo si está Pendiente" -> hay UN estado permitido
    //         -> error si es DISTINTO de ese:      if (Estado != Pendiente)
    //       - Regla 7: "salvo que ya esté Cancelada" -> hay UN estado prohibido
    //         -> error si es IGUAL a ese:          if (Estado == Cancelada)
    // ---------------------------------------------------------------------
    public void Cancelar()
    {
        if (Estado == EstadoReserva.Cancelada)
            throw new InvalidOperationException("La reserva ya está cancelada.");

        Estado = EstadoReserva.Cancelada;
    }
}
