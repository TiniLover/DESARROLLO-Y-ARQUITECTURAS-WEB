// =========================================================================
// INFRAESTRUCTURA - Repositorio en memoria
// ✅ Estaba BIEN (sin errores). Ordenar por FechaHora (fecha del partido)
//    es una buena idea: la lista sale en orden de partidos.
// =========================================================================
using System.Collections.Concurrent;
using Futbol.Application.Abstracciones;
using Futbol.Domain;

namespace Futbol.Infrastructure;

public sealed class ReservaRepositorioEnMemoria : IReservaRepositorio
{
    private readonly ConcurrentDictionary<Guid, Reserva> reservas = new();

    public Task AddAsync(Reserva reserva, CancellationToken cancellationToken = default)
    {
        reservas[reserva.Id] = reserva;
        return Task.CompletedTask;
    }

    public Task<IReadOnlyCollection<Reserva>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        IReadOnlyCollection<Reserva> resultado = reservas.Values.OrderBy(r => r.FechaHora).ToArray();
        return Task.FromResult(resultado);
    }

    public Task<Reserva?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
    {
        reservas.TryGetValue(id, out var reserva);
        return Task.FromResult(reserva);
    }

    public Task UpdateAsync(Reserva reserva, CancellationToken cancellationToken = default)
    {
        reservas[reserva.Id] = reserva;
        return Task.CompletedTask;
    }
}
