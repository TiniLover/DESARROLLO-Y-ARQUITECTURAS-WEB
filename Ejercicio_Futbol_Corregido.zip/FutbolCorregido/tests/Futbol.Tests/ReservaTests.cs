// =========================================================================
// PRUEBAS   (ANTES: Test/UnitTest1.cs)
// -------------------------------------------------------------------------
// ✅ ¡BIEN! Esta vez el proyecto de pruebas referencia SOLO Domain y
//    Application (no repetiste el error de referenciar Infraestructura).
//
// ❌ ERROR L10 - Las pruebas eran las de PEDIDOS adaptadas a medias
//    QUÉ PASABA: los nombres decían "total_0", "total_600000",
//                "Despachar_y_entregar", "pedido_pendiente" y se llamaba a
//                Reserva.Crear con los datos de un Pedido ("Marta Ruiz", 18500m).
//                Por eso salían 7 errores de compilación (E2, E5 a E9).
//    ✅ CÓMO CORREGIRLO: escribí UNA prueba por cada punto de "Pruebas
//       mínimas" de la consigna de ESTE ejercicio, con los datos de una
//       reserva (cliente, cancha, fecha, precio).
//
// ❌ ERROR E2  (el PRIMERO de este archivo)
//    TAL CUAL APARECÍA EN VISUAL STUDIO:
//      Gravedad:    Error
//      Código:      CS1519
//      Descripción: El token "/" no es válido en una clase, un registro, una estructura o una declaración de miembro de interfaz
//      Proyecto:    Test
//      Archivo:     UnitTest1.cs
//      Línea:       50
//    QUÉ PASABA: en la línea 50 quedó una "/" sola (de un comentario borrado
//                a medias, igual que en Program.cs). Fuera de un método, C#
//                no sabe qué hacer con ella.
//    ✅ CÓMO CORREGIRLO: borrá la línea 50 (la que tiene solo "/").
//    TRUCO: cuando borres un comentario, borrá la línea entera
//           (Ctrl+Shift+L) en vez de ir borrando caracter por caracter.
// =========================================================================
using Futbol.Application.Abstracciones;
using Futbol.Application.Reservas;
using Futbol.Domain;

namespace Futbol.Tests;

public sealed class ReservaTests
{
    // Una fecha que SIEMPRE es futura (dentro de 7 días). Si escribís una
    // fecha fija, la prueba empieza a fallar cuando esa fecha pasa.
    private static DateTime FechaFutura => DateTime.Now.AddDays(7);

    // ---------------------------------------------------------------------
    // Prueba 1 de la consigna: cancha 6 lanza excepción
    // ❌ ERROR E5
    //    TAL CUAL APARECÍA EN VISUAL STUDIO:
    //      Gravedad:    Error
    //      Código:      CS1503
    //      Descripción: Argumento 5: no se puede convertir de 'int' a 'System.DateTime'
    //      Proyecto:    Test
    //      Archivo:     UnitTest1.cs
    //      Línea:       12
    //    QUÉ PASABA: escribiste la fecha como 13/07/2023. Sin comillas, C# lo
    //                lee como una CUENTA: 13 dividido 7 dividido 2023 = 0
    //                (división entera). O sea, un int, no una fecha.
    //                Además: la prueba se llamaba "total_0" (de Pedidos) y
    //                usaba cancha 1, que es VÁLIDA (no probaba lo que dice
    //                la consigna).
    //    ✅ CÓMO CORREGIRLO:
    //       1. Las fechas se escriben con DateTime: new DateTime(2023, 7, 13)
    //          o, mejor, DateTime.Now.AddDays(7) para una fecha futura.
    //       2. Usá cancha 6 (la que tiene que fallar).
    //       3. Sacá EnumEstado.Pendiente (error L1).
    //    ANTES:  Reserva.Crear("Marta Ruiz", 1, 8m, EnumEstado.Pendiente, 13/07/2023)
    // ---------------------------------------------------------------------
    [Fact]
    public void Crear_en_cancha_6_lanza_excepcion()
    {
        Assert.Throws<ArgumentException>(() => Reserva.Crear("Diego Sosa", 6, FechaFutura, 45000m));
    }

    // ---------------------------------------------------------------------
    // Prueba 2 de la consigna: fecha de ayer lanza excepción
    // ❌ ERROR E6  (el mismo error aparecía en las líneas 19, 26, 34 y 45)
    //    TAL CUAL APARECÍA EN VISUAL STUDIO:
    //      Gravedad:    Error
    //      Código:      CS7036
    //      Descripción: No se ha dado ningún argumento que corresponda al parámetro requerido "precio" de "Reserva.Crear(string, int, decimal, EnumEstado, DateTime)"
    //      Proyecto:    Test
    //      Archivo:     UnitTest1.cs
    //      Línea:       19  (y también 26, 34 y 45)
    //    QUÉ PASABA: se llamaba Reserva.Crear("Marta Ruiz", 600000m) con 2
    //                datos (como Pedido.Crear) y Reserva.Crear pide más.
    //                C# intentó poner 600000m en "numCancha" y le faltaron
    //                el resto.
    //    ✅ CÓMO CORREGIRLO: pasá TODOS los datos que pide Reserva.Crear, en
    //       el MISMO orden: (cliente, numeroCancha, fechaHora, precio).
    //       Para "ayer": DateTime.Now.AddDays(-1).
    //    ANTES:  Reserva.Crear("Marta Ruiz", 600000m)
    // ---------------------------------------------------------------------
    [Fact]
    public void Crear_con_fecha_de_ayer_lanza_excepcion()
    {
        Assert.Throws<ArgumentException>(() =>
            Reserva.Crear("Diego Sosa", 3, DateTime.Now.AddDays(-1), 45000m));
    }

    // Prueba 3 de la consigna (❌ ERROR E6 también estaba acá, línea 26)
    [Fact]
    public void Reserva_nueva_esta_pendiente()
    {
        var reserva = Reserva.Crear("Diego Sosa", 3, FechaFutura, 45000m);
        Assert.Equal(EstadoReserva.Pendiente, reserva.Estado);
    }

    // ---------------------------------------------------------------------
    // Prueba 4 de la consigna (❌ ERROR E6 también estaba acá, línea 34)
    // ❌ ERROR L10 - Además, la prueba verificaba lo contrario:
    //    ANTES:  reserva.Reservar();
    //            Assert.Equal(EnumEstado.Pendiente, reserva.Estado);
    //    QUÉ PASABA: después de confirmar, el estado es Confirmada, no
    //                Pendiente -> la prueba iba a fallar siempre.
    //    ✅ CÓMO CORREGIRLO: confirmar, cancelar y verificar que quede Cancelada.
    // ---------------------------------------------------------------------
    [Fact]
    public void Confirmar_y_cancelar_deja_la_reserva_cancelada()
    {
        var reserva = Reserva.Crear("Diego Sosa", 3, FechaFutura, 45000m);

        reserva.Confirmar();
        reserva.Cancelar();

        Assert.Equal(EstadoReserva.Cancelada, reserva.Estado);
    }

    // ---------------------------------------------------------------------
    // Prueba 5 de la consigna (❌ ERROR E6 también estaba acá, línea 45)
    // ❌ ERROR L10 - Probaba otra cosa: Reservar() sobre una Pendiente (que es
    //    justo cuando SÍ se puede) esperando una excepción.
    //    ✅ CÓMO CORREGIRLO: cancelar una vez (OK) y la segunda vez tiene que
    //       lanzar InvalidOperationException.
    // ---------------------------------------------------------------------
    [Fact]
    public void Cancelar_una_reserva_ya_cancelada_lanza_excepcion()
    {
        var reserva = Reserva.Crear("Diego Sosa", 3, FechaFutura, 45000m);
        reserva.Cancelar();

        Assert.Throws<InvalidOperationException>(() => reserva.Cancelar());
    }

    // ---------------------------------------------------------------------
    // Extra: el caso de uso guarda y devuelve el DTO
    // ❌ ERROR E7
    //    TAL CUAL APARECÍA EN VISUAL STUDIO:
    //      Gravedad:    Error
    //      Código:      CS7036
    //      Descripción: No se ha dado ningún argumento que corresponda al parámetro requerido "fechaHora" de "CrearReserva.ExecuteAsync(string, int, decimal, DateTime, EnumEstado, CancellationToken)"
    //      Proyecto:    Test
    //      Archivo:     UnitTest1.cs
    //      Línea:       57
    //    QUÉ PASABA: se pasaban los datos de un PEDIDO ("Azopardo 668" es una
    //                dirección) en vez de los de una reserva.
    //    ✅ CÓMO CORREGIRLO: pasá cliente, cancha, fecha y precio.
    //    ANTES:  useCase.ExecuteAsync("  Julia Gómez  ", "Azopardo 668", 15000m);
    //
    // ❌ ERROR E8  (aparece cuando arreglás E7)
    //      Código:      CS1061
    //      Descripción: "ReservaDTO" no contiene una definición para "Total" ni un método de extensión accesible "Total" que acepte un primer argumento del tipo "ReservaDTO" (¿falta alguna directiva using o una referencia de ensamblado?)
    //      Archivo:     UnitTest1.cs     Línea: 60
    //    QUÉ PASABA: "Total" era del Pedido; la reserva tiene "Precio".
    //    ✅ CÓMO CORREGIRLO: resultado.Total -> resultado.Precio.
    //
    // ❌ ERROR E9  (aparece cuando arreglás E7)
    //      Código:      CS1503
    //      Descripción: Argumento 2: no se puede convertir de 'Domain.EnumEstado' a 'System.Collections.Generic.IEnumerable<char>?'
    //      Archivo:     UnitTest1.cs     Línea: 61
    //    QUÉ PASABA: comparabas el texto "Pendiente" con un enum. En Pedidos
    //                funcionaba porque el DTO tenía el estado como string;
    //                acá tu DTO lo tenía como enum.
    //    ✅ CÓMO CORREGIRLO: poné el estado del DTO como string (error L8,
    //       ver ReservaDto.cs). Así "Pendiente" == "Pendiente".
    // ---------------------------------------------------------------------
    [Fact]
    public async Task Crear_reserva_guarda_y_devuelve_dto_pendiente()
    {
        var repositorio = new RepositorioFalso();
        var useCase = new CrearReservaUseCase(repositorio);

        var resultado = await useCase.ExecuteAsync("  Julia Gómez  ", 2, FechaFutura, 45000m);

        Assert.Equal("Julia Gómez", resultado.Cliente);
        Assert.Equal(45000m, resultado.Precio);
        Assert.Equal("Pendiente", resultado.Estado);
        Assert.Single(repositorio.Reservas);
    }

    // ✅ El repositorio falso estaba BIEN.
    private sealed class RepositorioFalso : IReservaRepositorio
    {
        public List<Reserva> Reservas { get; } = [];

        public Task AddAsync(Reserva reserva, CancellationToken cancellationToken = default)
        {
            Reservas.Add(reserva);
            return Task.CompletedTask;
        }

        public Task<IReadOnlyCollection<Reserva>> GetAllAsync(CancellationToken cancellationToken = default)
            => Task.FromResult<IReadOnlyCollection<Reserva>>(Reservas);

        public Task<Reserva?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
            => Task.FromResult(Reservas.FirstOrDefault(r => r.Id == id));

        public Task UpdateAsync(Reserva reserva, CancellationToken cancellationToken = default)
            => Task.CompletedTask;
    }
}
