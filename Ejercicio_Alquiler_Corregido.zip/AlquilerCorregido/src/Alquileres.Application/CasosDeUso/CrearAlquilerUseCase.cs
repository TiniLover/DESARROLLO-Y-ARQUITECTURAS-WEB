// =========================================================================
// APLICACIÓN - Crear   (ANTES: CrearAlquiler.cs)
// ❌ ERROR L2 - Recibía kmFinal y estado
//    ✅ CÓMO CORREGIRLO: (patente, cliente, fechaDevolucion, kmInicial, ct).
// (Detalle: la variable se llamaba "orden" -> quedó del Taller.)
// =========================================================================
using Alquileres.Application.Abstracciones;
using Alquileres.Domain;

namespace Alquileres.Application.CasosDeUso;

public sealed class CrearAlquilerUseCase(IAlquilerRepositorio repositorio)
{
    public async Task<AlquilerDto> ExecuteAsync(string patente, string cliente, DateTime fechaDevolucion,
        int kmInicial, CancellationToken cancellationToken = default)
    {
        var alquiler = Alquiler.Crear(patente, cliente, fechaDevolucion, kmInicial);
        await repositorio.AddAsync(alquiler, cancellationToken);
        return alquiler.ToDto();
    }
}
