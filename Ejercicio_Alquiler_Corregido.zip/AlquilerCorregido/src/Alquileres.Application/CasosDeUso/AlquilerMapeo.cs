// APLICACIÓN - Mapeo   (✅ estaba bien, con Estado.ToString(); se agrega FechaAlta)
using Alquileres.Domain;

namespace Alquileres.Application.CasosDeUso;

internal static class AlquilerMapeo
{
    public static AlquilerDto ToDto(this Alquiler alquiler) =>
        new(alquiler.Id, alquiler.Patente, alquiler.Cliente, alquiler.FechaDevolucion,
            alquiler.KmInicial, alquiler.KmFinal, alquiler.Estado.ToString(), alquiler.FechaAlta);
}
