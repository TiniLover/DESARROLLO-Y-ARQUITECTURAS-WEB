// =========================================================================
// APLICACIÓN - Devolver
// ❌ ERROR L5 - NO EXISTÍA (se usaba "Alquilar" para todo).
//    ✅ CÓMO CORREGIRLO: recibe el id y SOLO el dato nuevo: kmFinal.
// =========================================================================
using Alquileres.Application.Abstracciones;

namespace Alquileres.Application.CasosDeUso;

public sealed class DevolverAlquilerUseCase(IAlquilerRepositorio repositorio)
{
    public async Task<AlquilerDto?> ExecuteAsync(Guid id, int kmFinal, CancellationToken cancellationToken = default)
    {
        var alquiler = await repositorio.GetByIdAsync(id, cancellationToken);
        if (alquiler is null)
            return null;

        alquiler.Devolver(kmFinal);

        await repositorio.UpdateAsync(alquiler, cancellationToken);
        return alquiler.ToDto();
    }
}
