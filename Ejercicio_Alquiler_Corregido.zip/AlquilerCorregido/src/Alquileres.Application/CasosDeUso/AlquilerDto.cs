// =========================================================================
// APLICACIÓN - DTO   (ANTES: AlquilerDTO.cs)
// ✅ ¡BIEN! Esta vez pusiste el Estado como STRING (lo que vimos en los
//    anteriores). Solo faltaba FechaAlta (está en la entidad de la consigna).
// =========================================================================
namespace Alquileres.Application.CasosDeUso;

public sealed record AlquilerDto(
    Guid Id,
    string Patente,
    string Cliente,
    DateTime FechaDevolucion,
    int KmInicial,
    int KmFinal,
    string Estado,
    DateTime FechaAlta);
