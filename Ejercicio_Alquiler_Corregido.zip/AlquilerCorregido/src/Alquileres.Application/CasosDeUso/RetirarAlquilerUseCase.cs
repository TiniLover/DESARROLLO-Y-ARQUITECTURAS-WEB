// =========================================================================
// APLICACIÓN - Retirar
// ❌ ERROR L5 - Tu caso de uso "Alquilar" servía para las dos acciones y
//    recibía (id, kmInicial, estado, kmFinal, kmTotal).
//    ✅ CÓMO CORREGIRLO: un caso de uso por acción. Retirar recibe SOLO el id.
// =========================================================================
using Alquileres.Application.Abstracciones;

namespace Alquileres.Application.CasosDeUso;

public sealed class RetirarAlquilerUseCase(IAlquilerRepositorio repositorio)
{
    public async Task<AlquilerDto?> ExecuteAsync(Guid id, CancellationToken cancellationToken = default)
    {
        var alquiler = await repositorio.GetByIdAsync(id, cancellationToken);
        if (alquiler is null)
            return null;

        alquiler.Retirar();

        await repositorio.UpdateAsync(alquiler, cancellationToken);
        return alquiler.ToDto();
    }
}
