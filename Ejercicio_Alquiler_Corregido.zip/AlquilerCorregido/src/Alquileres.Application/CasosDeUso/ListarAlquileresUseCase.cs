// APLICACIÓN - Listar   (✅ estaba BIEN)
using Alquileres.Application.Abstracciones;

namespace Alquileres.Application.CasosDeUso;

public sealed class ListarAlquileresUseCase(IAlquilerRepositorio repositorio)
{
    public async Task<IReadOnlyCollection<AlquilerDto>> ExecuteAsync(CancellationToken cancellationToken = default)
    {
        var alquileres = await repositorio.GetAllAsync(cancellationToken);
        return alquileres.Select(a => a.ToDto()).ToArray();
    }
}
