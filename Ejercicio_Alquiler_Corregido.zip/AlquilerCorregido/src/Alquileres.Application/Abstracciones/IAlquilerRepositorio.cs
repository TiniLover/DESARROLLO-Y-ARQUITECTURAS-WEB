// APLICACIÓN - Interfaz del repositorio   (✅ estaba BIEN)
using Alquileres.Domain;

namespace Alquileres.Application.Abstracciones;

public interface IAlquilerRepositorio
{
    Task AddAsync(Alquiler alquiler, CancellationToken cancellationToken = default);
    Task<IReadOnlyCollection<Alquiler>> GetAllAsync(CancellationToken cancellationToken = default);
    Task<Alquiler?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default);
    Task UpdateAsync(Alquiler alquiler, CancellationToken cancellationToken = default);
}
