// INFRAESTRUCTURA - Repositorio en memoria   (✅ estaba BIEN)
// (Detalle: el proyecto se llamaba "Infraestrutura", le faltaba la "c".)
using System.Collections.Concurrent;
using Alquileres.Application.Abstracciones;
using Alquileres.Domain;

namespace Alquileres.Infrastructure;

public sealed class AlquilerRepositorioEnMemoria : IAlquilerRepositorio
{
    private readonly ConcurrentDictionary<Guid, Alquiler> alquileres = new();

    public Task AddAsync(Alquiler alquiler, CancellationToken cancellationToken = default)
    {
        alquileres[alquiler.Id] = alquiler;
        return Task.CompletedTask;
    }

    public Task<IReadOnlyCollection<Alquiler>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        IReadOnlyCollection<Alquiler> resultado = alquileres.Values.OrderBy(a => a.FechaAlta).ToArray();
        return Task.FromResult(resultado);
    }

    public Task<Alquiler?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
    {
        alquileres.TryGetValue(id, out var alquiler);
        return Task.FromResult(alquiler);
    }

    public Task UpdateAsync(Alquiler alquiler, CancellationToken cancellationToken = default)
    {
        alquileres[alquiler.Id] = alquiler;
        return Task.CompletedTask;
    }
}
