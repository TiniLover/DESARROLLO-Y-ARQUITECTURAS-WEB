// DOMINIO - Enum   (ANTES: EnumEstado.cs)
// ✅ Los 3 estados bien y en orden. Solo el nombre: EnumEstado -> EstadoAlquiler.
namespace Alquileres.Domain;

public enum EstadoAlquiler
{
    Reservado,
    EnCurso,
    Finalizado
}
