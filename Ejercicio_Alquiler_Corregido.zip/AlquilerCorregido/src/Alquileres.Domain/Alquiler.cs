// =========================================================================
// DOMINIO - Entidad Alquiler   (ANTES: Domain/Alquiler.cs)
// -------------------------------------------------------------------------
// ✅ BIEN: KmFinal = 0 adentro del constructor, FechaAlta automática,
//    reglas de patente y cliente obligatorios.
// ❌ Pero este archivo tenía el error principal del ejercicio: confundir
//    PARÁMETROS (lo que llega) con PROPIEDADES (lo que el objeto ya tiene).
// =========================================================================
namespace Alquileres.Domain;

public sealed class Alquiler
{
    // ---------------------------------------------------------------------
    // ❌ ERROR L1 - El constructor IGNORABA la fecha de devolución
    //    QUÉ PASABA: recibías "fechaDevolucion" pero escribiste
    //                "FechaDevolucion = DateTime.UtcNow;". Todos los
    //                alquileres quedaban con fecha de devolución = AHORA
    //                (lo que mandaba el usuario se perdía).
    //    ✅ CÓMO CORREGIRLO: "FechaDevolucion = fechaDevolucion;" (el parámetro).
    //
    // ❌ ERROR L2 - El estado venía de AFUERA
    //    QUÉ PASABA: "Estado = estado;" -> quien crea el alquiler podía
    //                mandar "Finalizado" y nacía finalizado. La regla 4 dice
    //                que siempre arranca Reservado.
    //    ✅ CÓMO CORREGIRLO: borrá los parámetros "int kmFinal, EnumEstado estado"
    //       y poné "Estado = EstadoAlquiler.Reservado;".
    //    ANTES: private Alquiler(Guid id, string patente, string cliente,
    //               DateTime fechaDevolucion, int kmInicial, int kmFinal, EnumEstado estado)
    // ---------------------------------------------------------------------
    private Alquiler(Guid id, string patente, string cliente, DateTime fechaDevolucion, int kmInicial)
    {
        Id = id;
        Patente = patente;
        Cliente = cliente;
        FechaDevolucion = fechaDevolucion;   // ← antes: DateTime.UtcNow
        KmInicial = kmInicial;
        KmFinal = 0;                          // regla 4 (estaba bien)
        Estado = EstadoAlquiler.Reservado;    // regla 4 (antes venía de afuera)
        FechaAlta = DateTime.Now;
    }

    public Guid Id { get; }
    public string Patente { get; }
    public string Cliente { get; }
    public DateTime FechaDevolucion { get; }
    public int KmInicial { get; }
    public DateTime FechaAlta { get; }

    // Cambian al retirar/devolver -> private set
    public int KmFinal { get; private set; }
    public EstadoAlquiler Estado { get; private set; }

    // ---------------------------------------------------------------------
    // ❌ ERROR L2 - Crear recibía kmFinal y estado (no los manda el cliente)
    //    ✅ CÓMO CORREGIRLO: dejá (patente, cliente, fechaDevolucion, kmInicial).
    //
    // ❌ ERROR L3 - La validación de la fecha usaba ".Day"
    //    QUÉ PASABA: ".Day" es SOLO el número del día del mes (1 a 31).
    //      - Si hoy es 20/11 y la devolución es el 5/12, compara 5 < 20 ->
    //        RECHAZA una fecha futura válida.
    //      - El 1° de cada mes, "ayer" es 31 -> 31 < 1? No -> ACEPTA ayer.
    //      Tu prueba 2 pasó solo porque hoy es día 2.
    //      Además usaba UtcNow (hora de Londres).
    //    ✅ CÓMO CORREGIRLO: comparar la fecha COMPLETA con DateTime.Now:
    //       if (fechaDevolucion <= DateTime.Now) throw ...
    //    ANTES: if (fechaDevolucion.Day < DateTime.UtcNow.Day)
    //
    // ❌ ERROR L4 - La regla 3 (km inicial no negativo) estaba en el lugar
    //    equivocado: en Alquilar en vez de en Crear. Por eso tu prueba 1
    //    fallaba: "No exception was thrown".
    //    ✅ CÓMO CORREGIRLO: mové el "if (kmInicial < 0)" acá.
    // ---------------------------------------------------------------------
    public static Alquiler Crear(string patente, string cliente, DateTime fechaDevolucion, int kmInicial)
    {
        if (string.IsNullOrWhiteSpace(patente))
            throw new ArgumentException("La patente es obligatoria.", nameof(patente));

        if (string.IsNullOrWhiteSpace(cliente))
            throw new ArgumentException("El cliente es obligatorio.", nameof(cliente));

        if (fechaDevolucion <= DateTime.Now)
            throw new ArgumentException("La fecha de devolución tiene que ser futura.", nameof(fechaDevolucion));

        if (kmInicial < 0)
            throw new ArgumentException("El km inicial no puede ser negativo.", nameof(kmInicial));

        return new Alquiler(Guid.NewGuid(), patente.Trim().ToUpper(), cliente.Trim(), fechaDevolucion, kmInicial);
    }

    // ---------------------------------------------------------------------
    // ❌ ERROR L5 - El método "Alquilar" (EL MÁS IMPORTANTE)
    //    ANTES:
    //        public void Alquilar(int kmInicial, EnumEstado estado, int kmFinal, int kmTotal)
    //        {
    //            if (kmInicial < 0) throw ...
    //            if (estado != EnumEstado.Reservado && kmFinal == 0) throw ...
    //            Estado = EnumEstado.EnCurso;
    //            if (kmFinal < kmInicial) throw ...
    //            if (estado != EnumEstado.EnCurso) throw ...
    //            estado = EnumEstado.Finalizado;
    //            if (kmFinal > kmInicial && kmFinal - kmInicial > 3000) throw ...
    //            kmTotal = kmFinal - kmInicial;
    //        }
    //    QUÉ PASABA (5 problemas):
    //      a) Recibía como PARÁMETROS cosas que el alquiler YA TIENE
    //         (kmInicial, estado). Validaba el "estado" que le mandaban desde
    //         afuera, no el "Estado" real del alquiler.
    //         -> minúscula "estado" = lo que llega; Mayúscula "Estado" = lo real.
    //      b) "estado = EnumEstado.Finalizado;" cambiaba el PARÁMETRO (que se
    //         pierde al terminar el método), NO la propiedad. El alquiler
    //         nunca quedaba Finalizado. Lo mismo con "kmTotal = ...".
    //      c) NUNCA guardaba el km final: faltaba "KmFinal = kmFinal;"
    //         (igual que las horas en Soporte).
    //      d) Hacía RETIRAR y DEVOLVER juntos (pone EnCurso y en la línea
    //         siguiente valida la devolución). Ya te pasó en Fútbol y Taller.
    //      e) Errores de estado con ArgumentException (va InvalidOperationException).
    //    ✅ CÓMO CORREGIRLO: dos métodos, uno por acción:
    //       Retirar()            -> sin parámetros (todo lo que necesita ya lo tiene)
    //       Devolver(int kmFinal) -> recibe SOLO lo nuevo: el km final
    //    REGLA DE ORO: un método recibe como parámetro SOLO lo que el objeto
    //                  todavía NO sabe. Lo que ya sabe, lo lee de sus propiedades.
    // ---------------------------------------------------------------------

    // REGLA 5
    public void Retirar()
    {
        if (Estado != EstadoAlquiler.Reservado)
            throw new InvalidOperationException("Solo se puede retirar un alquiler Reservado.");

        Estado = EstadoAlquiler.EnCurso;
    }

    // REGLA 6
    public void Devolver(int kmFinal)
    {
        // 1) Estado (con la PROPIEDAD Estado)
        if (Estado != EstadoAlquiler.EnCurso)
            throw new InvalidOperationException("Solo se puede devolver un alquiler EnCurso.");

        // 2) kmFinal (parámetro) contra KmInicial (propiedad)
        if (kmFinal <= KmInicial)
            throw new ArgumentException("El km final tiene que ser mayor al km inicial.", nameof(kmFinal));

        // 3) El recorrido es una variable LOCAL (no hace falta guardarla)
        int recorrido = kmFinal - KmInicial;
        if (recorrido > 3000)
            throw new ArgumentException("El recorrido no puede superar los 3000 km.", nameof(kmFinal));

        // 4) GUARDAR en las PROPIEDADES (Mayúscula)
        KmFinal = kmFinal;
        Estado = EstadoAlquiler.Finalizado;
    }
}
