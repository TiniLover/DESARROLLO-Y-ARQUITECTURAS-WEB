// =========================================================================
// API   (ANTES: WebApplication1/Program.cs)
// ✅ Compilaba. Inyección (Singleton + Scoped): bien.
// =========================================================================
using Alquileres.Application.Abstracciones;
using Alquileres.Application.CasosDeUso;
using Alquileres.Infrastructure;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSingleton<IAlquilerRepositorio, AlquilerRepositorioEnMemoria>();

builder.Services.AddScoped<CrearAlquilerUseCase>();
builder.Services.AddScoped<ListarAlquileresUseCase>();
builder.Services.AddScoped<RetirarAlquilerUseCase>();
builder.Services.AddScoped<DevolverAlquilerUseCase>();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// ❌ ERROR L7 - Rutas "/Alquileres" (mayúscula), "/iniciar" y "/finalizar"
//    (del Taller). La consigna dice /alquileres, /retirar y /devolver.
app.MapGet("/alquileres", async (ListarAlquileresUseCase useCase, CancellationToken ct) =>
    Results.Ok(await useCase.ExecuteAsync(ct)))
.WithName("ListarAlquileres")
.WithOpenApi();

// -------------------------------------------------------------------------
// ❌ ERROR L2 - El POST pedía kmFinal y estado al usuario
//    QUÉ PASABA: en Swagger aparecían "kmFinal" y "estado" para completar,
//                y el usuario podía crear un alquiler ya "Finalizado".
//    ✅ CÓMO CORREGIRLO: el request lleva solo Patente, Cliente,
//       FechaDevolucion y KmInicial.
// -------------------------------------------------------------------------
app.MapPost("/alquileres", async (CrearAlquilerRequest request, CrearAlquilerUseCase useCase, CancellationToken ct) =>
{
    try
    {
        var alquiler = await useCase.ExecuteAsync(
            request.Patente, request.Cliente, request.FechaDevolucion, request.KmInicial, ct);
        return Results.Created($"/alquileres/{alquiler.Id}", alquiler);   // 201
    }
    catch (ArgumentException ex)
    {
        return Results.BadRequest(new { error = ex.Message });           // 400
    }
})
.WithName("CrearAlquiler")
.WithOpenApi();

// -------------------------------------------------------------------------
// ❌ ERROR L6 - Los endpoints mandaban NÚMEROS INVENTADOS (el más grave de la API)
//    ANTES:  useCase.ExecuteAsync(id, 5, EnumEstado.Reservado, 20, 15, ct);
//    QUÉ PASABA: le pasabas valores fijos (5, 20, 15) escritos a mano. No
//                importaba qué alquiler fuera: siempre los mismos números.
//                Y con esos valores, "Alquilar" SIEMPRE tiraba
//                ArgumentException ("El auto solo puede ser devuelto si...").
//                Como acá solo atrapabas InvalidOperationException, el
//                endpoint respondía 500 (error del servidor).
//    ✅ CÓMO CORREGIRLO: retirar no necesita datos -> solo el id.
// -------------------------------------------------------------------------
app.MapPost("/alquileres/{id:guid}/retirar", async (Guid id, RetirarAlquilerUseCase useCase, CancellationToken ct) =>
{
    try
    {
        var alquiler = await useCase.ExecuteAsync(id, ct);
        return alquiler is null
            ? Results.NotFound(new { error = "No existe un alquiler con ese Id." })   // 404
            : Results.Ok(alquiler);                                                    // 200
    }
    catch (InvalidOperationException ex)
    {
        return Results.BadRequest(new { error = ex.Message });                       // 400
    }
})
.WithName("RetirarAlquiler")
.WithOpenApi();

// -------------------------------------------------------------------------
// ❌ ERROR L6 - Recibía el request pero NO LO USABA
//    ANTES:  async (Guid id, FinalizarRequest request, Alquilar useCase, ...)
//              => useCase.ExecuteAsync(id, 5, EnumEstado.Finalizado, 20, 15, ct);
//    QUÉ PASABA: el km final que mandaba el usuario ({ "kmFinla": ... })
//                se ignoraba y se pasaban 5, 20, 15 fijos.
//    ✅ CÓMO CORREGIRLO: usá el dato del request: request.KmFinal.
// -------------------------------------------------------------------------
app.MapPost("/alquileres/{id:guid}/devolver", async (
    Guid id, DevolverRequest request, DevolverAlquilerUseCase useCase, CancellationToken ct) =>
{
    try
    {
        var alquiler = await useCase.ExecuteAsync(id, request.KmFinal, ct);
        return alquiler is null
            ? Results.NotFound(new { error = "No existe un alquiler con ese Id." })   // 404
            : Results.Ok(alquiler);                                                    // 200
    }
    catch (ArgumentException ex)            // km final inválido
    {
        return Results.BadRequest(new { error = ex.Message });
    }
    catch (InvalidOperationException ex)    // no estaba EnCurso
    {
        return Results.BadRequest(new { error = ex.Message });
    }
})
.WithName("DevolverAlquiler")
.WithOpenApi();

app.Run();

// ❌ ERROR L2 - ANTES: (string Patente, string Cliente, DateTime FechaDevolucion,
//                       int kmInicial, int kmFinal, EnumEstado estado)
//    ✅ Sin kmFinal ni estado, y con MAYÚSCULA (KmInicial).
public sealed record CrearAlquilerRequest(string Patente, string Cliente, DateTime FechaDevolucion, int KmInicial);

// ❌ ERROR L6 - ANTES: FinalizarRequest(int kmFinla)  <- "kmFinla" mal escrito
//    y con el nombre del Taller. ✅ DevolverRequest(int KmFinal).
public sealed record DevolverRequest(int KmFinal);
