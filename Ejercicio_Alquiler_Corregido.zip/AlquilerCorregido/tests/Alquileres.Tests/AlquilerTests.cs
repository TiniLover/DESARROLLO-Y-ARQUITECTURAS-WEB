// =========================================================================
// PRUEBAS   (ANTES: Test/UnitTest1.cs)
// Al ejecutarlas (Ctrl+R, A): Con error: 3, Superado: 2, Total: 5
// ✅ Bien: los NOMBRES de las pruebas esta vez eran los de ESTA consigna.
// =========================================================================
using Alquileres.Application.Abstracciones;
using Alquileres.Application.CasosDeUso;
using Alquileres.Domain;

namespace Alquileres.Tests;

public sealed class AlquilerTests
{
    private static DateTime FechaFutura => DateTime.Now.AddDays(7);

    // ---------------------------------------------------------------------
    // Prueba 1
    // ❌ ERROR P1 - FALLABA: "Assert.Throws() Failure: No exception was thrown"
    //    QUÉ PASABA: la validación de km negativo estaba en Alquilar, no en
    //                Crear (ver L4). Crear aceptaba -5 sin quejarse.
    // ---------------------------------------------------------------------
    [Fact]
    public void Crear_con_km_inicial_negativo_lanza_excepcion()
    {
        Assert.Throws<ArgumentException>(() => Alquiler.Crear("AE456FG", "Martina Ríos", FechaFutura, -5));
    }

    // Prueba 2 (✅ pasaba, pero SOLO porque hoy es día 2: ver ERROR L3)
    [Fact]
    public void Crear_con_fecha_de_ayer_lanza_excepcion()
    {
        Assert.Throws<ArgumentException>(() => Alquiler.Crear("AE456FG", "Martina Ríos", DateTime.Now.AddDays(-1), 45000));
    }

    // Prueba 3 (✅ pasaba. Detalle: "0m" es decimal y KmFinal es int -> va "0")
    [Fact]
    public void Alquiler_nuevo_esta_reservado_y_con_km_final_0()
    {
        var alquiler = Alquiler.Crear("AE456FG", "Martina Ríos", FechaFutura, 45000);

        Assert.Equal(EstadoAlquiler.Reservado, alquiler.Estado);
        Assert.Equal(0, alquiler.KmFinal);
    }

    // ---------------------------------------------------------------------
    // Prueba 4
    // ❌ ERROR P2 - FALLABA: "El auto solo puede ser devuelto si el alquiler
    //    está en curso."
    //    QUÉ PASABA: Alquilar validaba el "estado" que le pasabas
    //                (Finalizado), no el real. Además la prueba esperaba
    //                EnCurso (después de devolver tiene que ser Finalizado) y
    //                que KmFinal == KmInicial (tiene que ser 45800).
    //    ✅ CÓMO CORREGIRLO: Retirar() + Devolver(45800) y verificar
    //       Finalizado y KmFinal 45800.
    // ---------------------------------------------------------------------
    [Fact]
    public void Retirar_y_devolver_deja_el_alquiler_finalizado_con_45800()
    {
        var alquiler = Alquiler.Crear("AE456FG", "Martina Ríos", FechaFutura, 45000);

        alquiler.Retirar();
        alquiler.Devolver(45800);

        Assert.Equal(EstadoAlquiler.Finalizado, alquiler.Estado);
        Assert.Equal(45800, alquiler.KmFinal);
    }

    // ---------------------------------------------------------------------
    // Prueba 5
    // ❌ ERROR P3 - FALLABA: "Exception type was not an exact match.
    //    Expected: typeof(System.InvalidOperationException)"
    //    QUÉ PASABA: km final menor al inicial es un DATO mal cargado ->
    //                ArgumentException (lo que lanzaba tu código). La prueba
    //                esperaba la otra.
    //    RECORDÁ: dato mal -> ArgumentException;
    //             estado que no lo permite -> InvalidOperationException.
    //    Y antes de devolver hay que RETIRAR (si no, salta el error de estado).
    // ---------------------------------------------------------------------
    [Fact]
    public void Devolver_con_km_final_menor_al_inicial_lanza_excepcion()
    {
        var alquiler = Alquiler.Crear("AE456FG", "Martina Ríos", FechaFutura, 45000);
        alquiler.Retirar();

        Assert.Throws<ArgumentException>(() => alquiler.Devolver(44000));
    }

    // Extra (el repositorio falso estaba armado pero ninguna prueba lo usaba)
    [Fact]
    public async Task Crear_alquiler_guarda_y_devuelve_dto_reservado()
    {
        var repositorio = new RepositorioFalso();
        var useCase = new CrearAlquilerUseCase(repositorio);

        var resultado = await useCase.ExecuteAsync("ae456fg", "Martina Ríos", FechaFutura, 45000);

        Assert.Equal("AE456FG", resultado.Patente);
        Assert.Equal("Reservado", resultado.Estado);
        Assert.Equal(0, resultado.KmFinal);
        Assert.Single(repositorio.Alquileres);
    }

    private sealed class RepositorioFalso : IAlquilerRepositorio
    {
        public List<Alquiler> Alquileres { get; } = [];

        public Task AddAsync(Alquiler alquiler, CancellationToken cancellationToken = default)
        {
            Alquileres.Add(alquiler);
            return Task.CompletedTask;
        }

        public Task<IReadOnlyCollection<Alquiler>> GetAllAsync(CancellationToken cancellationToken = default)
            => Task.FromResult<IReadOnlyCollection<Alquiler>>(Alquileres);

        public Task<Alquiler?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
            => Task.FromResult(Alquileres.FirstOrDefault(a => a.Id == id));

        public Task UpdateAsync(Alquiler alquiler, CancellationToken cancellationToken = default)
            => Task.CompletedTask;
    }
}
