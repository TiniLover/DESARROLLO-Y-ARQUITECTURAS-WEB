﻿using System;

namespace ConsoleApp1
{
    // Subclase concreta: solo completa los pasos que dejó abiertos Bebida.
    public class Cafe : Bebida
    {
        public override string Nombre => "Café";
        public override decimal Precio => 2500;

        protected override void Preparar()
        {
            Console.WriteLine("Moliendo granos y pasando agua a 90 grados...");
        }

        protected override void AgregarAcompaniamiento()
        {
            Console.WriteLine("Agregando una galletita de manteca.");
        }

        // Sobrescribe el hook: esta bebida SÍ ofrece crema.
        protected override bool OfreceCrema()
        {
            return true;
        }
    }
}
