﻿using System;

namespace ConsoleApp1
{
    // Subclase concreta: solo completa los pasos que dejó abiertos Bebida.
    public class Licuado : Bebida
    {
        public override string Nombre => "Licuado";
        public override decimal Precio => 3500;

        protected override void Preparar()
        {
            Console.WriteLine("Licuando frutas frescas con leche y hielo...");
        }

        protected override void AgregarAcompaniamiento()
        {
            Console.WriteLine("Agregando un sorbete y una rodaja de naranja.");
        }

        // No sobrescribe OfreceCrema(): usa el valor por defecto (sin crema).
    }
}
