﻿using System;

namespace ConsoleApp1
{
    // Subclase concreta: solo completa los pasos que dejó abiertos Bebida.
    public class ChocolateCaliente : Bebida
    {
        public override string Nombre => "Chocolate caliente";
        public override decimal Precio => 3000;

        protected override void Preparar()
        {
            Console.WriteLine("Calentando leche y derritiendo el chocolate...");
        }

        protected override void AgregarAcompaniamiento()
        {
            Console.WriteLine("Agregando malvaviscos por encima.");
        }

        // Sobrescribe el hook: esta bebida SÍ ofrece crema.
        protected override bool OfreceCrema()
        {
            return true;
        }
    }
}
