﻿using System;

namespace ConsoleApp1
{
    // Subclase concreta: solo completa los pasos que dejó abiertos Bebida.
    public class Te : Bebida
    {
        public override string Nombre => "Té";
        public override decimal Precio => 2000;

        protected override void Preparar()
        {
            Console.WriteLine("Calentando agua a 80 grados y dejando el saquito 3 minutos...");
        }

        protected override void AgregarAcompaniamiento()
        {
            Console.WriteLine("Agregando una rodaja de limón.");
        }

        // No sobrescribe OfreceCrema(): usa el valor por defecto (sin crema).
    }
}
