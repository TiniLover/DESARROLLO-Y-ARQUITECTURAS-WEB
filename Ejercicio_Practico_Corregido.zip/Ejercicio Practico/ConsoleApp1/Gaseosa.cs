﻿using System;

namespace ConsoleApp1
{
    // Subclase concreta: solo completa los pasos que dejó abiertos Bebida.
    public class Gaseosa : Bebida
    {
        public override string Nombre => "Gaseosa";
        public override decimal Precio => 1800;

        protected override void Preparar()
        {
            Console.WriteLine("Sirviendo la gaseosa bien fría en un vaso con hielo...");
        }

        protected override void AgregarAcompaniamiento()
        {
            Console.WriteLine("Agregando un sorbete.");
        }

        // No sobrescribe OfreceCrema(): usa el valor por defecto (sin crema).
    }
}
