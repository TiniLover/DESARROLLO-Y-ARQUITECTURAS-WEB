﻿using System;
using System.Text;

namespace ConsoleApp1
{
    // =====================================================================
    // PROGRAMA PRINCIPAL
    // El cliente elige una bebida y se llama al MÉTODO PLANTILLA
    // PrepararPedido(). El programa trata a todas como "Bebida": no le
    // importa cuál es, el flujo es siempre el mismo.
    // =====================================================================
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            // Bebidas disponibles. Para agregar otra: crear la clase y sumarla acá.
            Bebida[] bebidas =
            {
                new Cafe(),
                new ChocolateCaliente(),
                new Te(),
                new Licuado(),
                new Gaseosa()
            };

            while (true)
            {
                Console.WriteLine();
                Console.WriteLine("===== CAFETERÍA: ELEGÍ TU BEBIDA =====");
                for (int i = 0; i < bebidas.Length; i++)
                {
                    Console.WriteLine($"{i + 1}. {bebidas[i].Nombre} (${bebidas[i].Precio})");
                }
                Console.WriteLine("0. Salir");
                Console.Write("Opción: ");

                string entrada = Console.ReadLine() ?? "";

                if (entrada == "0")
                {
                    Console.WriteLine("¡Hasta la próxima!");
                    break;
                }

                if (int.TryParse(entrada, out int opcion) && opcion >= 1 && opcion <= bebidas.Length)
                {
                    // Template Method: el mismo llamado para cualquier bebida.
                    bebidas[opcion - 1].PrepararPedido();
                }
                else
                {
                    Console.WriteLine("Opción inválida.");
                }
            }
        }
    }
}
