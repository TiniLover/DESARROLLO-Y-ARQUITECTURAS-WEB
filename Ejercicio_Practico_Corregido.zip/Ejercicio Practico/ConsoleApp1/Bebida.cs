﻿using System;

namespace ConsoleApp1
{
    // =====================================================================
    // PATRÓN TEMPLATE METHOD — CLASE ABSTRACTA
    // ---------------------------------------------------------------------
    // ¿Por qué Template Method?
    //   Todas las bebidas siguen el MISMO flujo y en el MISMO orden:
    //     1. Tomar el pedido (mostrar menú)
    //     2. Validar la elección del cliente
    //     3. Preparar la bebida        <- cambia según la bebida
    //     4. Agregar el acompañamiento <- cambia según la bebida
    //     5. Mostrar el ticket (común)
    //   El flujo se escribe UNA vez en esta clase y cada bebida completa
    //   solo los pasos 3 y 4. Nadie puede saltear pasos ni cambiar el orden.
    // =====================================================================
    public abstract class Bebida
    {
        // -----------------------------------------------------------------
        // MÉTODO PLANTILLA: público y NO virtual (las subclases no lo cambian).
        // -----------------------------------------------------------------
        public void PrepararPedido()
        {
            TomarPedido();                       // 1. fijo
            string tamanio = ValidarEleccion();  // 2. fijo
            Preparar();                          // 3. abstracto
            AgregarAcompaniamiento();            // 4. abstracto
            if (OfreceCrema())                   // hook (desafío extra): solo si la bebida lo ofrece
            {
                PreguntarCrema();
            }
            MostrarTicket(tamanio);              // 5. fijo
        }

        // ------------- LO QUE DEFINE CADA BEBIDA (abstract = obligatorio) -------------
        public abstract string Nombre { get; }
        public abstract decimal Precio { get; }

        // PASO 3: cómo se prepara esta bebida.
        protected abstract void Preparar();

        // PASO 4: qué acompañamiento lleva.
        protected abstract void AgregarAcompaniamiento();

        // ------------- HOOK (virtual = opcional) -------------
        // Por defecto ninguna bebida ofrece crema. La que sí, lo sobrescribe
        // devolviendo true. Así no todas están obligadas a implementarlo.
        protected virtual bool OfreceCrema()
        {
            return false;
        }

        // ------------- PASOS FIJOS (private = nadie los cambia) -------------

        // PASO 1: muestra la bebida, su precio y los tamaños.
        private void TomarPedido()
        {
            Console.WriteLine();
            Console.WriteLine($"===== PEDIDO: {Nombre.ToUpper()} (${Precio}) =====");
            Console.WriteLine("Tamaños: 1. Chico  2. Grande");
        }

        // PASO 2: pide el tamaño hasta que la opción sea válida.
        private string ValidarEleccion()
        {
            while (true)
            {
                Console.Write("Elegí el tamaño: ");
                string entrada = Console.ReadLine() ?? "";
                if (entrada == "1") return "Chico";
                if (entrada == "2") return "Grande";
                Console.WriteLine("Opción inválida. Ingresá 1 o 2.");
            }
        }

        // Paso opcional del hook: pregunta si quiere crema.
        private void PreguntarCrema()
        {
            Console.Write("¿Querés agregar crema? (s/n): ");
            if ((Console.ReadLine() ?? "").Trim().ToLower() == "s")
            {
                Console.WriteLine("Agregando crema...");
            }
        }

        // PASO 5: ticket común con nombre, tamaño y precio.
        private void MostrarTicket(string tamanio)
        {
            Console.WriteLine("----------- TICKET -----------");
            Console.WriteLine($"{Nombre} ({tamanio}) ........ ${Precio}");
            Console.WriteLine("¡Gracias por tu compra!");
        }
    }
}
