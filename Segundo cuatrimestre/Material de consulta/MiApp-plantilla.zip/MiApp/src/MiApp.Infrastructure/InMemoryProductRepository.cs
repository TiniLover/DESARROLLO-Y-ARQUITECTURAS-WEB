using System.Collections.Concurrent;     // Para usar ConcurrentDictionary
using MiApp.Application.Abstractions;    // Para usar la interfaz IProductRepository
using MiApp.Domain;                      // Para usar Product

namespace MiApp.Infrastructure;

/// <summary>
/// REPOSITORIO EN MEMORIA: la "heladera" donde se guardan los productos.
/// ": IProductRepository" = esta clase CUMPLE la interfaz, así que tiene que tener TODOS sus métodos.
/// OJO: los datos se BORRAN cuando apagás la API, porque no hay base de datos.
/// </summary>
public sealed class InMemoryProductRepository : IProductRepository
{
    // DICCIONARIO: guarda pares "id → producto" (como una agenda: buscás por id y te da el producto).
    // "Concurrent" = aguanta varios pedidos al mismo tiempo sin romperse.
    // "readonly" = la variable no se reemplaza nunca (aunque su contenido sí cambia).
    private readonly ConcurrentDictionary<Guid, Product> items = new();

    public Task AddAsync(Product product, CancellationToken ct = default)
    {
        items[product.Id] = product;   // Guarda el producto usando su id como clave.
        return Task.CompletedTask;     // "Ya terminé". Lo pide la interfaz porque el método devuelve Task.
    }

    public Task<IReadOnlyCollection<Product>> GetAllAsync(CancellationToken ct = default)
    {
        IReadOnlyCollection<Product> all = items.Values.ToArray(); // .Values = todos los productos guardados.
        return Task.FromResult(all);   // Task.FromResult = "acá tenés el resultado, ya está listo".
    }

    public Task<Product?> GetByIdAsync(Guid id, CancellationToken ct = default)
    {
        // GetValueOrDefault = si existe lo devuelve; si no, devuelve null.
        Product? product = items.GetValueOrDefault(id);
        return Task.FromResult(product);
    }

    public Task UpdateAsync(Product product, CancellationToken ct = default)
    {
        items[product.Id] = product;   // Pisa el producto viejo con el nuevo (misma clave).
        return Task.CompletedTask;
    }

    public Task<bool> DeleteAsync(Guid id, CancellationToken ct = default)
    {
        // TryRemove = intenta borrarlo. Devuelve true si estaba y lo borró, false si no estaba.
        // "out _" = me devolvería el producto borrado, pero no me interesa (el "_" lo descarta).
        bool removed = items.TryRemove(id, out _);
        return Task.FromResult(removed);
    }
}
