using MiApp.Domain;   // "using" = voy a usar clases de otro lugar (acá, Product)

namespace MiApp.Application.Abstractions;

/// <summary>
/// INTERFAZ: es una LISTA de cosas que "alguien" tiene que saber hacer, SIN decir cómo.
/// Application dice "necesito guardar y buscar productos", pero no le importa si se usa
/// una lista en memoria o una base de datos. Eso lo decide Infrastructure.
/// </summary>
public interface IProductRepository   // Por convención, las interfaces empiezan con "I"
{
    // Task = el método es ASÍNCRONO (puede tardar, por ejemplo con una base de datos).
    // CancellationToken = permite cancelar si el cliente se va. "= default" lo hace opcional.

    Task AddAsync(Product product, CancellationToken ct = default);           // Guardar uno nuevo
    Task<IReadOnlyCollection<Product>> GetAllAsync(CancellationToken ct = default); // Traer todos (lista de solo lectura)
    Task<Product?> GetByIdAsync(Guid id, CancellationToken ct = default);     // Buscar por id. "?" = puede devolver null
    Task UpdateAsync(Product product, CancellationToken ct = default);        // Guardar cambios
    Task<bool> DeleteAsync(Guid id, CancellationToken ct = default);          // Borrar. true si lo borró, false si no existía
}
