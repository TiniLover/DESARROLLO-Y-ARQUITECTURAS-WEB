namespace MiApp.Application.Products;

/// <summary>
/// DTO (Data Transfer Object): la "cajita" con los datos que se le MANDAN al cliente.
/// No mandamos la entidad Product directamente, sino una copia de sus datos.
/// "record" = una clase cortita pensada solo para guardar datos.
/// </summary>
public sealed record ProductDto(Guid Id, string Name, decimal Price);
