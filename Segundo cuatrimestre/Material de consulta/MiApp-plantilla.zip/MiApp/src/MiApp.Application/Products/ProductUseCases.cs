using MiApp.Application.Abstractions;
using MiApp.Domain;

namespace MiApp.Application.Products;

// CASOS DE USO: cada clase es UNA acción del sistema (crear, listar, buscar, modificar, borrar).
// Es el "paso a paso" de cada operación.
//
// El "(IProductRepository repo)" al lado del nombre de la clase es un CONSTRUCTOR CORTO:
// la clase recibe un repositorio (la "heladera") sin saber cuál es. Se lo pasa la DI desde Program.cs.

// ---------- CREAR ----------
public sealed class CreateProductUseCase(IProductRepository repo)
{
    // "async" + "await" = esperá a que termine cada paso antes de seguir.
    // Devuelve Task<ProductDto> = "en algún momento te devuelvo un ProductDto".
    public async Task<ProductDto> ExecuteAsync(string name, decimal price, CancellationToken ct = default)
    {
        var product = Product.Create(name, price); // 1. Crea el producto (acá se valida; si está mal, tira error).
        await repo.AddAsync(product, ct);          // 2. Lo guarda en el repositorio.
        return product.ToDto();                    // 3. Devuelve la "cajita" con los datos.
    }
}

// ---------- LISTAR TODOS ----------
public sealed class GetProductsUseCase(IProductRepository repo)
{
    public async Task<IReadOnlyCollection<ProductDto>> ExecuteAsync(CancellationToken ct = default)
    {
        var products = await repo.GetAllAsync(ct);   // 1. Trae todos los productos.

        return products
            .Select(p => p.ToDto())   // 2. Select = "a cada uno, transformalo en DTO".
            .ToArray();               // 3. Lo convierte en un arreglo.
    }
}

// ---------- BUSCAR UNO POR ID ----------
public sealed class GetProductByIdUseCase(IProductRepository repo)
{
    // "ProductDto?" = puede devolver null (si no existe).
    public async Task<ProductDto?> ExecuteAsync(Guid id, CancellationToken ct = default)
    {
        var product = await repo.GetByIdAsync(id, ct);  // 1. Lo busca.

        if (product == null)                            // 2. Si no existe...
        {
            return null;                                //    ...devuelvo null (la API lo convierte en 404).
        }

        return product.ToDto();                         // 3. Si existe, devuelvo el DTO.
    }
}

// ---------- MODIFICAR ----------
public sealed class UpdateProductUseCase(IProductRepository repo)
{
    public async Task<ProductDto?> ExecuteAsync(Guid id, string name, decimal price, CancellationToken ct = default)
    {
        var product = await repo.GetByIdAsync(id, ct);  // 1. Busco el producto.

        if (product == null)                            // 2. Si no existe → null (404).
        {
            return null;
        }

        product.Update(name, price);                    // 3. Lo modifico (valida; si está mal, tira error).
        await repo.UpdateAsync(product, ct);            // 4. Guardo los cambios.
        return product.ToDto();                         // 5. Devuelvo el DTO actualizado.
    }
}

// ---------- BORRAR ----------
public sealed class DeleteProductUseCase(IProductRepository repo)
{
    // Devuelve true si lo borró o false si no existía.
    public async Task<bool> ExecuteAsync(Guid id, CancellationToken ct = default)
    {
        return await repo.DeleteAsync(id, ct);
    }
}

// ---------- CONVERSOR Product → ProductDto ----------
// "internal" = solo se usa dentro de este proyecto (Application).
// "static" = no hace falta crear un objeto para usarlo.
internal static class ProductMapping
{
    // El "this" delante del parámetro permite escribir "product.ToDto()"
    // como si fuera un método del producto (se llama "método de extensión").
    public static ProductDto ToDto(this Product product)
    {
        return new ProductDto(product.Id, product.Name, product.Price);
    }
}
