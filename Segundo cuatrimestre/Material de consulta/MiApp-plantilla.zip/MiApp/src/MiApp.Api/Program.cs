using MiApp.Application.Abstractions;
using MiApp.Application.Products;
using MiApp.Infrastructure;

// =====================================================================
// PARTE 1: ARMAR LA APLICACIÓN
// =====================================================================

// Empieza a "armar" la app web. "args" son los parámetros con los que se ejecutó el programa.
var builder = WebApplication.CreateBuilder(args);

// ---------- INYECCIÓN DE DEPENDENCIAS (DI) ----------
// Acá le decimos a .NET: "cuando alguien pida X, dale Y".

// "Cuando alguien pida un IProductRepository, dale un InMemoryProductRepository".
// AddSingleton = se crea UNO SOLO para toda la app.
// ¡Tiene que ser Singleton! Si no, cada pedido tendría una "heladera" nueva y vacía.
builder.Services.AddSingleton<IProductRepository, InMemoryProductRepository>();

// Registramos cada caso de uso.
// AddScoped = se crea uno nuevo por cada pedido HTTP.
// Si te olvidás de alguno, aparece el error "Unable to resolve service...".
builder.Services.AddScoped<CreateProductUseCase>();
builder.Services.AddScoped<GetProductsUseCase>();
builder.Services.AddScoped<GetProductByIdUseCase>();
builder.Services.AddScoped<UpdateProductUseCase>();
builder.Services.AddScoped<DeleteProductUseCase>();

// ---------- SWAGGER ----------
builder.Services.AddEndpointsApiExplorer(); // Busca todos los endpoints que definimos abajo.
builder.Services.AddSwaggerGen();           // Genera la documentación que usa Swagger.

// Termina de armar la app.
// REGLA: todos los "builder.Services..." van ANTES de esta línea y todos los "app..." van DESPUÉS.
var app = builder.Build();

// Mientras programás (modo Development), activa la página de Swagger en /swagger.
if (app.Environment.IsDevelopment())
{
    // SerializeAsV2 = true: evita el error "does not specify a valid version field" en Swagger.
    app.UseSwagger(options => options.SerializeAsV2 = true);  // Publica la documentación en JSON.
    app.UseSwaggerUI();                                       // Publica la página con botones para probar.
}

// =====================================================================
// PARTE 2: LOS ENDPOINTS (las "rutas" de la API)
// =====================================================================

// MapGroup agrupa rutas: todo lo que se defina con "products" empieza con "/products".
// WithOpenApi() hace que aparezcan en Swagger.
var products = app.MapGroup("/products").WithOpenApi();

// Los parámetros de cada endpoint los completa .NET SOLO:
//   - Si el nombre está en la ruta (como {id}) → lo saca de la URL.
//   - Si es un record como ProductRequest → lo saca del JSON que manda el cliente.
//   - Si es un caso de uso → lo saca de la DI (lo que registramos arriba).
//   - CancellationToken → lo pone .NET automáticamente.

// ---------- GET /products → LISTAR TODOS ----------
products.MapGet("/", async (GetProductsUseCase useCase, CancellationToken ct) =>
{
    var list = await useCase.ExecuteAsync(ct);
    return Results.Ok(list);                  // 200 OK + la lista en JSON
});

// ---------- GET /products/{id} → BUSCAR UNO ----------
// "{id:guid}" = esa parte de la URL es un parámetro y tiene que ser un Guid.
// Ejemplo: GET /products/3fa85f64-5717-4562-b3fc-2c963f66afa6
products.MapGet("/{id:guid}", async (Guid id, GetProductByIdUseCase useCase, CancellationToken ct) =>
{
    var product = await useCase.ExecuteAsync(id, ct);

    if (product == null)
    {
        return Results.NotFound();            // 404 = no existe
    }

    return Results.Ok(product);               // 200 OK + el producto
});

// ---------- POST /products → CREAR ----------
// El cliente manda un JSON como: { "name": "Mouse", "price": 100 }
// .NET lo convierte solo en "ProductRequest request".
products.MapPost("/", async (ProductRequest request, CreateProductUseCase useCase, CancellationToken ct) =>
{
    // try / catch = "intentá esto, y si el Domain tira un error de validación, atrapalo".
    try
    {
        var product = await useCase.ExecuteAsync(request.Name, request.Price, ct);

        // 201 Created + dónde encontrar el producto nuevo + el producto.
        // El $"..." permite meter variables dentro del texto con {llaves}.
        return Results.Created($"/products/{product.Id}", product);
    }
    catch (ArgumentException ex)
    {
        // 400 Bad Request + el mensaje de error (por ejemplo "El nombre es obligatorio.")
        return Results.BadRequest(new { error = ex.Message });
    }
});

// ---------- PUT /products/{id} → MODIFICAR ----------
// Recibe el id por la URL y los datos nuevos por el JSON.
products.MapPut("/{id:guid}", async (Guid id, ProductRequest request, UpdateProductUseCase useCase, CancellationToken ct) =>
{
    try
    {
        var product = await useCase.ExecuteAsync(id, request.Name, request.Price, ct);

        if (product == null)
        {
            return Results.NotFound();        // 404 = no existe
        }

        return Results.Ok(product);           // 200 OK + el producto modificado
    }
    catch (ArgumentException ex)
    {
        return Results.BadRequest(new { error = ex.Message }); // 400 = datos inválidos
    }
});

// ---------- DELETE /products/{id} → BORRAR ----------
products.MapDelete("/{id:guid}", async (Guid id, DeleteProductUseCase useCase, CancellationToken ct) =>
{
    bool deleted = await useCase.ExecuteAsync(id, ct);

    if (!deleted)                             // "!" = "no". Si NO se borró (porque no existía)...
    {
        return Results.NotFound();            // 404
    }

    return Results.NoContent();               // 204 = se borró, no hay nada que devolver
});

// PRENDE la API. Queda escuchando pedidos hasta que apretás Ctrl + C.
// ¡Sin esta línea no funciona nada!
app.Run();

// =====================================================================
// PARTE 3: LO QUE MANDA EL CLIENTE
// =====================================================================

// La "forma" del JSON que manda el cliente en POST y PUT.
// Va AL FINAL del archivo, después de app.Run().
public sealed record ProductRequest(string Name, decimal Price);
