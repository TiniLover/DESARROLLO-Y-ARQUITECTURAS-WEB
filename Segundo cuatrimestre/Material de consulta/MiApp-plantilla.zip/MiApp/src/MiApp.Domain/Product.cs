// "namespace" es como la "dirección" de la clase. Tiene que coincidir con el nombre del proyecto.
namespace MiApp.Domain;

/// <summary>
/// ENTIDAD: representa un producto y guarda sus REGLAS.
/// No sabe nada de HTTP, JSON ni bases de datos. Es C# puro.
/// </summary>
public sealed class Product   // "sealed" = nadie puede heredar de esta clase
{
    // CONSTRUCTOR PRIVADO: desde afuera NO se puede hacer "new Product(...)".
    // Así obligamos a que todos usen el método Create(), que es el que valida.
    private Product(Guid id, string name, decimal price)
    {
        Id = id;
        Name = name;
        Price = price;
    }

    // PROPIEDADES (los datos del producto)
    public Guid Id { get; }                     // Guid = identificador único. Solo lectura: nunca cambia.
    public string Name { get; private set; }    // Se puede leer desde afuera, pero solo esta clase lo modifica.
    public decimal Price { get; private set; }  // decimal = número con coma, ideal para plata.

    // MÉTODO PARA CREAR: es la única "puerta de entrada" para crear un producto.
    // "static" = se llama sin tener un producto antes: Product.Create("Mouse", 100)
    public static Product Create(string name, decimal price)
    {
        Validate(name, price);                  // 1. Primero reviso que los datos sean válidos.

        return new Product(
            Guid.NewGuid(),                     // 2. Genero un id nuevo al azar.
            name.Trim(),                        //    Trim() saca los espacios del principio y del final.
            price);
    }

    // MÉTODO PARA MODIFICAR: cambia los datos, pero validando antes.
    public void Update(string name, decimal price)
    {
        Validate(name, price);
        Name = name.Trim();
        Price = price;
    }

    // VALIDACIONES: acá van las REGLAS DE NEGOCIO que pide el enunciado.
    // "private" = solo se usa dentro de esta clase.
    private static void Validate(string name, decimal price)
    {
        // Si el nombre es null, está vacío o tiene solo espacios → error.
        if (string.IsNullOrWhiteSpace(name))
        {
            // "throw" corta todo y lanza un error. La API lo atrapa y responde 400.
            throw new ArgumentException("El nombre es obligatorio.", nameof(name));
        }

        // Si el precio es 0 o negativo → error.
        if (price <= 0)
        {
            throw new ArgumentException("El precio debe ser mayor a 0.", nameof(price));
        }
    }
}
