using MiApp.Application.Abstractions;
using MiApp.Application.Products;
using MiApp.Domain;

namespace MiApp.Tests;

public sealed class ProductTests
{
    // [Fact] = marca el método como un TEST. "dotnet test" corre todos los que lo tengan.

    // ---------- TEST DEL DOMAIN: probar una regla ----------
    [Fact]
    public void Create_rejects_empty_name()
    {
        // Assert.Throws = "comprobá que esto TIRE un error de este tipo".
        // Si crear un producto sin nombre NO tira error, el test FALLA.
        Assert.Throws<ArgumentException>(() => Product.Create("   ", 100));
    }

    [Fact]
    public void Create_rejects_negative_price()
    {
        Assert.Throws<ArgumentException>(() => Product.Create("Mouse", -1));
    }

    // ---------- TEST DE UN CASO DE USO ----------
    // "async Task" porque el caso de uso es asíncrono.
    [Fact]
    public async Task Create_use_case_saves_the_product()
    {
        // 1. PREPARAR (Arrange): un repositorio falso y el caso de uso.
        var repo = new FakeProductRepository();
        var useCase = new CreateProductUseCase(repo);

        // 2. EJECUTAR (Act): llamar al caso de uso.
        var result = await useCase.ExecuteAsync("  Mouse  ", 100);

        // 3. COMPROBAR (Assert): que el resultado sea el esperado.
        Assert.Equal("Mouse", result.Name);   // Assert.Equal(esperado, real): se sacaron los espacios
        Assert.Single(repo.Items);            // Assert.Single = hay EXACTAMENTE 1 guardado
    }

    // ---------- REPOSITORIO FALSO ----------
    // Una versión "de mentira" del repositorio, solo para los tests.
    // Así probamos el caso de uso sin depender de Infrastructure.
    private sealed class FakeProductRepository : IProductRepository
    {
        public List<Product> Items { get; } = [];   // "[]" = una lista vacía

        public Task AddAsync(Product product, CancellationToken ct = default)
        {
            Items.Add(product);
            return Task.CompletedTask;
        }

        public Task<IReadOnlyCollection<Product>> GetAllAsync(CancellationToken ct = default) =>
            Task.FromResult<IReadOnlyCollection<Product>>(Items);

        public Task<Product?> GetByIdAsync(Guid id, CancellationToken ct = default) =>
            Task.FromResult(Items.FirstOrDefault(p => p.Id == id)); // El primero con ese id, o null

        public Task UpdateAsync(Product product, CancellationToken ct = default) =>
            Task.CompletedTask;               // En memoria ya está modificado, no hay nada que hacer

        public Task<bool> DeleteAsync(Guid id, CancellationToken ct = default) =>
            Task.FromResult(Items.RemoveAll(p => p.Id == id) > 0); // true si borró alguno
    }
}
