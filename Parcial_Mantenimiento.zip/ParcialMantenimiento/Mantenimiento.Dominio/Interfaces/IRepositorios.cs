﻿using System.Collections.Generic;
using Mantenimiento.Dominio.Entidades;

namespace Mantenimiento.Dominio.Interfaces
{
    // =====================================================================
    // INTERFACES DE LOS REPOSITORIOS (contratos)
    // ---------------------------------------------------------------------
    // ¿Por qué están en el DOMINIO y no en Infraestructura?
    // Por la REGLA DE DEPENDENCIA de Clean Architecture: las capas de afuera
    // dependen de las de adentro, nunca al revés.
    //   - El Dominio dice QUÉ necesita ("guardame un técnico", "buscame un
    //     servicio") mediante una interfaz.
    //   - Infraestructura dice CÓMO lo hace (lista en memoria, SQL, archivo)
    //     implementando esa interfaz.
    // Esto se llama INVERSIÓN DE DEPENDENCIAS (la "D" de SOLID). Si mañana
    // cambiamos la lista en memoria por una base de datos, solo se toca
    // Infraestructura; Dominio y Aplicación no cambian ni una línea.
    //
    // Las tres interfaces van en un mismo archivo porque son cortas; también
    // es válido poner una por archivo.
    // =====================================================================

    public interface ITecnicoRepositorio
    {
        Tecnico ObtenerPorDni(string dni);   // devuelve null si no existe
        List<Tecnico> ObtenerTodos();
        void Agregar(Tecnico tecnico);
    }

    public interface IServicioRepositorio
    {
        Servicio ObtenerPorCodigo(int codigo); // devuelve null si no existe
        List<Servicio> ObtenerTodos();
        void Agregar(Servicio servicio);
    }

    public interface ICiudadRepositorio
    {
        Ciudad ObtenerPorCodigo(int codigo);   // devuelve null si no existe
        List<Ciudad> ObtenerTodas();
    }
}
