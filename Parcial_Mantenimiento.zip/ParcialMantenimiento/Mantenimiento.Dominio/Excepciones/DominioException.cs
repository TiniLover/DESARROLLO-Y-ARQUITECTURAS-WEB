﻿using System;

namespace Mantenimiento.Dominio.Excepciones
{
    // =====================================================================
    // Excepción propia del negocio.
    // Se lanza cuando se rompe una regla (dato obligatorio vacío, técnico
    // inexistente, código repetido, etc.). La presentación la atrapa y
    // muestra el mensaje al usuario sin que el programa se cierre.
    // Tener un tipo propio permite distinguir "error de negocio" (mensaje
    // para el usuario) de un error inesperado del sistema.
    // =====================================================================
    public class DominioException : Exception
    {
        public DominioException(string mensaje) : base(mensaje) { }
    }
}
