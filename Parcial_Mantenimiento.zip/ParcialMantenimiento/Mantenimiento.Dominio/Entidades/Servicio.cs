﻿using Mantenimiento.Dominio.Excepciones;

namespace Mantenimiento.Dominio.Entidades
{
    // =====================================================================
    // CAPA DE DOMINIO - ENTIDAD Servicio
    // ---------------------------------------------------------------------
    // Atributos del enunciado: código, descripción y dirección del lugar.
    //
    // RELACIONES (reglas de negocio del enunciado):
    //   - "cada servicio es realizado por UN SOLO técnico"
    //        -> propiedad Tecnico (una sola, no una lista).
    //   - "un servicio se realiza en UNA ciudad"
    //        -> propiedad Ciudad (una sola, no una lista).
    // Del otro lado: muchos servicios pueden apuntar al mismo técnico o a la
    // misma ciudad, y eso cumple el "uno a muchos" que pide el enunciado.
    // =====================================================================
    public class Servicio
    {
        public int Codigo { get; private set; }
        public string Descripcion { get; private set; }
        public string DireccionLugar { get; private set; }

        // Navegación hacia el técnico y la ciudad (relación "muchos a uno").
        public Tecnico Tecnico { get; private set; }
        public Ciudad Ciudad { get; private set; }

        public Servicio(int codigo, string descripcion, string direccionLugar, Tecnico tecnico, Ciudad ciudad)
        {
            if (codigo <= 0)
                throw new DominioException("El código del servicio debe ser mayor a 0.");
            if (string.IsNullOrWhiteSpace(descripcion))
                throw new DominioException("La descripción del servicio es obligatoria.");
            if (string.IsNullOrWhiteSpace(direccionLugar))
                throw new DominioException("La dirección del lugar es obligatoria.");

            // Regla: un servicio SIEMPRE tiene un técnico y una ciudad.
            if (tecnico == null)
                throw new DominioException("El servicio debe tener un técnico asignado.");
            if (ciudad == null)
                throw new DominioException("El servicio debe realizarse en una ciudad.");

            Codigo = codigo;
            Descripcion = descripcion.Trim();
            DireccionLugar = direccionLugar.Trim();
            Tecnico = tecnico;
            Ciudad = ciudad;
        }
    }
}
