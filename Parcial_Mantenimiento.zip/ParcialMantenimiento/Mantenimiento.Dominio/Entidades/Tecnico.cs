﻿using Mantenimiento.Dominio.Excepciones;

namespace Mantenimiento.Dominio.Entidades
{
    // =====================================================================
    // CAPA DE DOMINIO - ENTIDAD Tecnico
    // ---------------------------------------------------------------------
    // ¿Qué es el Dominio? Es el CENTRO de Clean Architecture: contiene las
    // entidades del negocio y sus reglas. NO depende de ninguna otra capa
    // (no sabe que existe la consola, ni la lista en memoria, ni los DTOs).
    //
    // Atributos que pide el enunciado: DNI, nombre, teléfono, dirección y
    // especialidad.
    //
    // Relación: "un técnico puede realizar muchos servicios". No hace falta
    // guardar una lista de servicios acá: la relación se resuelve desde el
    // lado del Servicio (cada Servicio apunta a SU técnico). Así evitamos
    // tener el dato repetido en dos lugares.
    // =====================================================================
    public class Tecnico
    {
        // "private set": nadie de afuera puede cambiar los datos a mano;
        // solo se cargan por el constructor, que valida. Así la entidad
        // nunca queda en un estado inválido.
        public string Dni { get; private set; }
        public string Nombre { get; private set; }
        public string Telefono { get; private set; }
        public string Direccion { get; private set; }
        public string Especialidad { get; private set; }

        public Tecnico(string dni, string nombre, string telefono, string direccion, string especialidad)
        {
            // Reglas de negocio de la entidad: datos obligatorios.
            // Se validan acá (en el Dominio) porque son reglas propias del
            // técnico, valen sin importar si se carga desde consola o WinForms.
            if (string.IsNullOrWhiteSpace(dni))
                throw new DominioException("El DNI del técnico es obligatorio.");
            if (string.IsNullOrWhiteSpace(nombre))
                throw new DominioException("El nombre del técnico es obligatorio.");
            if (string.IsNullOrWhiteSpace(especialidad))
                throw new DominioException("La especialidad del técnico es obligatoria.");

            // El DNI se "limpia" (se sacan puntos, espacios y guiones) para
            // aceptar tanto 30111222 como 30.111.222.
            // Regla: el DNI tiene que ser SOLO NÚMEROS (sin letras).
            // No se limita la cantidad de dígitos porque el enunciado no lo pide.
            string dniLimpio = NormalizarDni(dni);
            if (!SoloDigitos(dniLimpio))
                throw new DominioException("El DNI debe contener solo números. Ingresaste \"" + dni.Trim() + "\".");

            Dni = dniLimpio;
            Nombre = nombre.Trim();
            Telefono = telefono == null ? "" : telefono.Trim();
            Direccion = direccion == null ? "" : direccion.Trim();
            Especialidad = especialidad.Trim();
        }

        // Saca puntos, espacios y guiones del DNI.
        // Es "public static" porque el repositorio también lo usa al BUSCAR,
        // así "30.111.222" encuentra al técnico guardado como "30111222".
        public static string NormalizarDni(string dni)
        {
            if (dni == null) return "";
            return dni.Replace(".", "").Replace(" ", "").Replace("-", "").Trim();
        }

        // Método auxiliar privado: solo lo usa esta clase.
        private static bool SoloDigitos(string texto)
        {
            foreach (char c in texto)
            {
                if (!char.IsDigit(c)) return false;
            }
            return true;
        }
    }
}
