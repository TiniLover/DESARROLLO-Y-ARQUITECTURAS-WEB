﻿using Mantenimiento.Dominio.Excepciones;

namespace Mantenimiento.Dominio.Entidades
{
    // =====================================================================
    // CAPA DE DOMINIO - ENTIDAD Ciudad
    // Atributos del enunciado: código y nombre.
    // Relación: "una ciudad puede tener muchos servicios". Igual que con el
    // técnico, la relación se guarda del lado del Servicio.
    // =====================================================================
    public class Ciudad
    {
        public int Codigo { get; private set; }
        public string Nombre { get; private set; }

        public Ciudad(int codigo, string nombre)
        {
            if (codigo <= 0)
                throw new DominioException("El código de la ciudad debe ser mayor a 0.");
            if (string.IsNullOrWhiteSpace(nombre))
                throw new DominioException("El nombre de la ciudad es obligatorio.");

            Codigo = codigo;
            Nombre = nombre.Trim();
        }
    }
}
