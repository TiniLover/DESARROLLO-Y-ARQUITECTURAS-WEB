﻿using System.Collections.Generic;
using Mantenimiento.Dominio.Entidades;

namespace Mantenimiento.Infraestructura.Datos
{
    // =====================================================================
    // CAPA DE INFRAESTRUCTURA - "BASE DE DATOS" EN MEMORIA
    // ---------------------------------------------------------------------
    // El enunciado pide "repositorio en memoria con datos de prueba".
    // Esta clase hace de base de datos: tiene una lista por cada entidad y
    // las carga con datos de prueba al crearse.
    //
    // ¿Por qué una clase aparte y no una lista dentro de cada repositorio?
    // Porque los datos están RELACIONADOS: los servicios de prueba apuntan a
    // técnicos y ciudades de prueba. Teniendo todo junto, los tres
    // repositorios comparten los MISMOS datos.
    //
    // Se crea UNA sola vez en Program.cs (composición) y se le pasa a los
    // tres repositorios. Así todos trabajan sobre la misma información
    // mientras el programa esté abierto (al cerrarlo, se pierde: es memoria).
    // =====================================================================
    public class ContextoEnMemoria
    {
        public List<Tecnico> Tecnicos { get; private set; }
        public List<Ciudad> Ciudades { get; private set; }
        public List<Servicio> Servicios { get; private set; }

        public ContextoEnMemoria()
        {
            Tecnicos = new List<Tecnico>();
            Ciudades = new List<Ciudad>();
            Servicios = new List<Servicio>();

            CargarDatosDePrueba();
        }

        private void CargarDatosDePrueba()
        {
            // ---- Ciudades ----
            Ciudad cordoba = new Ciudad(1, "Córdoba");
            Ciudad rosario = new Ciudad(2, "Rosario");
            Ciudad mendoza = new Ciudad(3, "Mendoza");
            Ciudades.AddRange(new[] { cordoba, rosario, mendoza });

            // ---- Técnicos ----
            Tecnico juan = new Tecnico("30111222", "Juan Pérez", "351-4445566", "Av. Colón 1200", "Electricidad");
            Tecnico maria = new Tecnico("28999888", "María Gómez", "341-5556677", "Bv. Oroño 450", "Plomería");
            Tecnico carlos = new Tecnico("35123456", "Carlos Díaz", "261-4223344", "San Martín 800", "Refrigeración");
            Tecnicos.AddRange(new[] { juan, maria, carlos });

            // ---- Servicios ----
            // Se ven las reglas del enunciado:
            //   - Juan hace DOS servicios (un técnico -> muchos servicios).
            //   - Córdoba tiene DOS servicios (una ciudad -> muchos servicios).
            //   - Cada servicio tiene UN técnico y UNA ciudad.
            Servicios.Add(new Servicio(100, "Reparación de tablero eléctrico", "Dean Funes 350", juan, cordoba));
            Servicios.Add(new Servicio(101, "Instalación de tomacorrientes", "Bv. San Juan 900", juan, cordoba));
            Servicios.Add(new Servicio(102, "Arreglo de pérdida de agua", "Córdoba 1500", maria, rosario));
            Servicios.Add(new Servicio(103, "Carga de gas de aire acondicionado", "Las Heras 220", carlos, mendoza));
        }
    }
}
