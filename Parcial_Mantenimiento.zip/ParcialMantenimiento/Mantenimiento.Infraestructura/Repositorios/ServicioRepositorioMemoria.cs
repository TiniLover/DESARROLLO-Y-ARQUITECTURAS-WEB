﻿using System.Collections.Generic;
using Mantenimiento.Dominio.Entidades;
using Mantenimiento.Dominio.Interfaces;
using Mantenimiento.Infraestructura.Datos;

namespace Mantenimiento.Infraestructura.Repositorios
{
    // Implementación en memoria de IServicioRepositorio.
    // Misma idea que TecnicoRepositorioMemoria.
    public class ServicioRepositorioMemoria : IServicioRepositorio
    {
        private readonly ContextoEnMemoria _contexto;

        public ServicioRepositorioMemoria(ContextoEnMemoria contexto)
        {
            _contexto = contexto;
        }

        public Servicio ObtenerPorCodigo(int codigo)
        {
            foreach (Servicio servicio in _contexto.Servicios)
            {
                if (servicio.Codigo == codigo) return servicio;
            }
            return null;
        }

        public List<Servicio> ObtenerTodos()
        {
            // Copia de la lista (nadie de afuera modifica la original).
            return new List<Servicio>(_contexto.Servicios);
        }

        public void Agregar(Servicio servicio)
        {
            _contexto.Servicios.Add(servicio);
        }
    }
}
