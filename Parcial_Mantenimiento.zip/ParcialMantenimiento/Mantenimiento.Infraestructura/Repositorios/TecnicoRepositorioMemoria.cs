﻿using System.Collections.Generic;
using Mantenimiento.Dominio.Entidades;
using Mantenimiento.Dominio.Interfaces;
using Mantenimiento.Infraestructura.Datos;

namespace Mantenimiento.Infraestructura.Repositorios
{
    // =====================================================================
    // IMPLEMENTACIÓN del contrato ITecnicoRepositorio (definido en Dominio).
    // Acá está el "CÓMO": se guarda en una lista en memoria.
    // Si mañana se usa SQL Server, se crea otra clase (por ejemplo
    // TecnicoRepositorioSql) que implemente la MISMA interfaz, y solo se
    // cambia una línea en Program.cs.
    //
    // También usa inyección por constructor: recibe el contexto compartido.
    // =====================================================================
    public class TecnicoRepositorioMemoria : ITecnicoRepositorio
    {
        private readonly ContextoEnMemoria _contexto;

        public TecnicoRepositorioMemoria(ContextoEnMemoria contexto)
        {
            _contexto = contexto;
        }

        public Tecnico ObtenerPorDni(string dni)
        {
            if (dni == null) return null;
            // Se normaliza igual que al guardar (sin puntos ni espacios).
            string buscado = Tecnico.NormalizarDni(dni);

            // Recorre la lista buscando el DNI; si no lo encuentra, null.
            foreach (Tecnico tecnico in _contexto.Tecnicos)
            {
                if (tecnico.Dni == buscado) return tecnico;
            }
            return null;
        }

        public List<Tecnico> ObtenerTodos()
        {
            // Se devuelve una COPIA de la lista para que nadie de afuera
            // pueda agregar o borrar elementos sin pasar por el repositorio.
            return new List<Tecnico>(_contexto.Tecnicos);
        }

        public void Agregar(Tecnico tecnico)
        {
            _contexto.Tecnicos.Add(tecnico);
        }
    }
}
