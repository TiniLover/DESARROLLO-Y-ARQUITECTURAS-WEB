﻿using System.Collections.Generic;
using Mantenimiento.Dominio.Entidades;
using Mantenimiento.Dominio.Interfaces;
using Mantenimiento.Infraestructura.Datos;

namespace Mantenimiento.Infraestructura.Repositorios
{
    // Implementación en memoria de ICiudadRepositorio.
    // Las ciudades vienen cargadas desde los datos de prueba
    // (el enunciado no pide dar de alta ciudades).
    public class CiudadRepositorioMemoria : ICiudadRepositorio
    {
        private readonly ContextoEnMemoria _contexto;

        public CiudadRepositorioMemoria(ContextoEnMemoria contexto)
        {
            _contexto = contexto;
        }

        public Ciudad ObtenerPorCodigo(int codigo)
        {
            foreach (Ciudad ciudad in _contexto.Ciudades)
            {
                if (ciudad.Codigo == codigo) return ciudad;
            }
            return null;
        }

        public List<Ciudad> ObtenerTodas()
        {
            return new List<Ciudad>(_contexto.Ciudades);
        }
    }
}
