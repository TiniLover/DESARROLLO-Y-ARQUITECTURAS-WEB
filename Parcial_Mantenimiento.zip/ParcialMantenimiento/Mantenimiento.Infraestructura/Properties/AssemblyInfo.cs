﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Mantenimiento.Infraestructura")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Mantenimiento.Infraestructura")]
[assembly: AssemblyCopyright("Copyright © 2026")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("f61102ee-e7e3-445c-bef2-bf8301b27086")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
