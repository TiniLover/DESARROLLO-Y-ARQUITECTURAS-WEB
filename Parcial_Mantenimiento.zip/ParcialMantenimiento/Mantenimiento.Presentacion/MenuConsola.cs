﻿using System;
using System.Collections.Generic;
using Mantenimiento.Aplicacion.DTOs;
using Mantenimiento.Aplicacion.Interfaces;
using Mantenimiento.Aplicacion.Excepciones;

namespace Mantenimiento.Presentacion
{
    // =====================================================================
    // CAPA DE PRESENTACIÓN - MENÚ DE CONSOLA
    // ---------------------------------------------------------------------
    // Responsabilidad: SOLO pedir datos al usuario y mostrar resultados.
    // No tiene reglas de negocio ni sabe dónde se guardan los datos.
    //
    // Fijate en los "using" de arriba: SOLO usa cosas de Aplicación
    // (DTOs, interfaces y AplicacionException). NO usa ninguna entidad
    // (Tecnico, Servicio, Ciudad), ni repositorios, ni nada del Dominio.
    //
    // Recibe los servicios por constructor = inyección de dependencias.
    // =====================================================================
    public class MenuConsola
    {
        private readonly ITecnicoAppService _tecnicoAppService;
        private readonly IServicioAppService _servicioAppService;

        public MenuConsola(ITecnicoAppService tecnicoAppService, IServicioAppService servicioAppService)
        {
            _tecnicoAppService = tecnicoAppService;
            _servicioAppService = servicioAppService;
        }

        // Bucle principal del menú.
        public void Ejecutar()
        {
            while (true)
            {
                Console.WriteLine();
                Console.WriteLine("===== GESTIÓN DE SERVICIOS DE MANTENIMIENTO =====");
                Console.WriteLine("1. Consultar servicio por código");
                Console.WriteLine("2. Agregar técnico");
                Console.WriteLine("3. Listar técnicos");
                Console.WriteLine("4. Registrar servicio");
                Console.WriteLine("0. Salir");
                Console.Write("Elegí una opción del menú (0 a 4): ");

                string opcion = LeerLinea();
                if (opcion == null || opcion == "0")
                {
                    Console.WriteLine("¡Hasta luego!");
                    return;
                }

                // try/catch acá: cualquier error de negocio (AplicacionException)
                // se muestra como mensaje y el menú sigue funcionando.
                try
                {
                    switch (opcion)
                    {
                        case "1": ConsultarServicio(); break;
                        case "2": AgregarTecnico(); break;
                        case "3": ListarTecnicos(); break;
                        case "4": RegistrarServicio(); break;
                        default:
                            // Aclaración: primero se elige la OPCIÓN (1 a 4) y
                            // DESPUÉS el programa pide el código del servicio.
                            Console.WriteLine("Opción inválida. Primero elegí una opción del 0 al 4;");
                            Console.WriteLine("después el programa te pide el código.");
                            break;
                    }
                }
                catch (AplicacionException ex)
                {
                    Console.WriteLine("ERROR: " + ex.Message);
                }

                // Pausa: así el resultado no "desaparece" cuando el menú se
                // vuelve a imprimir.
                Console.WriteLine();
                Console.Write("Presioná Enter para volver al menú...");
                if (LeerLinea() == null) return;
            }
        }

        // ------------------------------------------------------------
        // OPCIÓN 1: Consultar servicio por código (obligatoria)
        // ------------------------------------------------------------
        private void ConsultarServicio()
        {
            Console.WriteLine();
            Console.WriteLine("--- CONSULTAR SERVICIO ---");
            MostrarServiciosExistentes();
            int codigo = PedirEntero("Código del servicio: ");

            // La aplicación devuelve un DTO con todo lo que hay que mostrar.
            ServicioDetalleDto dto = _servicioAppService.ConsultarPorCodigo(codigo);

            Console.WriteLine("----- Datos del servicio -----");
            Console.WriteLine("Código:          " + dto.Codigo);
            Console.WriteLine("Descripción:     " + dto.Descripcion);
            Console.WriteLine("Dirección lugar: " + dto.DireccionLugar);
            Console.WriteLine("Técnico:         " + dto.NombreTecnico);
            Console.WriteLine("Ciudad:          " + dto.NombreCiudad);
        }

        // ------------------------------------------------------------
        // OPCIÓN 2: Agregar técnico (obligatoria)
        // ------------------------------------------------------------
        private void AgregarTecnico()
        {
            Console.WriteLine();
            Console.WriteLine("--- AGREGAR TÉCNICO ---");
            // Se llena un DTO (NO una entidad) y se manda a la aplicación.
            TecnicoDto dto = new TecnicoDto();
            dto.Dni = PedirTexto("DNI: ");
            dto.Nombre = PedirTexto("Nombre: ");
            dto.Telefono = PedirTexto("Teléfono: ");
            dto.Direccion = PedirTexto("Dirección: ");
            dto.Especialidad = PedirTexto("Especialidad: ");

            _tecnicoAppService.AgregarTecnico(dto);
            Console.WriteLine("Técnico agregado correctamente.");
        }

        // ------------------------------------------------------------
        // OPCIÓN 3: Listar técnicos (opcional)
        // ------------------------------------------------------------
        private void ListarTecnicos()
        {
            List<TecnicoDto> tecnicos = _tecnicoAppService.ListarTecnicos();

            if (tecnicos.Count == 0)
            {
                Console.WriteLine("No hay técnicos cargados.");
                return;
            }

            Console.WriteLine("----- Técnicos -----");
            foreach (TecnicoDto t in tecnicos)
            {
                Console.WriteLine(t.Dni + " | " + t.Nombre + " | " + t.Telefono + " | "
                                  + t.Direccion + " | " + t.Especialidad);
            }
        }

        // ------------------------------------------------------------
        // OPCIÓN 4: Registrar servicio (opcional)
        // ------------------------------------------------------------
        private void RegistrarServicio()
        {
            Console.WriteLine();
            Console.WriteLine("--- REGISTRAR SERVICIO ---");
            MostrarServiciosExistentes();
            Console.WriteLine("(El código del nuevo servicio tiene que ser uno que NO esté en la lista.)");
            // Ayuda para el usuario: se muestran técnicos y ciudades que
            // existen, así sabe qué DNI y qué código de ciudad ingresar.
            ListarTecnicos();
            Console.WriteLine("----- Ciudades -----");
            foreach (CiudadDto c in _servicioAppService.ListarCiudades())
            {
                Console.WriteLine(c.Codigo + " | " + c.Nombre);
            }

            RegistrarServicioDto dto = new RegistrarServicioDto();
            dto.Codigo = PedirEntero("Código del NUEVO servicio (número): ");
            dto.Descripcion = PedirTexto("Descripción: ");
            dto.DireccionLugar = PedirTexto("Dirección del lugar: ");
            dto.DniTecnico = PedirTexto("DNI del técnico: ");
            dto.CodigoCiudad = PedirEntero("Código de la ciudad: ");

            // La validación de que existan el técnico y la ciudad la hace la
            // capa de Aplicación, no la consola.
            _servicioAppService.RegistrarServicio(dto);
            Console.WriteLine("Servicio registrado correctamente.");
        }

        // Muestra los códigos de servicio cargados (ayuda para el usuario).
        private void MostrarServiciosExistentes()
        {
            Console.WriteLine("Servicios cargados:");
            foreach (ServicioDetalleDto s in _servicioAppService.ListarServicios())
            {
                Console.WriteLine("  " + s.Codigo + " - " + s.Descripcion);
            }
        }

        // ============== MÉTODOS AUXILIARES DE ENTRADA ==============
        // Validan solo el FORMATO de lo que se tipea (que sea un número).
        // Las reglas de negocio NO van acá.

        private string PedirTexto(string mensaje)
        {
            Console.Write(mensaje);
            return LeerLinea() ?? "";
        }

        private int PedirEntero(string mensaje)
        {
            while (true)
            {
                Console.Write(mensaje);
                string entrada = LeerLinea();
                if (entrada == null)
                    throw new AplicacionException("No se ingresaron datos.");

                int numero;
                if (int.TryParse(entrada, out numero))
                    return numero;

                Console.WriteLine("Debe ingresar un número entero.");
            }
        }

        // Lee una línea y le saca los espacios de los costados.
        private string LeerLinea()
        {
            string linea = Console.ReadLine();
            return linea == null ? null : linea.Trim();
        }
    }
}
