﻿using System;
using System.Text;
using Mantenimiento.Aplicacion.Interfaces;
using Mantenimiento.Aplicacion.Servicios;
using Mantenimiento.Dominio.Interfaces;
using Mantenimiento.Infraestructura.Datos;
using Mantenimiento.Infraestructura.Repositorios;

namespace Mantenimiento.Presentacion
{
    // =====================================================================
    // PUNTO DE COMPOSICIÓN (Composition Root) - INYECCIÓN DE DEPENDENCIAS
    // ---------------------------------------------------------------------
    // La rúbrica pide: "dependencias resueltas en un ÚNICO punto de
    // composición". Ese punto es ESTE Main y es el ÚNICO lugar de todo el
    // programa donde se hace "new" de repositorios y servicios.
    //
    // Orden en que se arma todo (de adentro hacia afuera):
    //   1) Contexto en memoria (los datos de prueba).
    //   2) Repositorios (Infraestructura), reciben el contexto.
    //   3) Servicios de aplicación, reciben los repositorios como INTERFAZ.
    //   4) Menú de consola, recibe los servicios como INTERFAZ.
    //
    // Fijate que las variables están declaradas con el tipo de la INTERFAZ
    // (ITecnicoRepositorio, ITecnicoAppService...). Para cambiar una
    // implementación (memoria -> SQL) se cambia solo la línea del "new".
    //
    // ¿Por qué Presentación referencia a Infraestructura? Solo por este
    // archivo: alguien tiene que crear los objetos concretos. El MENÚ
    // (MenuConsola) no usa nada de Infraestructura ni del Dominio.
    // =====================================================================
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            // 1) "Base de datos" en memoria (una sola instancia compartida).
            ContextoEnMemoria contexto = new ContextoEnMemoria();

            // 2) Repositorios: implementaciones concretas guardadas como interfaz.
            ITecnicoRepositorio tecnicoRepositorio = new TecnicoRepositorioMemoria(contexto);
            IServicioRepositorio servicioRepositorio = new ServicioRepositorioMemoria(contexto);
            ICiudadRepositorio ciudadRepositorio = new CiudadRepositorioMemoria(contexto);

            // 3) Servicios de aplicación: se les INYECTAN los repositorios.
            ITecnicoAppService tecnicoAppService = new TecnicoAppService(tecnicoRepositorio);
            IServicioAppService servicioAppService =
                new ServicioAppService(servicioRepositorio, tecnicoRepositorio, ciudadRepositorio);

            // 4) Presentación: se le INYECTAN los servicios de aplicación.
            MenuConsola menu = new MenuConsola(tecnicoAppService, servicioAppService);
            menu.Ejecutar();
        }
    }
}
