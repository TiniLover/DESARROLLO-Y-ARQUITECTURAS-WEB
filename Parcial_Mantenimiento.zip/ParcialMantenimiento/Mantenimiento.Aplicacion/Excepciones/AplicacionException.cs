﻿using System;

namespace Mantenimiento.Aplicacion.Excepciones
{
    // =====================================================================
    // Excepción de la capa de Aplicación.
    // ---------------------------------------------------------------------
    // ¿Para qué otra excepción si ya está DominioException?
    // Para que la PRESENTACIÓN no tenga que conocer NADA del Dominio.
    // La Aplicación atrapa los errores del Dominio y los "traduce" a esta
    // excepción. Así la consola solo depende de la capa de Aplicación
    // (DTOs + interfaces + esta excepción), como pide Clean Architecture.
    // =====================================================================
    public class AplicacionException : Exception
    {
        public AplicacionException(string mensaje) : base(mensaje) { }
    }
}
