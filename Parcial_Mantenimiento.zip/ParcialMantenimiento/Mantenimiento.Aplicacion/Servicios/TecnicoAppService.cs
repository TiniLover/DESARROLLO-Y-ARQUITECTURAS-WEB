﻿using System.Collections.Generic;
using Mantenimiento.Aplicacion.DTOs;
using Mantenimiento.Aplicacion.Excepciones;
using Mantenimiento.Aplicacion.Interfaces;
using Mantenimiento.Aplicacion.Mapeos;
using Mantenimiento.Dominio.Entidades;
using Mantenimiento.Dominio.Excepciones;
using Mantenimiento.Dominio.Interfaces;

namespace Mantenimiento.Aplicacion.Servicios
{
    // =====================================================================
    // CAPA DE APLICACIÓN - CASOS DE USO DE TÉCNICOS
    // ---------------------------------------------------------------------
    // La capa de Aplicación ORQUESTA: recibe un DTO, lo convierte en
    // entidad, aplica las validaciones que involucran a más de un objeto
    // (por ejemplo "que el DNI no esté repetido") y usa el repositorio.
    //
    // INYECCIÓN DE DEPENDENCIAS POR CONSTRUCTOR:
    // Esta clase NECESITA un repositorio de técnicos, pero NO hace
    // "new TecnicoRepositorioMemoria()" adentro. Lo recibe ya creado en el
    // constructor, y lo recibe como INTERFAZ (ITecnicoRepositorio).
    // Ventajas:
    //   - No conoce Infraestructura (respeta Clean Architecture).
    //   - Se puede cambiar el repositorio sin tocar esta clase.
    //   - Quién crea los objetos se decide en un solo lugar (Program.cs).
    // =====================================================================
    public class TecnicoAppService : ITecnicoAppService
    {
        // "readonly": se asigna una sola vez en el constructor y no cambia.
        private readonly ITecnicoRepositorio _tecnicoRepositorio;

        public TecnicoAppService(ITecnicoRepositorio tecnicoRepositorio)
        {
            _tecnicoRepositorio = tecnicoRepositorio;
        }

        // ------------------------------------------------------------
        // FUNCIONALIDAD 2: Agregar un técnico
        // ------------------------------------------------------------
        public void AgregarTecnico(TecnicoDto dto)
        {
            // 1) DTO -> Entidad. Si faltan datos, el constructor de Tecnico
            //    lanza DominioException; la atrapamos y la "traducimos" a
            //    AplicacionException para que la consola no dependa del Dominio.
            Tecnico tecnico;
            try
            {
                tecnico = Mapeador.ATecnico(dto);
            }
            catch (DominioException ex)
            {
                throw new AplicacionException(ex.Message);
            }

            // 2) Regla que necesita consultar el repositorio: el DNI no se
            //    puede repetir. Esta validación va en Aplicación (y no en la
            //    entidad) porque la entidad sola no sabe qué técnicos existen.
            if (_tecnicoRepositorio.ObtenerPorDni(tecnico.Dni) != null)
                throw new AplicacionException("Ya existe un técnico con el DNI " + tecnico.Dni + ".");

            // 3) Guardar.
            _tecnicoRepositorio.Agregar(tecnico);
        }

        // ------------------------------------------------------------
        // FUNCIONALIDAD 3: Listar técnicos
        // ------------------------------------------------------------
        public List<TecnicoDto> ListarTecnicos()
        {
            // Se traen las entidades y se convierte cada una a DTO.
            // Hacia afuera solo salen DTOs.
            List<TecnicoDto> resultado = new List<TecnicoDto>();
            foreach (Tecnico tecnico in _tecnicoRepositorio.ObtenerTodos())
            {
                resultado.Add(Mapeador.ATecnicoDto(tecnico));
            }
            return resultado;
        }
    }
}
