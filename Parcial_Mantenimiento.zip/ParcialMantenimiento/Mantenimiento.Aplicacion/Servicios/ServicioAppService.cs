﻿using System.Collections.Generic;
using Mantenimiento.Aplicacion.DTOs;
using Mantenimiento.Aplicacion.Excepciones;
using Mantenimiento.Aplicacion.Interfaces;
using Mantenimiento.Aplicacion.Mapeos;
using Mantenimiento.Dominio.Entidades;
using Mantenimiento.Dominio.Excepciones;
using Mantenimiento.Dominio.Interfaces;

namespace Mantenimiento.Aplicacion.Servicios
{
    // =====================================================================
    // CAPA DE APLICACIÓN - CASOS DE USO DE SERVICIOS
    // ---------------------------------------------------------------------
    // (Ojo con los nombres: "Servicio" es la ENTIDAD del enunciado, y
    // "AppService" es la clase de la capa de aplicación. Por eso se llama
    // ServicioAppService, para no confundirlos.)
    //
    // Recibe TRES repositorios por constructor (inyección de dependencias),
    // porque para registrar un servicio tiene que validar que existan el
    // técnico y la ciudad.
    // =====================================================================
    public class ServicioAppService : IServicioAppService
    {
        private readonly IServicioRepositorio _servicioRepositorio;
        private readonly ITecnicoRepositorio _tecnicoRepositorio;
        private readonly ICiudadRepositorio _ciudadRepositorio;

        public ServicioAppService(IServicioRepositorio servicioRepositorio,
                                  ITecnicoRepositorio tecnicoRepositorio,
                                  ICiudadRepositorio ciudadRepositorio)
        {
            _servicioRepositorio = servicioRepositorio;
            _tecnicoRepositorio = tecnicoRepositorio;
            _ciudadRepositorio = ciudadRepositorio;
        }

        // ------------------------------------------------------------
        // FUNCIONALIDAD 1: Consultar un servicio por código
        // Muestra: datos del servicio + nombre del técnico + nombre ciudad
        // ------------------------------------------------------------
        public ServicioDetalleDto ConsultarPorCodigo(int codigo)
        {
            Servicio servicio = _servicioRepositorio.ObtenerPorCodigo(codigo);

            if (servicio == null)
                throw new AplicacionException("No existe un servicio con el código " + codigo + ".");

            // Entidad -> DTO plano (con NombreTecnico y NombreCiudad).
            return Mapeador.AServicioDetalleDto(servicio);
        }

        // ------------------------------------------------------------
        // FUNCIONALIDAD 4: Registrar un servicio
        // "validando que el técnico y la ciudad existan"
        // ------------------------------------------------------------
        public void RegistrarServicio(RegistrarServicioDto dto)
        {
            // 1) El código del servicio no se puede repetir.
            if (_servicioRepositorio.ObtenerPorCodigo(dto.Codigo) != null)
                throw new AplicacionException("Ya existe un servicio con el código " + dto.Codigo + ".");

            // 2) VALIDACIÓN PEDIDA: el técnico tiene que existir.
            Tecnico tecnico = _tecnicoRepositorio.ObtenerPorDni(dto.DniTecnico);
            if (tecnico == null)
                throw new AplicacionException("No existe un técnico con el DNI " + dto.DniTecnico + ".");

            // 3) VALIDACIÓN PEDIDA: la ciudad tiene que existir.
            Ciudad ciudad = _ciudadRepositorio.ObtenerPorCodigo(dto.CodigoCiudad);
            if (ciudad == null)
                throw new AplicacionException("No existe una ciudad con el código " + dto.CodigoCiudad + ".");

            // 4) DTO -> Entidad (el constructor valida descripción, etc.)
            //    y se guarda. Acá queda armada la relación:
            //    este servicio -> UN técnico y UNA ciudad.
            Servicio servicio;
            try
            {
                servicio = Mapeador.AServicio(dto, tecnico, ciudad);
            }
            catch (DominioException ex)
            {
                // Error de regla del Dominio -> se traduce para la Presentación.
                throw new AplicacionException(ex.Message);
            }
            _servicioRepositorio.Agregar(servicio);
        }

        // Auxiliar: todos los servicios convertidos a DTO.
        public List<ServicioDetalleDto> ListarServicios()
        {
            List<ServicioDetalleDto> resultado = new List<ServicioDetalleDto>();
            foreach (Servicio servicio in _servicioRepositorio.ObtenerTodos())
            {
                resultado.Add(Mapeador.AServicioDetalleDto(servicio));
            }
            return resultado;
        }

        // Auxiliar para que el usuario vea qué códigos de ciudad existen.
        public List<CiudadDto> ListarCiudades()
        {
            List<CiudadDto> resultado = new List<CiudadDto>();
            foreach (Ciudad ciudad in _ciudadRepositorio.ObtenerTodas())
            {
                resultado.Add(Mapeador.ACiudadDto(ciudad));
            }
            return resultado;
        }
    }
}
