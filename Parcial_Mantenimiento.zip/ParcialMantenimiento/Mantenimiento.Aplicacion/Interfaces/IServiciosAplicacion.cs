﻿using System.Collections.Generic;
using Mantenimiento.Aplicacion.DTOs;

namespace Mantenimiento.Aplicacion.Interfaces
{
    // =====================================================================
    // INTERFACES DE LA CAPA DE APLICACIÓN (lo que la Presentación puede usar)
    // ---------------------------------------------------------------------
    // La consola depende de ESTAS interfaces, no de las clases concretas.
    // Fijate que todos los métodos reciben y devuelven DTOs: ninguna
    // entidad del Dominio "se escapa" hacia la Presentación.
    //
    // Cada método = una funcionalidad del enunciado (un caso de uso).
    // =====================================================================

    public interface ITecnicoAppService
    {
        // Funcionalidad 2 (obligatoria): Agregar un técnico.
        void AgregarTecnico(TecnicoDto dto);

        // Funcionalidad 3 (opcional): Listar técnicos.
        List<TecnicoDto> ListarTecnicos();
    }

    public interface IServicioAppService
    {
        // Funcionalidad 1 (obligatoria): Consultar un servicio por código.
        ServicioDetalleDto ConsultarPorCodigo(int codigo);

        // Funcionalidad 4 (opcional): Registrar un servicio validando que
        // existan el técnico y la ciudad.
        void RegistrarServicio(RegistrarServicioDto dto);

        // Auxiliar: lista de servicios cargados, para que el usuario vea qué
        // códigos existen antes de consultar o registrar.
        List<ServicioDetalleDto> ListarServicios();

        // Auxiliar: lista de ciudades para mostrarle al usuario los códigos.
        List<CiudadDto> ListarCiudades();
    }
}
