﻿using Mantenimiento.Aplicacion.DTOs;
using Mantenimiento.Dominio.Entidades;

namespace Mantenimiento.Aplicacion.Mapeos
{
    // =====================================================================
    // MAPEO ENTIDAD <-> DTO  (la rúbrica lo pide explícitamente)
    // ---------------------------------------------------------------------
    // Todas las conversiones están juntas en UNA clase, así si cambia una
    // entidad o un DTO, se corrige en un solo lugar.
    //
    // ¿Por qué está en Aplicación? Porque es la única capa que conoce las
    // DOS cosas: las entidades (Dominio) y los DTOs (los define ella misma).
    // La Presentación nunca ve una entidad: recibe siempre el DTO ya armado.
    //
    // Es "static" porque no guarda estado: solo transforma datos.
    // (En proyectos grandes se usa una librería como AutoMapper; acá se hace
    // a mano para que se vea claramente qué se copia.)
    // =====================================================================
    public static class Mapeador
    {
        // ---------- ENTIDAD -> DTO (para MOSTRAR datos) ----------

        public static TecnicoDto ATecnicoDto(Tecnico tecnico)
        {
            return new TecnicoDto
            {
                Dni = tecnico.Dni,
                Nombre = tecnico.Nombre,
                Telefono = tecnico.Telefono,
                Direccion = tecnico.Direccion,
                Especialidad = tecnico.Especialidad
            };
        }

        // Acá se "aplana" la información: del técnico y de la ciudad solo se
        // copia el NOMBRE, que es lo que pide la funcionalidad 1.
        public static ServicioDetalleDto AServicioDetalleDto(Servicio servicio)
        {
            return new ServicioDetalleDto
            {
                Codigo = servicio.Codigo,
                Descripcion = servicio.Descripcion,
                DireccionLugar = servicio.DireccionLugar,
                NombreTecnico = servicio.Tecnico.Nombre,
                NombreCiudad = servicio.Ciudad.Nombre
            };
        }

        public static CiudadDto ACiudadDto(Ciudad ciudad)
        {
            return new CiudadDto
            {
                Codigo = ciudad.Codigo,
                Nombre = ciudad.Nombre
            };
        }

        // ---------- DTO -> ENTIDAD (para GUARDAR datos) ----------

        // Al crear la entidad con "new Tecnico(...)" se ejecutan las
        // validaciones del constructor: si algún dato está mal, lanza
        // DominioException y no se crea nada.
        public static Tecnico ATecnico(TecnicoDto dto)
        {
            return new Tecnico(dto.Dni, dto.Nombre, dto.Telefono, dto.Direccion, dto.Especialidad);
        }

        // El servicio necesita los OBJETOS técnico y ciudad (no los ids),
        // por eso se reciben como parámetro: los busca antes el caso de uso.
        public static Servicio AServicio(RegistrarServicioDto dto, Tecnico tecnico, Ciudad ciudad)
        {
            return new Servicio(dto.Codigo, dto.Descripcion, dto.DireccionLugar, tecnico, ciudad);
        }
    }
}
