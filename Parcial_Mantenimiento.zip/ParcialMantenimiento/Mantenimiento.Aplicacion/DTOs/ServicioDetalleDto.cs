﻿namespace Mantenimiento.Aplicacion.DTOs
{
    // =====================================================================
    // DTO de SALIDA para la funcionalidad 1: "Consultar servicio por código".
    // ---------------------------------------------------------------------
    // El enunciado pide mostrar:
    //   - los datos del servicio   -> Codigo, Descripcion, DireccionLugar
    //   - el nombre del técnico    -> NombreTecnico
    //   - el nombre de la ciudad   -> NombreCiudad
    //
    // Fijate que el DTO es "plano": en vez de traer el objeto Tecnico entero
    // trae solo el NOMBRE (un string). Así la consola recibe exactamente lo
    // que tiene que mostrar y no toca ninguna entidad del dominio.
    // =====================================================================
    public class ServicioDetalleDto
    {
        public int Codigo { get; set; }
        public string Descripcion { get; set; }
        public string DireccionLugar { get; set; }
        public string NombreTecnico { get; set; }
        public string NombreCiudad { get; set; }
    }
}
