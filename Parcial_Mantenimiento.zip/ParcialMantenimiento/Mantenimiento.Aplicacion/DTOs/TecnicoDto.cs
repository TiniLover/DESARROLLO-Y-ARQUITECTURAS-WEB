﻿namespace Mantenimiento.Aplicacion.DTOs
{
    // =====================================================================
    // DTO (Data Transfer Object) - TecnicoDto
    // ---------------------------------------------------------------------
    // ¿Qué es un DTO? Una clase "tonta": solo propiedades, sin lógica ni
    // validaciones. Sirve para LLEVAR DATOS entre la Presentación y la
    // Aplicación.
    //
    // ¿Por qué no usar directamente la entidad Tecnico en la consola?
    //   1) La presentación NO debe conocer el Dominio (lo pide la rúbrica).
    //   2) Protege a la entidad: la consola no puede saltearse las
    //      validaciones del constructor ni modificar datos a mano.
    //   3) Podemos mandar solo los datos que la pantalla necesita.
    //
    // Se usa para las dos funcionalidades de técnicos:
    //   - Alta de técnico (la consola lo llena y lo manda).
    //   - Listado de técnicos (la aplicación lo llena y lo devuelve).
    // Por eso las propiedades tienen get y set públicos.
    // =====================================================================
    public class TecnicoDto
    {
        public string Dni { get; set; }
        public string Nombre { get; set; }
        public string Telefono { get; set; }
        public string Direccion { get; set; }
        public string Especialidad { get; set; }
    }
}
