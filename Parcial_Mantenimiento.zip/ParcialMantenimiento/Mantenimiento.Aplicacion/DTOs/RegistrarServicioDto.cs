﻿namespace Mantenimiento.Aplicacion.DTOs
{
    // =====================================================================
    // DTO de ENTRADA para la funcionalidad 4: "Registrar un servicio".
    // ---------------------------------------------------------------------
    // La consola no tiene objetos Tecnico ni Ciudad (no conoce el Dominio),
    // así que manda solo los IDENTIFICADORES: DNI del técnico y código de la
    // ciudad. La capa de Aplicación se encarga de buscarlos y validar que
    // existan (eso es justamente lo que pide el enunciado).
    // =====================================================================
    public class RegistrarServicioDto
    {
        public int Codigo { get; set; }
        public string Descripcion { get; set; }
        public string DireccionLugar { get; set; }
        public string DniTecnico { get; set; }
        public int CodigoCiudad { get; set; }
    }
}
