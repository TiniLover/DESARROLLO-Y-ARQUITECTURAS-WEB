﻿namespace Mantenimiento.Aplicacion.DTOs
{
    // =====================================================================
    // DTO de Ciudad. Se usa para mostrarle al usuario las ciudades
    // disponibles cuando registra un servicio (así sabe qué código poner).
    // =====================================================================
    public class CiudadDto
    {
        public int Codigo { get; set; }
        public string Nombre { get; set; }
    }
}
