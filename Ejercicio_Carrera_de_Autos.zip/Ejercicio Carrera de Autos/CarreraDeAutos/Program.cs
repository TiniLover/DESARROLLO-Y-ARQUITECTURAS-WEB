﻿using System;
using System.Text;

namespace CarreraDeAutos
{
    // =====================================================================
    // PROGRAMA PRINCIPAL
    // El piloto elige el circuito y se llama al MÉTODO PLANTILLA Correr().
    // El flujo es siempre el mismo para cualquier circuito.
    // =====================================================================
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            Circuito[] circuitos =
            {
                new CircuitoMontania(),
                new CircuitoUrbano()
            };

            while (true)
            {
                Console.WriteLine();
                Console.WriteLine("===== ELEGÍ EL CIRCUITO =====");
                for (int i = 0; i < circuitos.Length; i++)
                {
                    Console.WriteLine($"{i + 1}. {circuitos[i].Nombre}");
                }
                Console.WriteLine("0. Salir");
                Console.Write("Opción: ");

                string entrada = Console.ReadLine() ?? "";

                if (entrada == "0")
                {
                    Console.WriteLine("¡Hasta la próxima!");
                    break;
                }

                if (int.TryParse(entrada, out int opcion) && opcion >= 1 && opcion <= circuitos.Length)
                {
                    // Template Method: el mismo llamado para cualquier circuito.
                    circuitos[opcion - 1].Correr();
                }
                else
                {
                    Console.WriteLine("Opción inválida.");
                }
            }
        }
    }
}
