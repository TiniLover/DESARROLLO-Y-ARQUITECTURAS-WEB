﻿using System;

namespace CarreraDeAutos
{
    // Subclase concreta: completa solo los dos pasos propios
    // (presentación y acción), en el mismo orden que el método plantilla.
    public class CircuitoUrbano : Circuito
    {
        public override string Nombre => "Circuito Urbano";

        protected override string[] Acciones => new[]
        {
            "Tomar el atajo por el túnel",
            "Seguir por la avenida principal"
        };

        // PASO 2
        protected override void MostrarPresentacion()
        {
            Console.WriteLine("Calles angostas entre edificios y miles de espectadores en las veredas.");
        }

        // PASO 4
        protected override void EjecutarAccion(int eleccion)
        {
            switch (eleccion)
            {
                case 1:
                    Console.WriteLine("Doblás y entrás al túnel...");
                    Console.WriteLine("Resultado: sale del túnel adelante de todos y gana la carrera.");
                    break;
                case 2:
                    Console.WriteLine("Seguís derecho por la avenida principal...");
                    Console.WriteLine("Resultado: queda atrapado detrás de otro auto y termina tercero.");
                    break;
            }
        }
    }
}
