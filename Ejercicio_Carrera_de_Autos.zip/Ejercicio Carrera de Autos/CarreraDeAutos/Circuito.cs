﻿using System;

namespace CarreraDeAutos
{
    // =====================================================================
    // PATRÓN: TEMPLATE METHOD
    // ---------------------------------------------------------------------
    // Justificación: todos los circuitos siguen el mismo flujo en el mismo
    // orden (bienvenida, presentación, validación, acción y cierre). Solo
    // cambian la presentación y la acción según el circuito. La clase
    // abstracta define el flujo en el método plantilla Correr(); los pasos
    // comunes se implementan una sola vez y los que varían quedan
    // abstractos para que cada circuito los complete.
    //
    // TABLA DE PASOS (sale directo del enunciado):
    //   Paso | ¿Común o propio?                    | Método               | Tipo
    //   1    | común                               | MostrarBienvenida    | private
    //   2    | propio ("su propia presentación")   | MostrarPresentacion  | abstract
    //   3    | común                               | ValidarEleccion      | private
    //   4    | propio ("su propio comportamiento") | EjecutarAccion       | abstract
    //   5    | común                               | MostrarCierre        | private
    //
    // DETALLE DEL ORDEN: las opciones del piloto se muestran DENTRO de
    // ValidarEleccion (paso 3), así aparecen después de la presentación del
    // circuito (paso 2) y el "for" se escribe una sola vez, acá en la base.
    // =====================================================================
    public abstract class Circuito
    {
        // MÉTODO PLANTILLA: 5 pasos numerados = 5 llamadas, en ese orden.
        public void Correr()
        {
            MostrarBienvenida();              // 1. común   -> private
            MostrarPresentacion();            // 2. propio  -> abstract
            int eleccion = ValidarEleccion(); // 3. común   -> private
            EjecutarAccion(eleccion);         // 4. propio  -> abstract
            MostrarCierre();                  // 5. común   -> private
        }

        // ------------- LO QUE COMPLETA CADA CIRCUITO (abstract) -------------
        public abstract string Nombre { get; }
        protected abstract string[] Acciones { get; }

        // PASO 2: cada circuito tiene su propia presentación.
        protected abstract void MostrarPresentacion();

        // PASO 4: cada circuito tiene su propio comportamiento.
        protected abstract void EjecutarAccion(int eleccion);

        // ------------- PASOS COMUNES (private) -------------

        // PASO 1
        private void MostrarBienvenida()
        {
            Console.WriteLine();
            Console.WriteLine("Bienvenido al Gran Premio. Los motores ya están encendidos.");
        }

        // PASO 3: muestra las opciones (común a todos) y valida la elección.
        private int ValidarEleccion()
        {
            Console.WriteLine("¿Qué querés hacer?");
            for (int i = 0; i < Acciones.Length; i++)
            {
                Console.WriteLine($"  {i + 1}. {Acciones[i]}");
            }

            while (true)
            {
                Console.Write("Tu elección: ");
                string entrada = Console.ReadLine() ?? "";
                if (int.TryParse(entrada, out int eleccion) && eleccion >= 1 && eleccion <= Acciones.Length)
                {
                    Console.WriteLine($"Elegiste: {Acciones[eleccion - 1]}");
                    return eleccion;
                }
                Console.WriteLine($"Opción inválida. Ingresá un número del 1 al {Acciones.Length}.");
            }
        }

        // PASO 5
        private void MostrarCierre()
        {
            Console.WriteLine("-----------------------------------------");
            Console.WriteLine("Se agita la bandera a cuadros. ¡Fin de la carrera!");
        }
    }
}
