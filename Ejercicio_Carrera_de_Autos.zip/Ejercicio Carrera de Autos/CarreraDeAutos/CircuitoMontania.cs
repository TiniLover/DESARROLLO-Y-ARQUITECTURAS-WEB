﻿using System;

namespace CarreraDeAutos
{
    // Subclase concreta: completa solo los dos pasos propios
    // (presentación y acción), en el mismo orden que el método plantilla.
    public class CircuitoMontania : Circuito
    {
        public override string Nombre => "Circuito de Montaña";

        protected override string[] Acciones => new[]
        {
            "Acelerar en la curva",
            "Frenar antes de la curva"
        };

        // PASO 2
        protected override void MostrarPresentacion()
        {
            Console.WriteLine("Curvas cerradas, precipicios y niebla: el circuito más peligroso del campeonato.");
        }

        // PASO 4
        protected override void EjecutarAccion(int eleccion)
        {
            switch (eleccion)
            {
                case 1:
                    Console.WriteLine("Acelerás a fondo en la curva...");
                    Console.WriteLine("Resultado: el auto derrapa pero el piloto lo controla y pasa al primer puesto.");
                    break;
                case 2:
                    Console.WriteLine("Frenás antes de entrar a la curva...");
                    Console.WriteLine("Resultado: pierde dos posiciones pero termina la carrera sin daños.");
                    break;
            }
        }
    }
}
