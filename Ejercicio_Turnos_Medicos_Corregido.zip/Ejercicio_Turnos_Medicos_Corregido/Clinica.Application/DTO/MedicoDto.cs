﻿namespace Clinica.Application.DTO
{
    // =====================================================================
    // DTO de Médico (alta y listado).
    // ---------------------------------------------------------------------
    // CORRECCIÓN IMPORTANTE: tenías las propiedades con "private set".
    // En un DTO eso NO funciona: ni el Mapeador ni la consola pueden
    // cargarle datos (error "el descriptor de acceso set no es accesible").
    // En las ENTIDADES va "private set" (para protegerlas); en los DTOs va
    // "set" público, porque son solo "cajitas" para transportar datos.
    // También se sacó el DNI (no está en el enunciado).
    // =====================================================================
    public class MedicoDto
    {
        public string Matricula { get; set; }
        public string Nombre { get; set; }
        public string Telefono { get; set; }
        public string Email { get; set; }
        public string Especialidad { get; set; }
    }
}
