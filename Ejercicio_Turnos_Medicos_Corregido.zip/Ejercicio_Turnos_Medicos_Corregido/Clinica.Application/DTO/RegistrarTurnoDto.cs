﻿using System;

namespace Clinica.Application.DTO
{
    // =====================================================================
    // DTO de ENTRADA de la funcionalidad 4: "Registrar un turno".
    // ---------------------------------------------------------------------
    // CORRECCIÓN: faltaban los IDENTIFICADORES del médico y de la sede.
    // Sin ellos la aplicación no puede "validar que existan".
    // La consola manda la MATRÍCULA y el CÓDIGO de sede (no objetos).
    // =====================================================================
    public class RegistrarTurnoDto
    {
        public int NumTurno { get; set; }
        public string NombrePaciente { get; set; }
        public string MotivoConsulta { get; set; }
        public DateTime Fecha { get; set; }
        public string MatriculaMedico { get; set; }
        public int CodigoSede { get; set; }
    }
}
