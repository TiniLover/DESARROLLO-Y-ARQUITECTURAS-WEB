﻿namespace Clinica.Application.DTO
{
    // DTO de Sede, para mostrar las sedes al registrar un turno.
    // CORRECCIÓN: "set" público (antes era private set).
    public class SedeDto
    {
        public int Codigo { get; set; }
        public string Nombre { get; set; }
        public string Direccion { get; set; }
    }
}
