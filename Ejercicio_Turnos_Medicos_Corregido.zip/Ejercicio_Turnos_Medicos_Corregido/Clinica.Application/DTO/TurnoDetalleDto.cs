﻿using System;

namespace Clinica.Application.DTO
{
    // =====================================================================
    // DTO de SALIDA de la funcionalidad 1: "Consultar turno por número".
    // ---------------------------------------------------------------------
    // El enunciado pide mostrar: datos del turno + NOMBRE del médico +
    // su ESPECIALIDAD + NOMBRE de la sede.
    // CORRECCIONES:
    //  1) Faltaban NombreMedico, EspecialidadMedico y NombreSede (justamente
    //     lo que pide la consigna).
    //  2) "set" público.
    //  3) Tenía "using Clinica.Domain.Entidades": un DTO NO debe conocer las
    //     entidades. Se sacó.
    // =====================================================================
    public class TurnoDetalleDto
    {
        public int NumTurno { get; set; }
        public string NombrePaciente { get; set; }
        public string MotivoConsulta { get; set; }
        public DateTime Fecha { get; set; }
        public string NombreMedico { get; set; }
        public string EspecialidadMedico { get; set; }
        public string NombreSede { get; set; }
    }
}
