﻿using Clinica.Application.DTO;
using Clinica.Domain.Entidades;

namespace Clinica.Application.Mapeos
{
    // =====================================================================
    // MAPEO ENTIDAD <-> DTO
    // ---------------------------------------------------------------------
    // CORRECCIONES:
    //  1) AMedicoDto no tenía "return new MedicoDto { ... }": tenía las
    //     asignaciones sueltas -> error de sintaxis.
    //  2) Usabas "TurnoDetalleDto" y la clase se llamaba "TurnoDetalleDTO".
    //     C# distingue MAYÚSCULAS: tienen que escribirse IGUAL.
    //  3) ATurnoDetalleDto no copiaba el médico ni la sede -> ahora copia
    //     NombreMedico, EspecialidadMedico y NombreSede.
    //  4) Faltaban ATurno y AMedico (DTO -> Entidad), que los usan los
    //     servicios para GUARDAR.
    //  5) La clase pasa a "static" (solo tiene métodos static).
    // =====================================================================
    public static class Mapeador
    {
        // ---------- ENTIDAD -> DTO ----------
        public static MedicoDto AMedicoDto(Medico medico)
        {
            return new MedicoDto
            {
                Matricula = medico.Matricula,
                Nombre = medico.Nombre,
                Telefono = medico.Telefono,
                Email = medico.Email,
                Especialidad = medico.Especialidad
            };
        }

        public static TurnoDetalleDto ATurnoDetalleDto(Turno turno)
        {
            return new TurnoDetalleDto
            {
                NumTurno = turno.NumTurno,
                NombrePaciente = turno.NombrePaciente,
                MotivoConsulta = turno.MotivoConsulta,
                Fecha = turno.Fecha,
                // Se "aplana": del médico y la sede solo se copia lo que
                // pide la consigna.
                NombreMedico = turno.Medico.Nombre,
                EspecialidadMedico = turno.Medico.Especialidad,
                NombreSede = turno.Sede.Nombre
            };
        }

        public static SedeDto ASedeDto(Sede sede)
        {
            return new SedeDto
            {
                Codigo = sede.Codigo,
                Nombre = sede.Nombre,
                Direccion = sede.Direccion
            };
        }

        // ---------- DTO -> ENTIDAD ----------
        // El constructor de la entidad valida (email con @, etc.).
        public static Medico AMedico(MedicoDto dto)
        {
            return new Medico(dto.Matricula, dto.Nombre, dto.Telefono, dto.Email, dto.Especialidad);
        }

        // El turno necesita los OBJETOS médico y sede, que busca antes el
        // servicio de aplicación.
        public static Turno ATurno(RegistrarTurnoDto dto, Medico medico, Sede sede)
        {
            return new Turno(dto.NumTurno, dto.NombrePaciente, dto.MotivoConsulta, dto.Fecha, medico, sede);
        }
    }
}
