﻿using System.Collections.Generic;
using Clinica.Application.DTO;
using Clinica.Application.Excepciones;
using Clinica.Application.Interfaces;
using Clinica.Application.Mapeos;
using Clinica.Domain.Entidades;
using Clinica.Domain.Excepciones;
using Clinica.Domain.Interfaces;

namespace Clinica.Application.Servicios
{
    // =====================================================================
    // CASOS DE USO DE TURNOS
    // ---------------------------------------------------------------------
    // CORRECCIONES respecto de tu TurnoAPPService:
    //  1) No implementaba ninguna interfaz -> ahora ": ITurnoAppService".
    //  2) Faltaban los "using" de Domain.Interfaces y Domain.Excepciones
    //     (por eso no encontraba ITurnoRepositorio ni DominioException).
    //  3) LLAVES: el método RegistrarTurno se cerraba con "}" ANTES de
    //     crear y guardar el turno. Ese código quedaba suelto fuera de un
    //     método -> decenas de errores en cascada. Ahora está todo adentro.
    //  4) El método de sedes no tenía encabezado ("public List<SedeDto>
    //     ListarSedes()"): había un bloque { } suelto.
    //  5) Se buscaba al médico por DNI -> ahora por MATRÍCULA.
    //  6) Se usaba dto.Numero / dto.DniMedico, que no existían en el DTO.
    // =====================================================================
    public class TurnoAppService : ITurnoAppService
    {
        private readonly ITurnoRepositorio _turnoRepositorio;
        private readonly IMedicoRepositorio _medicoRepositorio;
        private readonly ISedeRepositorio _sedeRepositorio;

        public TurnoAppService(ITurnoRepositorio turnoRepositorio,
                               IMedicoRepositorio medicoRepositorio,
                               ISedeRepositorio sedeRepositorio)
        {
            _turnoRepositorio = turnoRepositorio;
            _medicoRepositorio = medicoRepositorio;
            _sedeRepositorio = sedeRepositorio;
        }

        // FUNCIONALIDAD 1: Consultar turno por número
        public TurnoDetalleDto ConsultarPorNumero(int numero)
        {
            Turno turno = _turnoRepositorio.ObtenerPorNumero(numero);
            if (turno == null)
                throw new AplicacionException("No existe un turno con el número " + numero + ".");

            return Mapeador.ATurnoDetalleDto(turno);
        }

        // FUNCIONALIDAD 4: Registrar turno validando médico y sede
        public void RegistrarTurno(RegistrarTurnoDto dto)
        {
            // 1) El número de turno no se puede repetir.
            if (_turnoRepositorio.ObtenerPorNumero(dto.NumTurno) != null)
                throw new AplicacionException("Ya existe un turno con el número " + dto.NumTurno + ".");

            // 2) VALIDACIÓN PEDIDA: el médico tiene que existir.
            Medico medico = _medicoRepositorio.ObtenerPorMatricula(dto.MatriculaMedico);
            if (medico == null)
                throw new AplicacionException("No existe un médico con la matrícula " + dto.MatriculaMedico + ".");

            // 3) VALIDACIÓN PEDIDA: la sede tiene que existir.
            Sede sede = _sedeRepositorio.ObtenerPorCodigo(dto.CodigoSede);
            if (sede == null)
                throw new AplicacionException("No existe una sede con el código " + dto.CodigoSede + ".");

            // 4) DTO -> Entidad y guardar (TODO dentro del mismo método).
            Turno turno;
            try
            {
                turno = Mapeador.ATurno(dto, medico, sede);
            }
            catch (DominioException ex)
            {
                throw new AplicacionException(ex.Message);
            }
            _turnoRepositorio.Agregar(turno);
        }

        // Auxiliar: lista de turnos (para mostrar los números existentes).
        public List<TurnoDetalleDto> ListarTurnos()
        {
            List<TurnoDetalleDto> resultado = new List<TurnoDetalleDto>();
            foreach (Turno turno in _turnoRepositorio.ObtenerTodos())
            {
                resultado.Add(Mapeador.ATurnoDetalleDto(turno));
            }
            return resultado;
        }

        // Auxiliar: lista de sedes (antes le faltaba esta línea de encabezado).
        public List<SedeDto> ListarSedes()
        {
            List<SedeDto> resultado = new List<SedeDto>();
            foreach (Sede sede in _sedeRepositorio.ObtenerTodas())
            {
                resultado.Add(Mapeador.ASedeDto(sede));
            }
            return resultado;
        }
    }
}
