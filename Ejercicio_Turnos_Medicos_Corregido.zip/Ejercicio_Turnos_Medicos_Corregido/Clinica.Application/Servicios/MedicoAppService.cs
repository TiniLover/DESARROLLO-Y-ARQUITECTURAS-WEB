﻿using System.Collections.Generic;
using Clinica.Application.DTO;
using Clinica.Application.Excepciones;
using Clinica.Application.Interfaces;
using Clinica.Application.Mapeos;
using Clinica.Domain.Entidades;
using Clinica.Domain.Excepciones;
using Clinica.Domain.Interfaces;

namespace Clinica.Application.Servicios
{
    // =====================================================================
    // CASOS DE USO DE MÉDICOS
    // ---------------------------------------------------------------------
    // Este archivo te llegó VACÍO (0 bytes) dentro del .rar, así que se
    // armó de nuevo siguiendo el TecnicoAppService del parcial.
    // Recibe el repositorio por constructor (inyección de dependencias).
    // =====================================================================
    public class MedicoAppService : IMedicoAppService
    {
        private readonly IMedicoRepositorio _medicoRepositorio;

        public MedicoAppService(IMedicoRepositorio medicoRepositorio)
        {
            _medicoRepositorio = medicoRepositorio;
        }

        // FUNCIONALIDAD 2: Agregar un médico
        public void AgregarMedico(MedicoDto dto)
        {
            // 1) DTO -> Entidad (valida datos obligatorios y el "@").
            Medico medico;
            try
            {
                medico = Mapeador.AMedico(dto);
            }
            catch (DominioException ex)
            {
                throw new AplicacionException(ex.Message);
            }

            // 2) REGLA DEL ENUNCIADO: "la matrícula no se puede repetir".
            //    Va en Aplicación porque necesita consultar el repositorio.
            if (_medicoRepositorio.ObtenerPorMatricula(medico.Matricula) != null)
                throw new AplicacionException("Ya existe un médico con la matrícula " + medico.Matricula + ".");

            // 3) Guardar.
            _medicoRepositorio.Agregar(medico);
        }

        // FUNCIONALIDAD 3: Listar médicos
        public List<MedicoDto> ListarMedicos()
        {
            List<MedicoDto> resultado = new List<MedicoDto>();
            foreach (Medico medico in _medicoRepositorio.ObtenerTodos())
            {
                resultado.Add(Mapeador.AMedicoDto(medico));
            }
            return resultado;
        }
    }
}
