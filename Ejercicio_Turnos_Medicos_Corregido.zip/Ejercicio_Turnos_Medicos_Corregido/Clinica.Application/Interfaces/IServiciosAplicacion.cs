﻿using System.Collections.Generic;
using Clinica.Application.DTO;

namespace Clinica.Application.Interfaces
{
    // =====================================================================
    // INTERFACES DE APLICACIÓN (lo que usa la consola).
    // ---------------------------------------------------------------------
    // CORRECCIONES:
    //  1) "IMedicoAplicacion" estaba declarada como "class" -> tiene que ser
    //     "interface". Una clase con métodos sin cuerpo no compila.
    //  2) Los nombres no coincidían con los que usabas en Program y en el
    //     menú (IMedicoAppService / ITurnoAppService). Se unificaron.
    //  3) Los métodos de turnos todavía se llamaban "...Servicio" (copiado
    //     del ejercicio de mantenimiento). Ahora dicen "Turno".
    // =====================================================================
    public interface IMedicoAppService
    {
        void AgregarMedico(MedicoDto dto);        // Funcionalidad 2
        List<MedicoDto> ListarMedicos();          // Funcionalidad 3
    }

    public interface ITurnoAppService
    {
        TurnoDetalleDto ConsultarPorNumero(int numero); // Funcionalidad 1
        void RegistrarTurno(RegistrarTurnoDto dto);      // Funcionalidad 4
        List<TurnoDetalleDto> ListarTurnos();            // auxiliar
        List<SedeDto> ListarSedes();                     // auxiliar
    }
}
