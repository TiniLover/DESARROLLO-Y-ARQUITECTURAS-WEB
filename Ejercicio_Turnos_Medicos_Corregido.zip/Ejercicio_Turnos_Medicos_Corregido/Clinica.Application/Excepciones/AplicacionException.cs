﻿using System;

namespace Clinica.Application.Excepciones
{
    // =====================================================================
    // CORRECCIÓN: la clase se llamaba "AplicationException" (sin la c),
    // pero en los servicios y el menú usabas "AplicacionException".
    // El nombre tiene que ser EXACTAMENTE el mismo en todos lados.
    // (Además, "ApplicationException" ya existe en .NET; conviene el
    // nombre en castellano para no confundirse.)
    // =====================================================================
    public class AplicacionException : Exception
    {
        public AplicacionException(string mensaje) : base(mensaje) { }
    }
}
