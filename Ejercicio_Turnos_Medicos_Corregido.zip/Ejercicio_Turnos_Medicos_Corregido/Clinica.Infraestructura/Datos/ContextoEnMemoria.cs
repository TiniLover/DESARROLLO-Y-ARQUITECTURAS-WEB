﻿using System;
using System.Collections.Generic;
using Clinica.Domain.Entidades;

namespace Clinica.Infraestructura.Datos
{
    // =====================================================================
    // "BASE DE DATOS" EN MEMORIA CON DATOS DE PRUEBA
    // ---------------------------------------------------------------------
    // CORRECCIONES:
    //  1) Los datos de prueba eran los del ejercicio de MANTENIMIENTO
    //     (Electricidad, Plomería, "Reparación de tablero"...) y además con
    //     la cantidad de parámetros equivocada:
    //       - new Sede(1, "Córdoba")  -> a la sede le faltaba la DIRECCIÓN.
    //       - new Médico(...) con 5 datos -> el constructor pedía 6.
    //       - new Turno(...) sin fecha ni paciente correctos.
    //     Ahora son datos de una clínica y respetan cada constructor.
    //  2) "Turno.Add(...)" -> Turno es la CLASE; hay que agregar a la LISTA:
    //     Turnos.Add(...).
    //  3) La lista se llamaba "Servicios" (copiada) -> "Turnos".
    //  4) "médicos" y "sedes" en minúscula y con tilde -> Medicos, Sedes.
    // =====================================================================
    public class ContextoEnMemoria
    {
        public List<Medico> Medicos { get; private set; }
        public List<Sede> Sedes { get; private set; }
        public List<Turno> Turnos { get; private set; }

        public ContextoEnMemoria()
        {
            Medicos = new List<Medico>();
            Sedes = new List<Sede>();
            Turnos = new List<Turno>();
            CargarDatosDePrueba();
        }

        private void CargarDatosDePrueba()
        {
            // ---- Sedes (código, nombre, dirección) ----
            Sede centro = new Sede(1, "Sede Centro", "Av. Corrientes 1500");
            Sede norte = new Sede(2, "Sede Norte", "Av. Cabildo 2300");
            Sede oeste = new Sede(3, "Sede Oeste", "Av. Rivadavia 9800");
            Sedes.AddRange(new[] { centro, norte, oeste });

            // ---- Médicos (matrícula, nombre, teléfono, email, especialidad) ----
            Medico perez = new Medico("MN1001", "Laura Pérez", "11-4444-5555", "lperez@clinica.com", "Cardiología");
            Medico gomez = new Medico("MN1002", "Martín Gómez", "11-5555-6666", "mgomez@clinica.com", "Pediatría");
            Medico diaz = new Medico("MN1003", "Sofía Díaz", "11-6666-7777", "sdiaz@clinica.com", "Traumatología");
            Medicos.AddRange(new[] { perez, gomez, diaz });

            // ---- Turnos (número, paciente, motivo, fecha, médico, sede) ----
            // Laura Pérez atiende 2 turnos y Sede Centro tiene 2 turnos:
            // se ven las relaciones "uno a muchos" del enunciado.
            Turnos.Add(new Turno(1, "Ana López", "Control de presión", new DateTime(2026, 11, 3, 9, 0, 0), perez, centro));
            Turnos.Add(new Turno(2, "Pedro Ruiz", "Dolor de pecho", new DateTime(2026, 11, 3, 10, 30, 0), perez, centro));
            Turnos.Add(new Turno(3, "Tomás Silva", "Control de crecimiento", new DateTime(2026, 11, 4, 15, 0, 0), gomez, norte));
            Turnos.Add(new Turno(4, "Julia Méndez", "Esguince de tobillo", new DateTime(2026, 11, 5, 11, 0, 0), diaz, oeste));
        }
    }
}
