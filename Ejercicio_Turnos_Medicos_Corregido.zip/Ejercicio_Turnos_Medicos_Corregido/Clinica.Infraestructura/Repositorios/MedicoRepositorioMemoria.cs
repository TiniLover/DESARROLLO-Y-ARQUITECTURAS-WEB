﻿using System.Collections.Generic;
using Clinica.Domain.Entidades;
using Clinica.Domain.Interfaces;
using Clinica.Infraestructura.Datos;

namespace Clinica.Infraestructura.Repositorios
{
    // =====================================================================
    // CORRECCIONES (válidas para los 3 repositorios):
    //  1) Tenías una clase ADENTRO de otra:
    //        public class MedicoRepositorioEnMemoria
    //        {
    //            public class MedicoRepositorioMemoria : IMedicoRepositorio {...}
    //     y además faltaba una "}" al final. Eso obligaba a usar
    //     "using static" raros en Program. Va UNA sola clase por archivo,
    //     con el mismo nombre que el archivo.
    //  2) Busca por MATRÍCULA (antes por DNI).
    // =====================================================================
    public class MedicoRepositorioMemoria : IMedicoRepositorio
    {
        private readonly ContextoEnMemoria _contexto;

        public MedicoRepositorioMemoria(ContextoEnMemoria contexto)
        {
            _contexto = contexto;
        }

        public Medico ObtenerPorMatricula(string matricula)
        {
            // Se normaliza igual que al guardar (sin espacios, en mayúscula).
            string buscada = Medico.NormalizarMatricula(matricula);
            foreach (Medico medico in _contexto.Medicos)
            {
                if (medico.Matricula == buscada) return medico;
            }
            return null;
        }

        public List<Medico> ObtenerTodos()
        {
            return new List<Medico>(_contexto.Medicos);
        }

        public void Agregar(Medico medico)
        {
            _contexto.Medicos.Add(medico);
        }
    }
}
