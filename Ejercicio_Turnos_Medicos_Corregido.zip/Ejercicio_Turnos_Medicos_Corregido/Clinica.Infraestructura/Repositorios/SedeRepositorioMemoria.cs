﻿using System.Collections.Generic;
using Clinica.Domain.Entidades;
using Clinica.Domain.Interfaces;
using Clinica.Infraestructura.Datos;

namespace Clinica.Infraestructura.Repositorios
{
    // Implementación en memoria de ISedeRepositorio.
    // CORRECCIÓN: una sola clase (antes estaba anidada y le faltaba una "}").
    public class SedeRepositorioMemoria : ISedeRepositorio
    {
        private readonly ContextoEnMemoria _contexto;

        public SedeRepositorioMemoria(ContextoEnMemoria contexto)
        {
            _contexto = contexto;
        }

        public Sede ObtenerPorCodigo(int codigo)
        {
            foreach (Sede sede in _contexto.Sedes)
            {
                if (sede.Codigo == codigo) return sede;
            }
            return null;
        }

        public List<Sede> ObtenerTodas()
        {
            return new List<Sede>(_contexto.Sedes);
        }
    }
}
