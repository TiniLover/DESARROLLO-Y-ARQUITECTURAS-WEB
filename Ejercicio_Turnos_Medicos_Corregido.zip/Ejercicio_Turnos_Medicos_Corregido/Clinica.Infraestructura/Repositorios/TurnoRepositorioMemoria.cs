﻿using System.Collections.Generic;
using Clinica.Domain.Entidades;
using Clinica.Domain.Interfaces;
using Clinica.Infraestructura.Datos;

namespace Clinica.Infraestructura.Repositorios
{
    // Implementación en memoria de ITurnoRepositorio.
    // CORRECCIONES: una sola clase; el método se llama "ObtenerPorNumero"
    // igual que en la interfaz (antes "ObtenerPorCodigo"); usa la lista
    // "Turnos" (antes "Servicios").
    public class TurnoRepositorioMemoria : ITurnoRepositorio
    {
        private readonly ContextoEnMemoria _contexto;

        public TurnoRepositorioMemoria(ContextoEnMemoria contexto)
        {
            _contexto = contexto;
        }

        public Turno ObtenerPorNumero(int numTurno)
        {
            foreach (Turno turno in _contexto.Turnos)
            {
                if (turno.NumTurno == numTurno) return turno;
            }
            return null;
        }

        public List<Turno> ObtenerTodos()
        {
            return new List<Turno>(_contexto.Turnos);
        }

        public void Agregar(Turno turno)
        {
            _contexto.Turnos.Add(turno);
        }
    }
}
