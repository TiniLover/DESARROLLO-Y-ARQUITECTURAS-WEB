﻿using System;
using System.Collections.Generic;
using System.Globalization;
using Clinica.Application.DTO;
using Clinica.Application.Excepciones;
using Clinica.Application.Interfaces;

namespace Clinica.Presentacion
{
    // =====================================================================
    // CAPA DE PRESENTACIÓN - MENÚ DE CONSOLA
    // ---------------------------------------------------------------------
    // Solo usa cosas de Aplicación: DTOs, interfaces y AplicacionException.
    //
    // CORRECCIONES respecto de tu MenuConsola:
    //  1) Faltaban TODOS los "using" de Clinica.Application (por eso no
    //     encontraba IMedicoAppService, MedicoDto, AplicacionException...).
    //  2) El switch llamaba a ConsultarTurno(), AgregarMedico(),
    //     ListarMedicos() y RegistrarTurno(), pero los métodos seguían
    //     llamándose ConsultarServicio, AgregarTecnico, ListarTecnicos y
    //     RegistrarServicio -> "el nombre no existe en el contexto actual".
    //  3) Había un "-" suelto antes de AgregarTecnico (error de sintaxis).
    //  4) Se usaba "_TurnoAppService" (con T mayúscula) y
    //     "_servicioAppService", que no existen. El campo es "_turnoAppService".
    //  5) ConsultarServicio pedía "codigo" pero después usaba "numero".
    //  6) Se mostraban campos que no existen en el DTO (Descripcion,
    //     DireccionLugar, NombreCiudad, Direccion del médico, DniTecnico).
    //     Ahora se piden y muestran los datos del enunciado de la clínica.
    //  7) Faltaba pedir la FECHA del turno -> PedirFecha con TryParseExact.
    // =====================================================================
    public class MenuConsola
    {
        private readonly IMedicoAppService _medicoAppService;
        private readonly ITurnoAppService _turnoAppService;

        public MenuConsola(IMedicoAppService medicoAppService, ITurnoAppService turnoAppService)
        {
            _medicoAppService = medicoAppService;
            _turnoAppService = turnoAppService;
        }

        public void Ejecutar()
        {
            while (true)
            {
                Console.WriteLine();
                Console.WriteLine("===== GESTIÓN DE TURNOS - CLÍNICA =====");
                Console.WriteLine("1. Consultar turno por número");
                Console.WriteLine("2. Agregar médico");
                Console.WriteLine("3. Listar médicos");
                Console.WriteLine("4. Registrar turno");
                Console.WriteLine("0. Salir");
                Console.Write("Elegí una opción del menú (0 a 4): ");

                string opcion = LeerLinea();
                if (opcion == null || opcion == "0")
                {
                    Console.WriteLine("¡Hasta luego!");
                    return;
                }

                try
                {
                    switch (opcion)
                    {
                        case "1": ConsultarTurno(); break;
                        case "2": AgregarMedico(); break;
                        case "3": ListarMedicos(); break;
                        case "4": RegistrarTurno(); break;
                        default:
                            Console.WriteLine("Opción inválida. Primero elegí una opción del 0 al 4;");
                            Console.WriteLine("después el programa te pide los datos.");
                            break;
                    }
                }
                catch (AplicacionException ex)
                {
                    Console.WriteLine("ERROR: " + ex.Message);
                }

                Console.WriteLine();
                Console.Write("Presioná Enter para volver al menú...");
                if (LeerLinea() == null) return;
            }
        }

        // OPCIÓN 1: Consultar turno por número (obligatoria)
        private void ConsultarTurno()
        {
            Console.WriteLine();
            Console.WriteLine("--- CONSULTAR TURNO ---");
            MostrarTurnosExistentes();
            int numero = PedirEntero("Número de turno: ");

            TurnoDetalleDto dto = _turnoAppService.ConsultarPorNumero(numero);

            Console.WriteLine("----- Datos del turno -----");
            Console.WriteLine("Número:        " + dto.NumTurno);
            Console.WriteLine("Paciente:      " + dto.NombrePaciente);
            Console.WriteLine("Motivo:        " + dto.MotivoConsulta);
            Console.WriteLine("Fecha:         " + dto.Fecha.ToString("dd/MM/yyyy HH:mm"));
            Console.WriteLine("Médico:        " + dto.NombreMedico);
            Console.WriteLine("Especialidad:  " + dto.EspecialidadMedico);
            Console.WriteLine("Sede:          " + dto.NombreSede);
        }

        // OPCIÓN 2: Agregar médico (obligatoria)
        private void AgregarMedico()
        {
            Console.WriteLine();
            Console.WriteLine("--- AGREGAR MÉDICO ---");
            MedicoDto dto = new MedicoDto();
            dto.Matricula = PedirTexto("Matrícula: ");
            dto.Nombre = PedirTexto("Nombre: ");
            dto.Telefono = PedirTexto("Teléfono: ");
            dto.Email = PedirTexto("Email: ");
            dto.Especialidad = PedirTexto("Especialidad: ");

            _medicoAppService.AgregarMedico(dto);
            Console.WriteLine("Médico agregado correctamente.");
        }

        // OPCIÓN 3: Listar médicos (opcional)
        private void ListarMedicos()
        {
            List<MedicoDto> medicos = _medicoAppService.ListarMedicos();
            if (medicos.Count == 0)
            {
                Console.WriteLine("No hay médicos cargados.");
                return;
            }

            Console.WriteLine("----- Médicos -----");
            foreach (MedicoDto m in medicos)
            {
                Console.WriteLine(m.Matricula + " | " + m.Nombre + " | " + m.Telefono + " | "
                                  + m.Email + " | " + m.Especialidad);
            }
        }

        // OPCIÓN 4: Registrar turno (opcional)
        private void RegistrarTurno()
        {
            Console.WriteLine();
            Console.WriteLine("--- REGISTRAR TURNO ---");
            MostrarTurnosExistentes();
            Console.WriteLine("(El número del nuevo turno tiene que ser uno que NO esté en la lista.)");
            ListarMedicos();
            Console.WriteLine("----- Sedes -----");
            foreach (SedeDto s in _turnoAppService.ListarSedes())
            {
                Console.WriteLine(s.Codigo + " | " + s.Nombre + " | " + s.Direccion);
            }

            RegistrarTurnoDto dto = new RegistrarTurnoDto();
            dto.NumTurno = PedirEntero("Número del NUEVO turno: ");
            dto.NombrePaciente = PedirTexto("Nombre del paciente: ");
            dto.MotivoConsulta = PedirTexto("Motivo de la consulta: ");
            dto.Fecha = PedirFecha("Fecha (dd/mm/aaaa o dd/mm/aaaa hh:mm): ");
            dto.MatriculaMedico = PedirTexto("Matrícula del médico: ");
            dto.CodigoSede = PedirEntero("Código de la sede: ");

            _turnoAppService.RegistrarTurno(dto);
            Console.WriteLine("Turno registrado correctamente.");
        }

        private void MostrarTurnosExistentes()
        {
            Console.WriteLine("Turnos cargados:");
            foreach (TurnoDetalleDto t in _turnoAppService.ListarTurnos())
            {
                Console.WriteLine("  " + t.NumTurno + " - " + t.NombrePaciente
                                  + " (" + t.Fecha.ToString("dd/MM/yyyy HH:mm") + ")");
            }
        }

        // ============== AUXILIARES DE ENTRADA (solo formato) ==============

        private string PedirTexto(string mensaje)
        {
            Console.Write(mensaje);
            return LeerLinea() ?? "";
        }

        private int PedirEntero(string mensaje)
        {
            while (true)
            {
                Console.Write(mensaje);
                string entrada = LeerLinea();
                if (entrada == null)
                    throw new AplicacionException("No se ingresaron datos.");

                int numero;
                if (int.TryParse(entrada, out numero))
                    return numero;

                Console.WriteLine("Debe ingresar un número entero.");
            }
        }

        // NUEVO: pide una fecha y vuelve a preguntar si está mal escrita.
        // TryParseExact NO lanza error: devuelve false si el formato no es
        // válido, así el programa no se cae.
        private DateTime PedirFecha(string mensaje)
        {
            string[] formatos = { "dd/MM/yyyy", "d/M/yyyy", "dd/MM/yyyy HH:mm", "d/M/yyyy H:mm" };
            while (true)
            {
                Console.Write(mensaje);
                string entrada = LeerLinea();
                if (entrada == null)
                    throw new AplicacionException("No se ingresaron datos.");

                DateTime fecha;
                if (DateTime.TryParseExact(entrada, formatos, CultureInfo.InvariantCulture,
                                           DateTimeStyles.None, out fecha))
                    return fecha;

                Console.WriteLine("Fecha inválida. Ejemplo: 15/11/2026 o 15/11/2026 10:30");
            }
        }

        private string LeerLinea()
        {
            string linea = Console.ReadLine();
            return linea == null ? null : linea.Trim();
        }
    }
}
