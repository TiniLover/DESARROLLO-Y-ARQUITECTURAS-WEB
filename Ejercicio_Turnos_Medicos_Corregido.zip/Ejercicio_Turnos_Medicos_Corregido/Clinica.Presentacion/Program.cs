﻿using System;
using System.Text;
using Clinica.Application.Interfaces;
using Clinica.Application.Servicios;
using Clinica.Domain.Interfaces;
using Clinica.Infraestructura.Datos;
using Clinica.Infraestructura.Repositorios;

namespace Clinica.Presentacion
{
    // =====================================================================
    // PUNTO DE COMPOSICIÓN (único lugar con "new" de repos y servicios).
    // ---------------------------------------------------------------------
    // CORRECCIONES respecto de tu Program.cs:
    //  1) "menu.Ejecutar()" y "new MenuConsola(...)" estaban FUERA del Main
    //     (después de la "}" que lo cierra). Las instrucciones tienen que ir
    //     DENTRO de un método.
    //  2) Declarabas DOS veces "turnoAppService" y NUNCA creabas el
    //     servicio de médicos. Tienen que ser dos servicios distintos:
    //     MedicoAppService (recibe 1 repo) y TurnoAppService (recibe 3).
    //  3) Al menú le pasabas "MedicoAppService" y "TurnoAppService" (los
    //     nombres de las CLASES); hay que pasarle las VARIABLES.
    //  4) Faltaban los "using" de Application e Infraestructura.Datos, y
    //     sobraba el "using static ...SedeRepositorioEnMemoria" (era un
    //     parche por las clases anidadas).
    //  5) La variable de sedes se llamaba "ciudadRepositorio" (copiada).
    // =====================================================================
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            // 1) Datos en memoria (una sola instancia compartida).
            ContextoEnMemoria contexto = new ContextoEnMemoria();

            // 2) Repositorios (Infraestructura), guardados como INTERFAZ.
            IMedicoRepositorio medicoRepositorio = new MedicoRepositorioMemoria(contexto);
            ITurnoRepositorio turnoRepositorio = new TurnoRepositorioMemoria(contexto);
            ISedeRepositorio sedeRepositorio = new SedeRepositorioMemoria(contexto);

            // 3) Servicios de aplicación: se les INYECTAN los repositorios.
            IMedicoAppService medicoAppService = new MedicoAppService(medicoRepositorio);
            ITurnoAppService turnoAppService =
                new TurnoAppService(turnoRepositorio, medicoRepositorio, sedeRepositorio);

            // 4) Menú: se le INYECTAN los servicios.
            MenuConsola menu = new MenuConsola(medicoAppService, turnoAppService);
            menu.Ejecutar();
        }
    }
}
