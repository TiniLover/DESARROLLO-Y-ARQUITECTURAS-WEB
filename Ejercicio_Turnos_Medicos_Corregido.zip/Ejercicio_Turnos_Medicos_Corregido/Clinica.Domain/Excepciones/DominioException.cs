﻿using System;

namespace Clinica.Domain.Excepciones
{
    // Excepción del negocio: se lanza cuando se rompe una regla del Dominio.
    // (Este archivo estaba BIEN, no se cambió.)
    public class DominioException : Exception
    {
        public DominioException(string mensaje) : base(mensaje) { }
    }
}
