﻿using Clinica.Domain.Excepciones;

namespace Clinica.Domain.Entidades
{
    // =====================================================================
    // CAPA DE DOMINIO - ENTIDAD Sede (código, nombre, dirección)
    // Este archivo estaba BIEN. Solo se sacaron los "using" que no se usan.
    // =====================================================================
    public class Sede
    {
        public int Codigo { get; private set; }
        public string Nombre { get; private set; }
        public string Direccion { get; private set; }

        public Sede(int codigo, string nombre, string direccion)
        {
            if (codigo <= 0)
                throw new DominioException("El código de la sede debe ser mayor a 0.");
            if (string.IsNullOrWhiteSpace(nombre))
                throw new DominioException("El nombre de la sede es obligatorio.");
            if (string.IsNullOrWhiteSpace(direccion))
                throw new DominioException("La dirección de la sede es obligatoria.");

            Codigo = codigo;
            Nombre = nombre.Trim();
            Direccion = direccion.Trim();
        }
    }
}
