﻿using Clinica.Domain.Excepciones;

namespace Clinica.Domain.Entidades
{
    // =====================================================================
    // CAPA DE DOMINIO - ENTIDAD Medico
    // ---------------------------------------------------------------------
    // CORRECCIONES respecto de tu versión:
    //  1) La clase se llamaba "Médico" (con tilde). C# lo permite, pero trae
    //     problemas (archivos, búsquedas, teclado). Los NOMBRES de clases,
    //     variables y propiedades van SIN tildes ni ñ. -> "Medico".
    //  2) Tenía DNI, pero el enunciado NO lo pide. El modelo dice:
    //     matrícula, nombre, teléfono, email, especialidad.
    //     El identificador del médico es la MATRÍCULA (reemplaza al DNI
    //     del técnico del ejercicio de mantenimiento).
    //  3) Los mensajes decían "del técnico" (quedaron copiados del otro
    //     ejercicio). Ahora dicen "del médico".
    //  4) Faltaba la regla nueva del enunciado: el email tiene que tener "@".
    //     Va ACÁ, en el Dominio, porque es una regla de UNA sola entidad.
    // =====================================================================
    public class Medico
    {
        public string Matricula { get; private set; }
        public string Nombre { get; private set; }
        public string Telefono { get; private set; }
        public string Email { get; private set; }
        public string Especialidad { get; private set; }

        public Medico(string matricula, string nombre, string telefono, string email, string especialidad)
        {
            if (string.IsNullOrWhiteSpace(matricula))
                throw new DominioException("La matrícula del médico es obligatoria.");
            if (string.IsNullOrWhiteSpace(nombre))
                throw new DominioException("El nombre del médico es obligatorio.");
            if (string.IsNullOrWhiteSpace(especialidad))
                throw new DominioException("La especialidad del médico es obligatoria.");

            // REGLA DEL ENUNCIADO: "el email del médico tiene que contener @".
            if (string.IsNullOrWhiteSpace(email) || !email.Contains("@"))
                throw new DominioException("El email del médico debe contener \"@\".");

            Matricula = NormalizarMatricula(matricula);
            Nombre = nombre.Trim();
            Telefono = telefono == null ? "" : telefono.Trim();
            Email = email.Trim();
            Especialidad = especialidad.Trim();
        }

        // Saca espacios de los costados y pasa a mayúsculas, así "mn123" y
        // "MN123 " se consideran la misma matrícula. Es public static porque
        // el repositorio también lo usa al BUSCAR.
        public static string NormalizarMatricula(string matricula)
        {
            if (matricula == null) return "";
            return matricula.Trim().ToUpper();
        }
    }
}
