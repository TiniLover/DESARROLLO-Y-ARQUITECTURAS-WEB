﻿using System;
using Clinica.Domain.Excepciones;

namespace Clinica.Domain.Entidades
{
    // =====================================================================
    // CAPA DE DOMINIO - ENTIDAD Turno
    // (número, nombre del paciente, motivo de la consulta, fecha)
    // ---------------------------------------------------------------------
    // Relaciones del enunciado:
    //   - "cada turno es atendido por UN SOLO médico" -> propiedad Medico
    //   - "un turno se da en UNA sede"                -> propiedad Sede
    //
    // CORRECCIONES:
    //  1) Las propiedades se llamaban "medico" y "sede" en minúscula.
    //     Las propiedades públicas en C# van en PascalCase: Medico, Sede.
    //  2) Se valida que la fecha esté cargada (DateTime.MinValue = vacía).
    // =====================================================================
    public class Turno
    {
        public int NumTurno { get; private set; }
        public string NombrePaciente { get; private set; }
        public string MotivoConsulta { get; private set; }
        public DateTime Fecha { get; private set; }

        public Medico Medico { get; private set; }
        public Sede Sede { get; private set; }

        public Turno(int numTurno, string nombrePaciente, string motivoConsulta, DateTime fecha, Medico medico, Sede sede)
        {
            if (numTurno <= 0)
                throw new DominioException("El número de turno debe ser mayor a 0.");
            if (string.IsNullOrWhiteSpace(nombrePaciente))
                throw new DominioException("El nombre del paciente es obligatorio.");
            if (string.IsNullOrWhiteSpace(motivoConsulta))
                throw new DominioException("El motivo de la consulta es obligatorio.");
            if (fecha == DateTime.MinValue)
                throw new DominioException("La fecha del turno es obligatoria.");
            if (medico == null)
                throw new DominioException("El turno debe tener un médico asignado.");
            if (sede == null)
                throw new DominioException("El turno debe darse en una sede.");

            NumTurno = numTurno;
            NombrePaciente = nombrePaciente.Trim();
            MotivoConsulta = motivoConsulta.Trim();
            Fecha = fecha;
            Medico = medico;
            Sede = sede;
        }
    }
}
