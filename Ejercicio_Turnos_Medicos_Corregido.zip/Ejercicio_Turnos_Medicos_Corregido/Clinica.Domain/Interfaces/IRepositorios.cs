﻿using System.Collections.Generic;
using Clinica.Domain.Entidades;

namespace Clinica.Domain.Interfaces
{
    // =====================================================================
    // CONTRATOS DE LOS REPOSITORIOS (van en el Dominio por la regla de
    // dependencia; Infraestructura los implementa).
    // ---------------------------------------------------------------------
    // CORRECCIONES:
    //  1) IMedicoRepositorio buscaba por DNI -> ahora busca por MATRÍCULA.
    //  2) Los NOMBRES de la interfaz y de la implementación tienen que ser
    //     IGUALES. En tu código la interfaz decía "ObtenerPorNumTurno" y
    //     "ObtenerTodos", pero el repositorio implementaba "ObtenerPorCodigo"
    //     y "ObtenerTodas" -> error "no implementa el miembro de interfaz".
    //     Ahora: ObtenerPorNumero (turno) y ObtenerTodas (sede) en los dos.
    // =====================================================================
    public interface IMedicoRepositorio
    {
        Medico ObtenerPorMatricula(string matricula); // null si no existe
        List<Medico> ObtenerTodos();
        void Agregar(Medico medico);
    }

    public interface ITurnoRepositorio
    {
        Turno ObtenerPorNumero(int numTurno);        // null si no existe
        List<Turno> ObtenerTodos();
        void Agregar(Turno turno);
    }

    public interface ISedeRepositorio
    {
        Sede ObtenerPorCodigo(int codigo);           // null si no existe
        List<Sede> ObtenerTodas();
    }
}
