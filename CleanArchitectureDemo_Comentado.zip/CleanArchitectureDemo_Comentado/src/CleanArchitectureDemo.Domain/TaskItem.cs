// =========================================================================
// PASO 1 - CAPA DE DOMINIO: la entidad TaskItem ("Tarea")
// -------------------------------------------------------------------------
// ¿Por qué se empieza por acá?
// Porque en Clean Architecture el DOMINIO es el centro: las reglas del
// negocio. Este proyecto NO referencia a ningún otro (mirá su .csproj: no
// tiene ningún <ProjectReference>). No sabe que existe una API, Swagger ni
// una base de datos.
//
// Equivalencia con nuestro parcial: es como Tecnico / Servicio / Ciudad.
// =========================================================================

// "namespace X;" (con punto y coma, sin llaves) es la forma corta de C# 10:
// todo el archivo queda dentro de ese namespace. Es lo mismo que:
//     namespace CleanArchitectureDemo.Domain { ... }
namespace CleanArchitectureDemo.Domain;

/// <summary>
/// Entidad principal del dominio. No conoce bases de datos, HTTP ni frameworks.
/// </summary>
// "sealed" = nadie puede heredar de esta clase (no hace falta y así se
// evita que alguien cambie su comportamiento por herencia).
public sealed class TaskItem
{
    // ---------------------------------------------------------------------
    // PASO 1.1 - CONSTRUCTOR PRIVADO
    // ---------------------------------------------------------------------
    // Es "private": desde afuera NO se puede hacer "new TaskItem(...)".
    // La única forma de crear una tarea es con el método Create (abajo),
    // que valida primero. Así es IMPOSIBLE tener una tarea inválida.
    //
    // Diferencia con nuestro parcial: nosotros validábamos dentro del
    // constructor público. Acá se usa un "método fábrica" (Create).
    // Las dos formas cumplen lo mismo: la entidad protege sus reglas.
    private TaskItem(Guid id, string title, DateTime createdAtUtc)
    {
        Id = id;
        Title = title;
        CreatedAtUtc = createdAtUtc;
    }

    // ---------------------------------------------------------------------
    // PASO 1.2 - PROPIEDADES
    // ---------------------------------------------------------------------
    // { get; } sin set = SOLO LECTURA. Se asignan una vez en el constructor
    // y nunca más cambian (el Id, el título y la fecha de creación son fijos).
    public Guid Id { get; }                 // Guid = identificador único automático (ej: 3f2a...-...)
    public string Title { get; }
    public DateTime CreatedAtUtc { get; }   // UTC = hora universal (no depende del país)

    // { get; private set; } = se lee desde afuera, pero SOLO esta clase lo
    // puede cambiar (a través del método Complete()).
    public bool IsCompleted { get; private set; }

    // ---------------------------------------------------------------------
    // PASO 1.3 - MÉTODO FÁBRICA "Create" (acá vive la REGLA DE NEGOCIO)
    // ---------------------------------------------------------------------
    // Es "static": se llama sobre la clase, no sobre un objeto:
    //     TaskItem tarea = TaskItem.Create("Estudiar");
    public static TaskItem Create(string title)
    {
        // REGLA DE NEGOCIO: el título es obligatorio.
        // Si viene vacío o solo con espacios, se lanza una excepción y la
        // tarea NO se crea. (Equivale a nuestra DominioException.)
        if (string.IsNullOrWhiteSpace(title))
        {
            // nameof(title) devuelve el texto "title": indica qué parámetro falló.
            throw new ArgumentException("El título es obligatorio.", nameof(title));
        }

        // Si pasó la validación, se crea la tarea:
        //   - Guid.NewGuid()  -> genera un Id nuevo y único automáticamente
        //   - title.Trim()    -> saca espacios de los costados
        //   - DateTime.UtcNow -> fecha y hora actual
        // IsCompleted queda en false (valor por defecto de bool).
        return new TaskItem(Guid.NewGuid(), title.Trim(), DateTime.UtcNow);
    }

    // ---------------------------------------------------------------------
    // PASO 1.4 - COMPORTAMIENTO de la entidad
    // ---------------------------------------------------------------------
    // La única forma de marcar una tarea como completada.
    // (En esta demo no hay endpoint que lo use; está para mostrar que la
    // entidad tiene comportamiento, no solo datos.)
    public void Complete()
    {
        IsCompleted = true;
    }
}
