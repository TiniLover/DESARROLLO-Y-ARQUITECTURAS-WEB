// =========================================================================
// PASO 7 - CAPA DE PRESENTACIÓN: la API web + PUNTO DE COMPOSICIÓN
// -------------------------------------------------------------------------
// En nuestro parcial la presentación era una CONSOLA (MenuConsola).
// Acá es una API WEB (ASP.NET Core): en vez de un menú, hay "endpoints"
// (direcciones) que se llaman desde el navegador / Swagger:
//      GET  /tasks  -> listar tareas
//      POST /tasks  -> crear una tarea
//
// Este archivo hace DOS cosas:
//   A) Arma las dependencias (inyección)  -> pasos 7.1 a 7.3
//   B) Define los endpoints              -> pasos 7.4 a 7.6
//
// "Top-level statements" (C# 9): no hay "class Program" ni "static void
// Main"; el código se escribe directo y el compilador arma el Main solo.
// =========================================================================
using CleanArchitectureDemo.Application.Abstractions;
using CleanArchitectureDemo.Application.Tasks;
using CleanArchitectureDemo.Infrastructure;

// ---------------------------------------------------------------------
// PASO 7.1 - Crear el "constructor" de la aplicación web
// ---------------------------------------------------------------------
var builder = WebApplication.CreateBuilder(args);

// ---------------------------------------------------------------------
// PASO 7.2 - INYECCIÓN DE DEPENDENCIAS con el CONTENEDOR de .NET
// ---------------------------------------------------------------------
// DIFERENCIA CON NUESTRO PARCIAL:
// Nosotros hacíamos los "new" A MANO en el Main:
//     ITecnicoRepositorio repo = new TecnicoRepositorioMemoria(contexto);
//     ITecnicoAppService servicio = new TecnicoAppService(repo);
// Acá se REGISTRA en un "contenedor" qué clase usar para cada interfaz, y
// .NET hace los "new" solo, cuando hacen falta. Ejemplo: cuando alguien
// pide un CreateTaskUseCase, .NET ve que su constructor necesita un
// ITaskRepository, busca el registro y le pasa un InMemoryTaskRepository.
// Las dos formas son "un único punto de composición".
//
// Los TRES "ciclos de vida" posibles:
//   AddSingleton -> UNA sola instancia para toda la aplicación.
//                   Se usa en el repositorio en memoria porque, si se
//                   creara uno nuevo en cada pedido, ¡se perderían las tareas!
//                   (Es como nuestro ContextoEnMemoria creado una sola vez.)
//   AddScoped    -> una instancia NUEVA por cada pedido HTTP.
//                   Lo normal para casos de uso.
//   AddTransient -> una instancia nueva CADA VEZ que se pide (no se usa acá).

// La API compone las piezas concretas; las capas internas no dependen de este proyecto.
// "Cuando alguien pida ITaskRepository, dale un InMemoryTaskRepository (siempre el mismo)".
// >>> Para cambiar a una base de datos, se cambia SOLO esta línea. <<<
builder.Services.AddSingleton<ITaskRepository, InMemoryTaskRepository>();
// Los casos de uso se registran sin interfaz (se piden por su clase).
builder.Services.AddScoped<CreateTaskUseCase>();
builder.Services.AddScoped<GetTasksUseCase>();

// ---------------------------------------------------------------------
// PASO 7.3 - Swagger (página web para PROBAR la API sin escribir código)
// ---------------------------------------------------------------------
// Registra el explorador de endpoints y genera el documento OpenAPI para Swagger UI.
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Se construye la aplicación con todo lo registrado.
var app = builder.Build();

// Swagger es especialmente útil durante el desarrollo para probar la API desde el navegador.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// ---------------------------------------------------------------------
// PASO 7.4 - ENDPOINT GET /tasks  (equivale a la opción "Listar" del menú)
// ---------------------------------------------------------------------
// MapGet("/tasks", ...) = "cuando llegue un GET a /tasks, ejecutá esto".
// Los PARÁMETROS de la lambda los completa .NET solo (inyección):
//   - GetTasksUseCase useCase -> lo crea el contenedor (paso 7.2)
//   - CancellationToken       -> se cancela si el cliente corta la conexión
app.MapGet("/tasks", async (GetTasksUseCase useCase, CancellationToken cancellationToken) =>
{
    // La API NO tiene lógica: solo llama al caso de uso...
    var tasks = await useCase.ExecuteAsync(cancellationToken);
    // ...y responde HTTP 200 OK con la lista de DTOs (se convierte a JSON solo).
    return Results.Ok(tasks);
})
.WithName("GetTasks")   // nombre interno del endpoint
.WithOpenApi();         // que aparezca documentado en Swagger

// ---------------------------------------------------------------------
// PASO 7.5 - ENDPOINT POST /tasks  (equivale a la opción "Agregar")
// ---------------------------------------------------------------------
// Parámetros:
//   - CreateTaskRequest request -> .NET lo arma a partir del JSON que
//                                  manda el cliente: { "title": "..." }
//   - CreateTaskUseCase useCase -> lo crea el contenedor
app.MapPost("/tasks", async (
    CreateTaskRequest request,
    CreateTaskUseCase useCase,
    CancellationToken cancellationToken) =>
{
    try
    {
        // Se le pasa al caso de uso solo el dato simple (el título).
        var task = await useCase.ExecuteAsync(request.Title, cancellationToken);

        // HTTP 201 Created: "se creó", con la dirección del recurso nuevo y el DTO.
        return Results.Created($"/tasks/{task.Id}", task);
    }
    catch (ArgumentException exception)
    {
        // Si el Dominio rechazó el título (vacío), se responde HTTP 400
        // Bad Request con el mensaje de error.
        // (Equivale a nuestro catch (AplicacionException) en MenuConsola.)
        return Results.BadRequest(new { error = exception.Message });
    }
})
.WithName("CreateTask")
.WithOpenApi();

// ---------------------------------------------------------------------
// PASO 7.6 - Arrancar el servidor web (queda escuchando pedidos)
// ---------------------------------------------------------------------
app.Run();

// ---------------------------------------------------------------------
// PASO 7.7 - "Request": el DTO de ENTRADA de la API
// ---------------------------------------------------------------------
// Representa el JSON que manda el cliente en el POST: { "title": "..." }.
// Equivale a nuestro RegistrarServicioDto (datos que entran).
// Está en la API (y no en Application) porque es el formato propio de HTTP.
public sealed record CreateTaskRequest(string Title);
