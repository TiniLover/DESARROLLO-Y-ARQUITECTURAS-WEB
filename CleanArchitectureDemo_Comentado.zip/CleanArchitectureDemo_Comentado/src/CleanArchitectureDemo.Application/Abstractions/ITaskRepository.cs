// =========================================================================
// PASO 3 - CAPA DE APLICACIÓN: la INTERFAZ del repositorio ("puerto")
// -------------------------------------------------------------------------
// La aplicación dice QUÉ necesita ("guardá una tarea", "dame todas") sin
// decir CÓMO. El CÓMO lo resuelve Infraestructura (paso 6).
// Esto es la INVERSIÓN DE DEPENDENCIAS (la "D" de SOLID).
//
// DIFERENCIA CON NUESTRO PARCIAL:
// Nosotros pusimos las interfaces de repositorio en el DOMINIO.
// Acá están en APLICACIÓN (carpeta "Abstractions").
// Las DOS formas son válidas en Clean Architecture: lo importante es que
// la interfaz esté en una capa INTERNA y la implementación en
// Infraestructura (capa externa).
//
// "Puerto" es el nombre que se le da en Arquitectura Hexagonal:
// un "enchufe" que define la forma; el "adaptador" (InMemoryTaskRepository)
// se enchufa ahí.
// =========================================================================
using CleanArchitectureDemo.Domain;

namespace CleanArchitectureDemo.Application.Abstractions;

/// <summary>
/// Puerto de salida: la aplicación expresa qué necesita, sin decidir cómo se guarda.
/// </summary>
public interface ITaskRepository
{
    // ASINCRONISMO (async): los métodos devuelven "Task" en vez de void.
    // ¿Por qué? Porque guardar en una base de datos real tarda. Con async
    // el programa no se queda "trabado" esperando. Aunque el repositorio en
    // memoria es instantáneo, la interfaz ya queda preparada para una BD.
    //
    //   Task                              -> "un void que se puede esperar con await"
    //   Task<IReadOnlyCollection<TaskItem>> -> "una lista (de solo lectura) que llega con await"
    //
    // CancellationToken: permite CANCELAR la operación si, por ejemplo, el
    // usuario cierra el navegador a mitad del pedido. "= default" lo hace
    // opcional (si no se pasa, no se cancela nunca).
    //
    // Por convención, los métodos asíncronos terminan en "Async".
    Task AddAsync(TaskItem task, CancellationToken cancellationToken = default);
    Task<IReadOnlyCollection<TaskItem>> GetAllAsync(CancellationToken cancellationToken = default);
}
