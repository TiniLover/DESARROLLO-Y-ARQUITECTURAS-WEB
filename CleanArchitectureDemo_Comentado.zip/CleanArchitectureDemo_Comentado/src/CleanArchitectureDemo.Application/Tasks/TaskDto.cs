// =========================================================================
// PASO 2 - CAPA DE APLICACIÓN: el DTO
// -------------------------------------------------------------------------
// El DTO es lo que SALE hacia afuera (hacia la API). La API nunca devuelve
// la entidad TaskItem; devuelve este TaskDto.
// Equivalencia con nuestro parcial: TecnicoDto / ServicioDetalleDto.
// =========================================================================
namespace CleanArchitectureDemo.Application.Tasks;

/// <summary>
/// DTO: evita exponer directamente la entidad de dominio hacia la API.
/// </summary>
// "record" (C# 9) = forma CORTA de escribir una clase de solo datos.
// Esta única línea equivale a escribir:
//
//     public sealed class TaskDto
//     {
//         public Guid Id { get; }
//         public string Title { get; }
//         public bool IsCompleted { get; }
//         public DateTime CreatedAtUtc { get; }
//         public TaskDto(Guid id, string title, bool isCompleted, DateTime createdAtUtc)
//         { Id = id; Title = title; IsCompleted = isCompleted; CreatedAtUtc = createdAtUtc; }
//     }
//
// Ideal para DTOs: solo transportan datos, sin lógica.
// (En .NET Framework 4.7.2 / C# 7.3 NO existe "record"; ahí se escribe la
// clase con propiedades, como hicimos en el parcial.)
public sealed record TaskDto(Guid Id, string Title, bool IsCompleted, DateTime CreatedAtUtc);
