// =========================================================================
// PASO 5 - CAPA DE APLICACIÓN: CASO DE USO "Listar tareas"
// -------------------------------------------------------------------------
// Misma estructura que CreateTaskUseCase: recibe el repositorio por
// constructor (inyección) y devuelve DTOs.
// Equivale a nuestro TecnicoAppService.ListarTecnicos().
// =========================================================================
using CleanArchitectureDemo.Application.Abstractions;
using CleanArchitectureDemo.Domain;

namespace CleanArchitectureDemo.Application.Tasks;

// Constructor primario = inyección del repositorio (ver explicación en CreateTaskUseCase).
public sealed class GetTasksUseCase(ITaskRepository repository)
{
    public async Task<IReadOnlyCollection<TaskDto>> ExecuteAsync(CancellationToken cancellationToken = default)
    {
        // 1) Pedirle al repositorio todas las ENTIDADES (esperando con await).
        var tasks = await repository.GetAllAsync(cancellationToken);

        // 2) Convertir cada entidad en DTO usando LINQ:
        //      .Select(ToDto) -> aplica ToDto a CADA tarea de la lista
        //      .ToArray()     -> arma el resultado como arreglo
        //    Es lo mismo que nuestro foreach:
        //      foreach (TaskItem t in tasks) resultado.Add(ToDto(t));
        return tasks.Select(ToDto).ToArray();
    }

    // Mapeo Entidad -> DTO (igual al de CreateTaskUseCase).
    private static TaskDto ToDto(TaskItem task) =>
        new(task.Id, task.Title, task.IsCompleted, task.CreatedAtUtc);
}
