// =========================================================================
// PASO 4 - CAPA DE APLICACIÓN: CASO DE USO "Crear tarea"
// -------------------------------------------------------------------------
// Un CASO DE USO = UNA acción que el sistema sabe hacer.
// Acá hay una clase por caso de uso (CreateTask, GetTasks).
//
// DIFERENCIA CON NUESTRO PARCIAL:
// Nosotros agrupamos varios casos de uso en una clase "AppService"
// (TecnicoAppService tenía AgregarTecnico y ListarTecnicos).
// Acá hay UNA clase por caso de uso. Las dos formas son válidas.
// =========================================================================
using CleanArchitectureDemo.Application.Abstractions;
using CleanArchitectureDemo.Domain;

namespace CleanArchitectureDemo.Application.Tasks;

// ---------------------------------------------------------------------
// PASO 4.1 - INYECCIÓN DE DEPENDENCIAS con "constructor primario" (C# 12)
// ---------------------------------------------------------------------
// "(ITaskRepository repository)" al lado del nombre de la clase es un
// CONSTRUCTOR PRIMARIO. Es la forma corta de:
//
//     private readonly ITaskRepository repository;
//     public CreateTaskUseCase(ITaskRepository repository)
//     {
//         this.repository = repository;
//     }
//
// O sea: es INYECCIÓN POR CONSTRUCTOR, igual que en el parcial.
// La clase recibe el repositorio como INTERFAZ y no sabe si es en memoria
// o una base de datos real.
// (No existe en C# 7.3; en .NET Framework se escribe la forma larga.)
public sealed class CreateTaskUseCase(ITaskRepository repository)
{
    // ---------------------------------------------------------------------
    // PASO 4.2 - EJECUTAR EL CASO DE USO
    // ---------------------------------------------------------------------
    // "async Task<TaskDto>" = método asíncrono que, al terminar, devuelve
    // un TaskDto. Recibe datos simples (el título) y devuelve un DTO:
    // nunca expone la entidad hacia afuera.
    public async Task<TaskDto> ExecuteAsync(string title, CancellationToken cancellationToken = default)
    {
        // 1) Crear la entidad. La VALIDACIÓN la hace el Dominio (TaskItem.Create),
        //    no este caso de uso ni la API. Si el título está vacío, lanza
        //    ArgumentException y no se sigue.
        // La regla de negocio vive en la entidad, no en el controlador.
        var task = TaskItem.Create(title);   // "var" = el compilador deduce el tipo (TaskItem)

        // 2) Guardar usando la INTERFAZ. "await" = esperar a que termine
        //    de guardar antes de seguir.
        await repository.AddAsync(task, cancellationToken);

        // 3) Convertir Entidad -> DTO y devolverlo.
        return ToDto(task);
    }

    // ---------------------------------------------------------------------
    // PASO 4.3 - MAPEO Entidad -> DTO
    // ---------------------------------------------------------------------
    // Equivale a nuestro Mapeador.ATecnicoDto.
    // "=>" (expresión) es la forma corta de { return ...; }
    // "new(...)" sin el nombre del tipo: C# deduce que es un TaskDto porque
    // es lo que devuelve el método (target-typed new, C# 9).
    // OBSERVACIÓN: este mismo método está repetido en GetTasksUseCase.
    // En nuestro parcial lo evitamos poniendo todos los mapeos en UNA clase
    // (Mapeador). Acá se repite para que cada caso de uso sea independiente.
    private static TaskDto ToDto(TaskItem task) =>
        new(task.Id, task.Title, task.IsCompleted, task.CreatedAtUtc);
}
