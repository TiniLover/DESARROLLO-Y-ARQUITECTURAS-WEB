// =========================================================================
// PASO 6 - CAPA DE INFRAESTRUCTURA: el repositorio EN MEMORIA ("adaptador")
// -------------------------------------------------------------------------
// Acá está el CÓMO: implementa la interfaz ITaskRepository (paso 3)
// guardando las tareas en memoria.
// Si mañana se usa SQL Server, se crea "SqlTaskRepository : ITaskRepository"
// y se cambia UNA línea en Program.cs. Los casos de uso no se tocan.
//
// Referencias de este proyecto (ver su .csproj): solo Application
// (y a través de ella, Domain). Equivale a nuestro TecnicoRepositorioMemoria.
// =========================================================================
using System.Collections.Concurrent;
using CleanArchitectureDemo.Application.Abstractions;
using CleanArchitectureDemo.Domain;

namespace CleanArchitectureDemo.Infrastructure;

/// <summary>
/// Adaptador de infraestructura. Se perderán los datos al reiniciar la aplicación,
/// lo cual mantiene la demostración enfocada en las dependencias entre capas.
/// </summary>
public sealed class InMemoryTaskRepository : ITaskRepository
{
    // ---------------------------------------------------------------------
    // PASO 6.1 - DÓNDE SE GUARDAN LOS DATOS
    // ---------------------------------------------------------------------
    // ConcurrentDictionary<Guid, TaskItem> = un diccionario (clave -> valor)
    // donde la clave es el Id de la tarea y el valor es la tarea.
    // "Concurrent" = seguro para usar desde varios hilos a la vez. Hace falta
    // porque una API web puede recibir VARIOS pedidos al mismo tiempo.
    // (En nuestro parcial de consola alcanzaba con una List<>, porque hay un
    // solo usuario a la vez.)
    // "new()" sin tipo: C# lo deduce del tipo declarado.
    private readonly ConcurrentDictionary<Guid, TaskItem> tasks = new();

    // ---------------------------------------------------------------------
    // PASO 6.2 - GUARDAR
    // ---------------------------------------------------------------------
    public Task AddAsync(TaskItem task, CancellationToken cancellationToken = default)
    {
        // Guarda (o reemplaza) la tarea usando su Id como clave.
        tasks[task.Id] = task;

        // El método tiene que devolver un Task (la interfaz es async), pero
        // acá no hay nada que esperar: Task.CompletedTask = "ya terminé".
        return Task.CompletedTask;
    }

    // ---------------------------------------------------------------------
    // PASO 6.3 - LISTAR
    // ---------------------------------------------------------------------
    public Task<IReadOnlyCollection<TaskItem>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        // tasks.Values                        -> todas las tareas guardadas
        // .OrderBy(task => task.CreatedAtUtc) -> ordenadas por fecha de creación
        // .ToArray()                          -> COPIA en un arreglo (nadie de afuera
        //                                        modifica el diccionario original)
        // "task => task.CreatedAtUtc" es una LAMBDA: "para cada tarea, usá su fecha".
        IReadOnlyCollection<TaskItem> result = tasks.Values.OrderBy(task => task.CreatedAtUtc).ToArray();

        // Task.FromResult(x) = "devolvé x como un Task ya terminado".
        return Task.FromResult(result);
    }
}
