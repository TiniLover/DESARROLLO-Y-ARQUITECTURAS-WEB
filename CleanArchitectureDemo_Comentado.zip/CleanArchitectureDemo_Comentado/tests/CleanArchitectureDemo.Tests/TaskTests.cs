// =========================================================================
// PASO 8 - PRUEBAS UNITARIAS (xUnit)
// -------------------------------------------------------------------------
// Este proyecto demuestra la GRAN VENTAJA de Clean Architecture:
// se puede probar el Dominio y la Aplicación SIN la API, SIN Swagger y
// SIN base de datos. Mirá su .csproj: solo referencia Domain y Application
// (NO referencia Api ni Infrastructure).
//
// Se ejecutan en Visual Studio con: Prueba > Ejecutar todas las pruebas
// (o "dotnet test" en la terminal).
// =========================================================================
using CleanArchitectureDemo.Application.Abstractions;
using CleanArchitectureDemo.Application.Tasks;
using CleanArchitectureDemo.Domain;

namespace CleanArchitectureDemo.Tests;

public sealed class TaskTests
{
    // ---------------------------------------------------------------------
    // PRUEBA 1 - Regla del DOMINIO: no se puede crear una tarea sin título
    // ---------------------------------------------------------------------
    // [Fact] = "esto es una prueba". El nombre describe lo que se prueba.
    [Fact]
    public void Create_rejects_an_empty_title()
    {
        // Se guarda la ACCIÓN (sin ejecutarla todavía): crear con título " ".
        var action = () => TaskItem.Create(" ");

        // La prueba pasa SI Y SOLO SI esa acción lanza ArgumentException.
        Assert.Throws<ArgumentException>(action);
    }

    // ---------------------------------------------------------------------
    // PRUEBA 2 - CASO DE USO: crear guarda la tarea y devuelve un DTO
    // ---------------------------------------------------------------------
    // Estructura típica de una prueba: PREPARAR - EJECUTAR - VERIFICAR.
    [Fact]
    public async Task Create_use_case_persists_and_returns_a_dto()
    {
        // PREPARAR: en vez del repositorio real se usa uno FALSO (abajo).
        // Esto es posible SOLO porque el caso de uso depende de la INTERFAZ
        // ITaskRepository: se le puede "inyectar" cualquier implementación.
        var repository = new FakeTaskRepository();
        var useCase = new CreateTaskUseCase(repository);   // inyección "a mano"

        // EJECUTAR: crear una tarea con espacios de más.
        var result = await useCase.ExecuteAsync("  Estudiar Clean Architecture  ");

        // VERIFICAR:
        //  - el título del DTO llegó SIN los espacios (lo hizo el Trim del Dominio)
        Assert.Equal("Estudiar Clean Architecture", result.Title);
        //  - en el repositorio quedó guardada exactamente UNA tarea
        Assert.Single(repository.Tasks);
    }

    // ---------------------------------------------------------------------
    // REPOSITORIO FALSO ("fake") usado solo por las pruebas
    // ---------------------------------------------------------------------
    // Implementa la misma interfaz que InMemoryTaskRepository, pero guarda en
    // una lista PÚBLICA para que la prueba pueda revisar qué se guardó.
    // Es una clase "private" anidada: solo existe dentro de TaskTests.
    private sealed class FakeTaskRepository : ITaskRepository
    {
        // "= []" (C# 12) = lista vacía. Equivale a "= new List<TaskItem>()".
        public List<TaskItem> Tasks { get; } = [];

        public Task AddAsync(TaskItem task, CancellationToken cancellationToken = default)
        {
            Tasks.Add(task);
            return Task.CompletedTask;
        }

        public Task<IReadOnlyCollection<TaskItem>> GetAllAsync(CancellationToken cancellationToken = default)
        {
            return Task.FromResult<IReadOnlyCollection<TaskItem>>(Tasks);
        }
    }
}
